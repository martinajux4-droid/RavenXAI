/*
  # Trading Platform Schema

  1. New Tables
    - `trades` - Records all executed trades
      - id, user_id, symbol, contract_type, stake, payout, entry_price, exit_price, result, profit_loss, duration, created_at, closed_at
    - `watchlist` - User's tracked symbols
      - id, user_id, symbol, added_at
    - `ai_signals` - AI-generated trading signals
      - id, symbol, signal_type, confidence, reasoning, created_at

  2. Security
    - Enable RLS on all tables
    - Authenticated users can only access their own trades/watchlist
    - AI signals are readable by all authenticated users
*/

CREATE TABLE IF NOT EXISTS trades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  symbol text NOT NULL,
  contract_type text NOT NULL,
  stake numeric(10,2) NOT NULL DEFAULT 0,
  payout numeric(10,2),
  entry_price numeric(15,5),
  exit_price numeric(15,5),
  result text DEFAULT 'open',
  profit_loss numeric(10,2) DEFAULT 0,
  duration integer DEFAULT 60,
  reference_id text,
  created_at timestamptz DEFAULT now(),
  closed_at timestamptz
);

CREATE TABLE IF NOT EXISTS watchlist (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  symbol text NOT NULL,
  added_at timestamptz DEFAULT now(),
  UNIQUE(user_id, symbol)
);

CREATE TABLE IF NOT EXISTS ai_signals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  symbol text NOT NULL,
  signal_type text NOT NULL,
  confidence numeric(5,2) NOT NULL DEFAULT 0,
  reasoning text,
  indicators jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE trades ENABLE ROW LEVEL SECURITY;
ALTER TABLE watchlist ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_signals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own trades"
  ON trades FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own trades"
  ON trades FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own trades"
  ON trades FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own watchlist"
  ON watchlist FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own watchlist"
  ON watchlist FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own watchlist"
  ON watchlist FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Authenticated users can view ai signals"
  ON ai_signals FOR SELECT
  TO authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS idx_trades_user_id ON trades(user_id);
CREATE INDEX IF NOT EXISTS idx_trades_created_at ON trades(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
CREATE INDEX IF NOT EXISTS idx_ai_signals_symbol ON ai_signals(symbol);
CREATE INDEX IF NOT EXISTS idx_ai_signals_created_at ON ai_signals(created_at DESC);
