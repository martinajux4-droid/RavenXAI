/*
  # Add contract metadata columns

  1. Changes
    - Add `barrier` column to trades for Over/Under and Matches/Differs strategies
    - Add `prediction` column for digit-based trades (Even/Odd/Matches/Differs)
    - Add `strategy_type` column to track which strategy was used
  2. Notes
    - All columns are nullable for backwards compatibility
    - No data is destroyed
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'trades' AND column_name = 'barrier'
  ) THEN
    ALTER TABLE trades ADD COLUMN barrier numeric;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'trades' AND column_name = 'prediction'
  ) THEN
    ALTER TABLE trades ADD COLUMN prediction integer;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'trades' AND column_name = 'strategy_type'
  ) THEN
    ALTER TABLE trades ADD COLUMN strategy_type text DEFAULT 'rise_fall';
  END IF;
END $$;
