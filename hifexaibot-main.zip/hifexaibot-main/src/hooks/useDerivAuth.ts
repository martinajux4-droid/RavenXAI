import { useState, useEffect, useCallback } from 'react';
import { derivAPI, DerivAccount, OAuthAccount } from '../lib/derivApi';

export type AuthState = 'idle' | 'loading' | 'authenticated' | 'error';

export function useDerivAuth() {
  const [account, setAccount] = useState<DerivAccount | null>(null);
  const [authState, setAuthState] = useState<AuthState>('idle');
  const [authError, setAuthError] = useState<string | null>(null);
  const [balance, setBalance] = useState<number | null>(null);
  const [oauthAccounts, setOAuthAccounts] = useState<OAuthAccount[]>([]);

  useEffect(() => {
    const unsubAcc = derivAPI.onAccountChange(acc => {
      setAccount(acc);
      setAuthState(acc ? 'authenticated' : 'idle');
      if (acc) setBalance(acc.balance);
    });
    const unsubBal = derivAPI.onBalanceChange(bal => setBalance(bal));
    const unsubAccounts = derivAPI.onAccountsChange(accs => setOAuthAccounts(accs));

    // Try restoring saved session on mount
    setAuthState('loading');
    derivAPI.restoreSession()
      .then(acc => {
        if (acc) { setAccount(acc); setBalance(acc.balance); setAuthState('authenticated'); }
        else setAuthState('idle');
        // Restore saved oauth accounts list
        setOAuthAccounts(derivAPI.getOAuthAccounts());
      })
      .catch(() => setAuthState('idle'));

    return () => { unsubAcc(); unsubBal(); unsubAccounts(); };
  }, []);

  const login = useCallback(async (token: string): Promise<DerivAccount> => {
    setAuthState('loading');
    setAuthError(null);
    try {
      const acc = await derivAPI.login(token);
      setAccount(acc);
      setBalance(acc.balance);
      setAuthState('authenticated');
      return acc;
    } catch (e) {
      const raw = e instanceof Error ? e.message : 'Authentication failed';
      const msg = translateError(raw);
      setAuthError(msg);
      setAuthState('error');
      throw new Error(msg);
    }
  }, []);

  const loginWithOAuth = useCallback(async (accounts: OAuthAccount[]): Promise<DerivAccount> => {
    setAuthState('loading');
    setAuthError(null);
    try {
      const acc = await derivAPI.loginWithOAuthAccounts(accounts);
      setAccount(acc);
      setBalance(acc.balance);
      setOAuthAccounts(derivAPI.getOAuthAccounts());
      setAuthState('authenticated');
      return acc;
    } catch (e) {
      const raw = e instanceof Error ? e.message : 'Authentication failed';
      const msg = translateError(raw);
      setAuthError(msg);
      setAuthState('error');
      throw new Error(msg);
    }
  }, []);

  const switchAccount = useCallback(async (loginid: string) => {
    setAuthState('loading');
    try {
      const acc = await derivAPI.switchAccount(loginid);
      setAccount(acc);
      setBalance(acc.balance);
      setAuthState('authenticated');
    } catch (e) {
      setAuthState('authenticated'); // don't lock out
      console.error('Switch account failed', e);
    }
  }, []);

  const logout = useCallback(() => {
    derivAPI.logout();
    setAccount(null);
    setBalance(null);
    setOAuthAccounts([]);
    setAuthState('idle');
    setAuthError(null);
  }, []);

  return {
    account,
    authState,
    authError,
    balance,
    oauthAccounts,
    login,
    loginWithOAuth,
    switchAccount,
    logout,
    isAuthenticated: authState === 'authenticated',
  };
}

function translateError(raw: string): string {
  if (raw.includes('InvalidToken') || raw.includes('AuthorizationRequired'))
    return 'Invalid API token. Please check and try again.';
  if (raw.includes('AccountDisabled'))
    return 'Your Deriv account has been disabled.';
  if (raw.includes('RateLimit'))
    return 'Too many attempts. Please wait a moment.';
  return raw;
}
