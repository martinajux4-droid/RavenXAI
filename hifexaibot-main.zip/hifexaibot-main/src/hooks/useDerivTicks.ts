import { useEffect, useRef, useState, useCallback } from 'react';
import { derivAPI, DerivTick } from '../lib/derivApi';

export function useDerivTicks(symbol: string) {
  const [ticks, setTicks] = useState<DerivTick[]>([]);
  const [currentPrice, setCurrentPrice] = useState<number | null>(null);
  const [priceChange, setPriceChange] = useState<number>(0);
  const [connected, setConnected] = useState(false);
  const unsubRef = useRef<(() => void) | null>(null);
  const subscriptionIdRef = useRef<string>('');

  const connect = useCallback(async () => {
    if (unsubRef.current) unsubRef.current();

    unsubRef.current = derivAPI.subscribe('tick', (data) => {
      const tick = (data as { tick?: { epoch: number; quote: number; symbol: string } }).tick;
      if (tick && tick.symbol === symbol) {
        setConnected(true);
        setCurrentPrice(prev => {
          if (prev !== null) setPriceChange(tick.quote - prev);
          return tick.quote;
        });
        setTicks(prev => {
          const updated = [...prev, { epoch: tick.epoch, quote: tick.quote, symbol: tick.symbol }];
          return updated.slice(-300);
        });
      }
    });

    try {
      subscriptionIdRef.current = await derivAPI.getTicks(symbol);
      setConnected(true);
    } catch {
      setConnected(false);
    }
  }, [symbol]);

  useEffect(() => {
    setTicks([]);
    setCurrentPrice(null);
    setPriceChange(0);
    setConnected(false);
    connect();

    return () => {
      if (unsubRef.current) unsubRef.current();
    };
  }, [connect]);

  return { ticks, currentPrice, priceChange, connected };
}
