import { useState, useEffect, useRef, useCallback } from 'react';
import { derivAPI, DerivContract } from '../lib/derivApi';

export type LiveContract = {
  contractId: number;
  status: 'open' | 'won' | 'lost' | 'sold';
  entrySpot: number;
  currentSpot: number | null;
  profit: number;
  profitPct: number;
  buyPrice: number;
  payout: number;
  dateExpiry: number;
  symbol: string;
  contractType: string;
  isExpired: boolean;
};

export function useContractMonitor(contractId: number | null) {
  const [contract, setContract] = useState<LiveContract | null>(null);
  const [closed, setClosed] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const unsubRef = useRef<(() => void) | null>(null);

  const parse = useCallback((raw: DerivContract): LiveContract => ({
    contractId: raw.contract_id,
    status: raw.status === 'open' ? 'open' : raw.profit >= 0 ? 'won' : 'lost',
    entrySpot: raw.entry_spot,
    currentSpot: raw.current_spot ?? null,
    profit: raw.profit,
    profitPct: raw.profit_percentage,
    buyPrice: raw.buy_price,
    payout: raw.payout,
    dateExpiry: raw.date_expiry,
    symbol: raw.symbol,
    contractType: raw.contract_type,
    isExpired: raw.is_expired,
  }), []);

  useEffect(() => {
    if (!contractId) { setContract(null); setClosed(false); return; }
    setClosed(false);

    // Subscribe to real-time updates via WebSocket
    unsubRef.current = derivAPI.subscribeToContract(contractId);

    const unsubMsg = derivAPI.subscribe('proposal_open_contract', (data) => {
      const poc = (data as { proposal_open_contract?: DerivContract }).proposal_open_contract;
      if (!poc || poc.contract_id !== contractId) return;
      const lc = parse(poc);
      setContract(lc);
      if (poc.is_expired || poc.status !== 'open') {
        setClosed(true);
        if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
      }
    });

    // Fallback polling every 3s
    pollRef.current = setInterval(async () => {
      try {
        const raw = await derivAPI.getContractDetails(contractId);
        setContract(parse(raw));
        if (raw.is_expired || raw.status !== 'open') {
          setClosed(true);
          if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
        }
      } catch {}
    }, 3000);

    return () => {
      if (unsubRef.current) { unsubRef.current(); unsubRef.current = null; }
      if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
      unsubMsg();
    };
  }, [contractId, parse]);

  return { contract, closed };
}
