import { useEffect, useState, useCallback } from 'react';
import { supabase, Trade } from '../lib/supabase';

export function useTrades(userId: string | null) {
  const [trades, setTrades] = useState<Trade[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchTrades = useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    const { data } = await supabase
      .from('trades')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(100);
    if (data) setTrades(data as Trade[]);
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    fetchTrades();
  }, [fetchTrades]);

  const addTrade = useCallback(async (trade: Omit<Trade, 'id' | 'user_id' | 'created_at'>) => {
    if (!userId) return null;
    const { data } = await supabase
      .from('trades')
      .insert({ ...trade, user_id: userId })
      .select()
      .maybeSingle();
    if (data) {
      setTrades(prev => [data as Trade, ...prev]);
      return data as Trade;
    }
    return null;
  }, [userId]);

  const updateTrade = useCallback(async (id: string, updates: Partial<Trade>) => {
    const { data } = await supabase
      .from('trades')
      .update(updates)
      .eq('id', id)
      .select()
      .maybeSingle();
    if (data) {
      setTrades(prev => prev.map(t => t.id === id ? { ...t, ...data } as Trade : t));
    }
  }, []);

  const totalPL = trades.reduce((sum, t) => sum + (t.profit_loss || 0), 0);
  const winRate = trades.length > 0
    ? (trades.filter(t => t.result === 'won').length / trades.filter(t => t.result !== 'open').length) * 100
    : 0;

  return { trades, loading, addTrade, updateTrade, fetchTrades, totalPL, winRate };
}
