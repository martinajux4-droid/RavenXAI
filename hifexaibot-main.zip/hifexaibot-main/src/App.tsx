import { useState, useEffect, useCallback, useRef } from 'react';
import AccountPanel from './components/dashboard/AccountPanel';
import RiskPanel, { RiskConfig, StrategyType } from './components/dashboard/RiskPanel';
import ScannerSection from './components/dashboard/ScannerSection';
import ExecuteSection from './components/dashboard/ExecuteSection';
import ResultPopup from './components/dashboard/ResultPopup';
import TradeHistoryCard from './components/dashboard/TradeHistoryCard';
import DerivAuthModal from './components/DerivAuthModal';
import { useDerivTicks } from './hooks/useDerivTicks';
import { useTrades } from './hooks/useTrades';
import { useDerivAuth } from './hooks/useDerivAuth';
import { useContractMonitor } from './hooks/useContractMonitor';
import { analyzeMarket, AIAnalysis, ScanResult } from './lib/aiEngine';
import { derivAPI, VOLATILITY_INDICES, OAuthAccount } from './lib/derivApi';
import { Trade } from './lib/supabase';
import {
  History, Settings2, Zap, RefreshCw,
  CheckCircle2, XCircle, Shield, Target,
} from 'lucide-react';

const DEMO_USER_ID = 'demo-user-00000000-0000-0000-0000-000000000001';

export type CloseReason = 'takeprofit' | 'stoploss' | 'expired' | null;

export type TradeResult = {
  result: 'won' | 'lost';
  profitLoss: number;
  stake: number;
  payout: number;
  symbol: string;
  contractType: string;
  entryPrice: number | null;
  exitPrice: number | null;
  prevBalance: number | null;
  newBalance: number | null;
  analysis: AIAnalysis | null;
  closeReason: CloseReason;
};

type NotifType = 'won' | 'lost' | 'takeprofit' | 'stoploss';
type Notif = { id: number; type: NotifType; message: string; amount?: number };

type MobileTab = 'execute' | 'history';

function resolveContractType(strategy: StrategyType, signal: string | undefined): string | null {
  if (!signal || signal === 'NEUTRAL') return null;
  const up = signal === 'CALL';
  switch (strategy) {
    case 'rise_fall':       return up ? 'CALL'       : 'PUT';
    case 'even_odd':        return up ? 'DIGITEVEN'  : 'DIGITODD';
    case 'over_under':      return up ? 'DIGITOVER'  : 'DIGITUNDER';
    case 'matches_differs': return up ? 'DIGITMATCH' : 'DIGITDIFF';
    default:                return null;
  }
}

const DEFAULT_RISK: RiskConfig = {
  stake: 10, stopLoss: null, takeProfit: null,
  martingale: false, martingaleMultiplier: 2, ticks: 5, strategy: 'rise_fall',
};

function parseOAuthParams(): OAuthAccount[] | null {
  const params = new URLSearchParams(window.location.search);
  const accounts: OAuthAccount[] = [];
  let i = 1;
  while (params.has(`acct${i}`)) {
    const loginid  = params.get(`acct${i}`) ?? '';
    const token    = params.get(`token${i}`) ?? '';
    const currency = params.get(`cur${i}`) ?? undefined;
    const isVirtual = loginid.startsWith('VRT') || loginid.startsWith('VRTC');
    if (loginid && token) accounts.push({ loginid, token, is_virtual: isVirtual, currency });
    i++;
  }
  return accounts.length > 0 ? accounts : null;
}

let notifId = 0;

export default function App() {
  const [symbol, setSymbol]             = useState('R_100');
  const [analysis, setAnalysis]         = useState<AIAnalysis | null>(null);
  const [riskConfig, setRiskConfig]     = useState<RiskConfig>(DEFAULT_RISK);
  const [mobileTab, setMobileTab]       = useState<MobileTab>('execute');
  const [showAuth, setShowAuth]         = useState(false);
  const [sessionActive, setSessionActive] = useState(false);
  const [martingaleStake, setMartingaleStake] = useState<number | null>(null);
  const [newTradeId, setNewTradeId]     = useState<string | null>(null);
  const [notifications, setNotifications] = useState<Notif[]>([]);
  const [consecutiveLosses, setConsecutiveLosses] = useState(0);

  /* Scan */
  const [scanning, setScanning]         = useState(false);
  const [scanProgress, setScanProg]     = useState(0);
  const [scanResults, setScanResults]   = useState<ScanResult[]>([]);
  const [bestResult, setBestResult]     = useState<ScanResult | null>(null);
  const [scanSymbol, setScanSymbol]     = useState('');

  /* Live trade */
  const [activeTrade, setActiveTrade]             = useState<Trade | null>(null);
  const [activeContractId, setActiveContractId]   = useState<number | null>(null);
  const [liveEntrySpot, setLiveEntrySpot]         = useState<number | null>(null);
  const [closeReason, setCloseReason]             = useState<CloseReason>(null);

  /* Result */
  const [tradeResult, setTradeResult]   = useState<TradeResult | null>(null);
  const [showResult, setShowResult]     = useState(false);
  const [balanceSnapshot, setBalanceSnapshot] = useState<number | null>(null);

  /* Session totals (cumulative for TP/SL session tracking) */
  const [sessionPL, setSessionPL]       = useState(0);

  /* Stable refs */
  const sessionRef   = useRef(sessionActive);
  const riskRef      = useRef(riskConfig);
  const closeRef     = useRef<CloseReason>(null);
  const executingRef = useRef(false);
  const sessionPLRef = useRef(sessionPL);
  const martingaleRef = useRef(martingaleStake);

  sessionRef.current    = sessionActive;
  riskRef.current       = riskConfig;
  closeRef.current      = closeReason;
  sessionPLRef.current  = sessionPL;
  martingaleRef.current = martingaleStake;

  const { ticks, currentPrice, connected }   = useDerivTicks(symbol);
  const { trades, addTrade, updateTrade, fetchTrades, totalPL, winRate } = useTrades(DEMO_USER_ID);
  const {
    account, authState, authError, balance, oauthAccounts,
    login, loginWithOAuth, switchAccount, logout, isAuthenticated,
  } = useDerivAuth();
  const { contract: liveContract, closed: contractClosed } = useContractMonitor(activeContractId);

  /* ── OAuth callback ── */
  useEffect(() => {
    const oauthAccts = parseOAuthParams();
    if (oauthAccts) {
      window.history.replaceState({}, '', window.location.pathname);
      loginWithOAuth(oauthAccts).catch(() => {});
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* ── Auto-analysis every 5 ticks ── */
  useEffect(() => {
    if (ticks.length >= 30 && ticks.length % 5 === 0) {
      setAnalysis(analyzeMarket(ticks.map(t => t.quote)));
    }
  }, [ticks.length]);

  /* ── Capture entry spot from live contract ── */
  useEffect(() => {
    if (liveContract?.entrySpot != null && liveEntrySpot === null) {
      setLiveEntrySpot(liveContract.entrySpot);
    }
  }, [liveContract?.entrySpot, liveEntrySpot]);

  const autoContractType = analysis
    ? resolveContractType(riskConfig.strategy, analysis.signal)
    : null;

  /* ── Push notification ── */
  const pushNotif = useCallback((type: NotifType, message: string, amount?: number) => {
    const id = ++notifId;
    setNotifications(prev => [...prev.slice(-3), { id, type, message, amount }]);
    setTimeout(() => setNotifications(prev => prev.filter(n => n.id !== id)), 5000);
  }, []);

  /* ── TP/SL watcher on live contract ── */
  useEffect(() => {
    if (!activeTrade || !liveContract || contractClosed || closeRef.current !== null) return;
    const p   = liveContract.profit;
    const cfg = riskRef.current;

    if (cfg.takeProfit !== null && p >= Math.abs(cfg.takeProfit)) {
      setCloseReason('takeprofit');
      closeRef.current = 'takeprofit';
      pushNotif('takeprofit', 'Take Profit Reached!', p);
      if (isAuthenticated && activeContractId) derivAPI.sellContract(activeContractId, 0).catch(() => {});
    } else if (cfg.stopLoss !== null && p <= -Math.abs(cfg.stopLoss)) {
      setCloseReason('stoploss');
      closeRef.current = 'stoploss';
      pushNotif('stoploss', 'Stop Loss Triggered', p);
      if (isAuthenticated && activeContractId) derivAPI.sellContract(activeContractId, 0).catch(() => {});
    }
  }, [liveContract, activeTrade, isAuthenticated, activeContractId, contractClosed, pushNotif]);

  /* ── Contract closed → finalize ── */
  useEffect(() => {
    if (!contractClosed || !liveContract || !activeTrade) return;

    const won      = liveContract.profit > 0;
    const pl       = liveContract.profit;
    const exitSpot = liveContract.currentSpot ?? null;
    const reason   = closeRef.current ?? 'expired';
    const prevBal  = balanceSnapshot;

    updateTrade(activeTrade.id, {
      result:      won ? 'won' : 'lost',
      profit_loss: pl,
      exit_price:  exitSpot ?? undefined,
      closed_at:   new Date().toISOString(),
    });

    setSessionPL(prev => prev + pl);

    /* Martingale */
    const cfg = riskRef.current;
    let nextStake: number | null = null;
    if (!won && cfg.martingale) {
      const base  = martingaleRef.current ?? cfg.stake;
      nextStake   = base * cfg.martingaleMultiplier;
      setConsecutiveLosses(n => n + 1);
    } else {
      setMartingaleStake(null);
      setConsecutiveLosses(0);
    }
    if (nextStake !== null) setMartingaleStake(nextStake);

    if (reason !== 'takeprofit' && reason !== 'stoploss') {
      pushNotif(won ? 'won' : 'lost', won ? 'Trade Won!' : 'Trade Lost', pl);
    }

    setTradeResult({
      result:       won ? 'won' : 'lost',
      profitLoss:   pl,
      stake:        activeTrade.stake,
      payout:       activeTrade.payout ?? activeTrade.stake * 1.85,
      symbol:       activeTrade.symbol,
      contractType: activeTrade.contract_type,
      entryPrice:   liveEntrySpot ?? activeTrade.entry_price,
      exitPrice:    exitSpot,
      prevBalance:  prevBal,
      newBalance:   balance,
      analysis,
      closeReason:  reason,
    });

    setActiveTrade(null);
    setActiveContractId(null);
    setLiveEntrySpot(null);
    setCloseReason(null);
    closeRef.current = null;
    setShowResult(true);
    setNewTradeId(activeTrade.id);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contractClosed]);

  /* ── Execute trade ── */
  const doExecute = useCallback(async () => {
    if (activeTrade || !sessionRef.current || executingRef.current) return;
    if (!analysis || analysis.signal === 'NEUTRAL' || analysis.confidence < 55) return;

    const cfg            = riskRef.current;
    const effectiveStake = martingaleRef.current ?? cfg.stake;
    const contractType   = resolveContractType(cfg.strategy, analysis.signal);
    if (!contractType) return;

    executingRef.current = true;
    const isDigit = cfg.strategy !== 'rise_fall';
    const durUnit = isDigit ? 't' : 'm';
    const durVal  = isDigit ? cfg.ticks : Math.max(1, Math.round(cfg.ticks * 2 / 60));
    const durSecs = isDigit ? cfg.ticks * 2 : durVal * 60;
    const barrier    = cfg.strategy === 'over_under' ? '5' : undefined;
    const prediction = isDigit ? 5 : undefined;

    setBalanceSnapshot(balance);

    const tradeRecord: Omit<Trade, 'id' | 'user_id' | 'created_at'> = {
      symbol, contract_type: contractType,
      stake: effectiveStake, payout: effectiveStake * 1.85,
      entry_price: currentPrice, exit_price: null,
      result: 'open', profit_loss: 0,
      duration: durSecs, reference_id: null, closed_at: null,
      barrier: barrier ? Number(barrier) : null,
      prediction: prediction ?? null,
      strategy_type: cfg.strategy,
    };

    /* ── Real Deriv buy ── */
    if (isAuthenticated) {
      try {
        const res = await derivAPI.buyContract({
          symbol, contractType, duration: durVal, durationUnit: durUnit,
          amount: effectiveStake, basis: 'stake', barrier, prediction,
        });
        tradeRecord.reference_id = String(res.buy.contract_id);
        tradeRecord.payout       = res.buy.payout;
        tradeRecord.stake        = res.buy.buy_price;
        tradeRecord.entry_price  = res.buy.spot ?? currentPrice;

        const saved = await addTrade(tradeRecord);
        if (saved) {
          setActiveTrade(saved);
          setActiveContractId(res.buy.contract_id);
          setLiveEntrySpot(res.buy.spot ?? currentPrice);
        }
        executingRef.current = false;
        return;
      } catch { /* fall through to demo */ }
    }

    /* ── Demo simulation ── */
    tradeRecord.reference_id = `DEMO-${Date.now()}`;
    const saved = await addTrade(tradeRecord);
    executingRef.current = false;
    if (!saved) return;

    setActiveTrade(saved);
    setLiveEntrySpot(currentPrice);

    /* Simulate live P&L movement */
    const totalMs  = Math.min(durSecs * 1000, 20_000);
    const tickMs   = 1000;
    let   elapsed  = 0;

    const simulate = () => {
      elapsed += tickMs;
      const progress = elapsed / totalMs;
      const won      = Math.random() > 0.44;

      if (elapsed >= totalMs) {
        const pl     = won ? effectiveStake * 0.85 : -effectiveStake;
        const exit   = currentPrice;
        const cfg2   = riskRef.current;

        /* Check TP/SL for demo */
        const cumPL  = sessionPLRef.current + pl;
        let reason: CloseReason = 'expired';
        if (cfg2.takeProfit !== null && (pl > 0) && pl >= cfg2.takeProfit) reason = 'takeprofit';
        if (cfg2.stopLoss   !== null && (pl < 0) && Math.abs(pl) >= cfg2.stopLoss) reason = 'stoploss';

        if (reason === 'takeprofit') pushNotif('takeprofit', 'Take Profit Reached!', pl);
        else if (reason === 'stoploss') pushNotif('stoploss', 'Stop Loss Triggered', pl);
        else pushNotif(won ? 'won' : 'lost', won ? 'Trade Won!' : 'Trade Lost', pl);

        updateTrade(saved.id, {
          result: won ? 'won' : 'lost', profit_loss: pl,
          exit_price: exit ?? undefined, closed_at: new Date().toISOString(),
        });

        setSessionPL(prev => prev + pl);

        /* Martingale */
        let nextStake: number | null = null;
        if (!won && cfg2.martingale) {
          const base = martingaleRef.current ?? cfg2.stake;
          nextStake  = base * cfg2.martingaleMultiplier;
          setConsecutiveLosses(n => n + 1);
        } else {
          setMartingaleStake(null);
          setConsecutiveLosses(0);
        }
        if (nextStake !== null) setMartingaleStake(nextStake);

        setTradeResult({
          result:       won ? 'won' : 'lost',
          profitLoss:   pl,
          stake:        effectiveStake,
          payout:       effectiveStake * 1.85,
          symbol,       contractType,
          entryPrice:   currentPrice, exitPrice: exit,
          prevBalance:  balanceSnapshot ?? null,
          newBalance:   (balanceSnapshot ?? 10000) + pl,
          analysis,     closeReason: reason,
        });

        setActiveTrade(null);
        setActiveContractId(null);
        setLiveEntrySpot(null);
        setCloseReason(null);
        closeRef.current = null;
        setShowResult(true);
        setNewTradeId(saved.id);
        return;
      }

      /* Mid-trade: update P&L with simulated movement */
      const noise = (Math.random() - 0.48) * effectiveStake * 0.3;
      const simPL = noise * progress;
      setActiveTrade(prev => prev ? { ...prev, profit_loss: simPL } : prev);

      /* Check live TP/SL during demo too */
      const cfg2 = riskRef.current;
      if (closeRef.current === null) {
        if (cfg2.takeProfit !== null && simPL >= cfg2.takeProfit) {
          closeRef.current = 'takeprofit';
          setCloseReason('takeprofit');
          pushNotif('takeprofit', 'Take Profit Reached!', simPL);
          const pl = simPL;
          updateTrade(saved.id, {
            result: 'won', profit_loss: pl,
            exit_price: currentPrice ?? undefined, closed_at: new Date().toISOString(),
          });
          setSessionPL(p => p + pl);
          setMartingaleStake(null); setConsecutiveLosses(0);
          setTradeResult({
            result: 'won', profitLoss: pl,
            stake: effectiveStake, payout: effectiveStake * 1.85,
            symbol, contractType, entryPrice: currentPrice, exitPrice: currentPrice,
            prevBalance: balanceSnapshot ?? null,
            newBalance: (balanceSnapshot ?? 10000) + pl,
            analysis, closeReason: 'takeprofit',
          });
          setActiveTrade(null); setActiveContractId(null); setLiveEntrySpot(null);
          closeRef.current = null; setShowResult(true); setNewTradeId(saved.id);
          return;
        }
        if (cfg2.stopLoss !== null && simPL <= -cfg2.stopLoss) {
          closeRef.current = 'stoploss';
          setCloseReason('stoploss');
          pushNotif('stoploss', 'Stop Loss Triggered', simPL);
          const pl = simPL;
          updateTrade(saved.id, {
            result: 'lost', profit_loss: pl,
            exit_price: currentPrice ?? undefined, closed_at: new Date().toISOString(),
          });
          setSessionPL(p => p + pl);
          const cfg3 = riskRef.current;
          if (cfg3.martingale) { const b = martingaleRef.current ?? cfg3.stake; setMartingaleStake(b * cfg3.martingaleMultiplier); setConsecutiveLosses(n => n + 1); }
          setTradeResult({
            result: 'lost', profitLoss: pl,
            stake: effectiveStake, payout: effectiveStake * 1.85,
            symbol, contractType, entryPrice: currentPrice, exitPrice: currentPrice,
            prevBalance: balanceSnapshot ?? null,
            newBalance: (balanceSnapshot ?? 10000) + pl,
            analysis, closeReason: 'stoploss',
          });
          setActiveTrade(null); setActiveContractId(null); setLiveEntrySpot(null);
          closeRef.current = null; setShowResult(true); setNewTradeId(saved.id);
          return;
        }
      }

      if (sessionRef.current) setTimeout(simulate, tickMs);
    };

    if (sessionRef.current) setTimeout(simulate, tickMs);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [symbol, currentPrice, isAuthenticated, activeTrade, addTrade, updateTrade, analysis, balance, balanceSnapshot, pushNotif]);

  /* ── Market scan ── */
  const scanMarkets = useCallback(async () => {
    if (scanning) return;
    setScanning(true); setScanResults([]); setBestResult(null); setScanProg(0);

    const results: ScanResult[] = [];
    for (let i = 0; i < VOLATILITY_INDICES.length; i++) {
      const sym = VOLATILITY_INDICES[i];
      setScanSymbol(sym.displayName.replace(' Index', ''));
      setScanProg(((i + 1) / VOLATILITY_INDICES.length) * 100);
      try {
        const h = await derivAPI.getTicksHistory(sym.symbol, 150);
        if (h.prices.length >= 30) {
          const a = analyzeMarket(h.prices);
          results.push({ symbol: sym.symbol, displayName: sym.displayName, analysis: a, score: a.confidence });
          setScanResults([...results].sort((a, b) => b.score - a.score));
        }
      } catch {}
      await new Promise(r => setTimeout(r, 150));
    }

    const sorted = [...results].sort((a, b) => b.score - a.score);
    setScanResults(sorted);
    const best = sorted[0] ?? null;
    setBestResult(best);
    if (best && best.score >= 61) { setSymbol(best.symbol); setAnalysis(best.analysis); }
    setScanning(false);
  }, [scanning]);

  const liveProfit = liveContract?.profit ?? (activeTrade?.profit_loss ?? 0);
  const liveSpot   = liveContract?.currentSpot ?? null;

  /* ── Notification color map ── */
  const notifStyles: Record<NotifType, { bg: string; border: string; color: string; icon: React.ReactNode }> = {
    won:        { bg: 'rgba(0,255,136,0.08)',  border: 'rgba(0,255,136,0.35)', color: '#00ff88', icon: <CheckCircle2 size={15} /> },
    lost:       { bg: 'rgba(255,51,85,0.08)',  border: 'rgba(255,51,85,0.35)', color: '#ff3355', icon: <XCircle size={15} /> },
    takeprofit: { bg: 'rgba(0,255,136,0.1)',   border: 'rgba(0,255,136,0.5)',  color: '#00ff88', icon: <Target size={15} /> },
    stoploss:   { bg: 'rgba(255,51,85,0.1)',   border: 'rgba(255,51,85,0.5)',  color: '#ff3355', icon: <Shield size={15} /> },
  };

  /* ── Shared blocks ── */
  const AccountBlock = () => (
    <div>
      <p className="section-label mb-3">Account</p>
      <AccountPanel
        account={account} balance={balance} connected={connected}
        totalPL={totalPL} winRate={winRate} tradesCount={trades.length}
        oauthAccounts={oauthAccounts}
        onOpenAuth={() => setShowAuth(true)}
        onSwitchAccount={switchAccount}
      />
    </div>
  );

  const RiskBlock = () => (
    <div>
      <p className="section-label mb-3">Risk Management</p>
      <RiskPanel onChange={setRiskConfig} />
    </div>
  );

  const ExecuteBlock = () => (
    <div>
      <p className="section-label mb-3">Execute Trade</p>
      <ExecuteSection
        analysis={analysis} currentPrice={currentPrice}
        activeTrade={activeTrade} liveProfit={liveProfit}
        liveCurrentSpot={liveSpot} liveEntrySpot={liveEntrySpot}
        riskConfig={riskConfig} sessionActive={sessionActive}
        autoContractType={autoContractType}
        balance={balance} currency={account?.currency ?? 'USD'}
        martingaleStake={martingaleStake}
        consecutiveLosses={consecutiveLosses}
        sessionPL={sessionPL}
        onExecute={doExecute}
        onStartSession={() => setSessionActive(true)}
        onStopSession={() => setSessionActive(false)}
      />
    </div>
  );

  const HistoryBlock = ({ compact }: { compact?: boolean }) => (
    <div>
      <div className="flex items-center justify-between mb-3">
        <p className="section-label">Trade History</p>
        <button onClick={fetchTrades}
          className="flex items-center gap-1 text-2xs font-black t-muted hover:t-green transition-colors">
          <RefreshCw size={10} /> Refresh
        </button>
      </div>
      {trades.length === 0 ? (
        <div className="text-center py-10">
          <History size={32} style={{ color: 'rgba(0,255,136,0.08)', margin: '0 auto 12px' }} />
          <p className="text-sm font-bold t-muted">No trades yet</p>
          <p className="text-2xs t-muted mt-1 opacity-60">Execute a trade to see history here</p>
        </div>
      ) : (
        <div className="space-y-2">
          {(compact ? trades.slice(0, 8) : trades).map(t => (
            <TradeHistoryCard key={t.id} trade={t} isNew={t.id === newTradeId} />
          ))}
        </div>
      )}
    </div>
  );

  const mobileTabs = [
    { id: 'execute' as MobileTab, label: 'Trade', icon: <Zap size={15} /> },
    { id: 'history' as MobileTab, label: 'History', icon: <History size={15} /> },
  ];

  /* ════════════════════════════════════════════════ */
  return (
    <div className="relative flex flex-col h-screen overflow-hidden" style={{ background: '#000' }}>

      {/* Animated BG */}
      <div className="scene" aria-hidden>
        <div className="orb orb-a" /><div className="orb orb-b" /><div className="orb orb-c" />
        <div className="sweep" />
      </div>

      {/* ── Notifications ── */}
      <div className="fixed top-4 right-4 z-[60] flex flex-col gap-2 pointer-events-none">
        {notifications.map(n => {
          const s = notifStyles[n.type];
          return (
            <div key={n.id}
              className="flex items-center gap-3 px-4 py-3 rounded-2xl anim-slide-left"
              style={{
                background: s.bg, border: `1px solid ${s.border}`,
                boxShadow: `0 0 24px ${s.border}, 0 8px 40px rgba(0,0,0,0.6)`,
                backdropFilter: 'blur(24px)', minWidth: 240,
              }}>
              <span style={{ color: s.color, filter: `drop-shadow(0 0 8px ${s.color})` }}>{s.icon}</span>
              <div>
                <p className="text-sm font-black" style={{ color: s.color, textShadow: `0 0 8px ${s.color}80` }}>
                  {n.message}
                </p>
                {n.amount !== undefined && (
                  <p className="text-xs font-black font-mono mt-0.5" style={{ color: `${s.color}aa` }}>
                    {n.amount >= 0 ? '+' : ''}{n.amount.toFixed(2)}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Header ── */}
      <header className="relative z-20 shrink-0 flex items-center gap-3 px-4 py-3"
        style={{
          background: 'rgba(0,5,2,0.93)', backdropFilter: 'blur(32px)',
          borderBottom: '1px solid rgba(0,255,136,0.1)',
          boxShadow: '0 1px 0 rgba(0,255,136,0.06), 0 4px 30px rgba(0,0,0,0.6)',
        }}>

        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-8 h-8 rounded-xl flex items-center justify-center"
            style={{
              background: 'linear-gradient(135deg, rgba(0,255,136,0.2), rgba(0,200,100,0.08))',
              border: '1px solid rgba(0,255,136,0.35)',
              boxShadow: '0 0 20px rgba(0,255,136,0.2), 0 0 50px rgba(0,255,136,0.07)',
            }}>
            <Zap size={15} style={{ color: '#00ff88', filter: 'drop-shadow(0 0 6px #00ff88)' }} />
          </div>
          <div>
            <div className="text-sm font-black tracking-tight t-white">DerivDen</div>
            <div className="t-green font-black uppercase tracking-widest" style={{ fontSize: '0.5rem' }}>AI AUTO TRADER</div>
          </div>
        </div>

        {/* Live stats */}
        <div className="hidden sm:flex items-center gap-2 ml-3">
          <div className="w-px h-5" style={{ background: 'rgba(0,255,136,0.1)' }} />
          <div className="px-2.5 py-1.5 rounded-xl text-xs font-black font-mono"
            style={{
              background: totalPL >= 0 ? 'rgba(0,255,136,0.07)' : 'rgba(255,51,85,0.07)',
              border:     totalPL >= 0 ? '1px solid rgba(0,255,136,0.16)' : '1px solid rgba(255,51,85,0.16)',
              color:      totalPL >= 0 ? '#00ff88' : '#ff3355',
              textShadow: totalPL >= 0 ? '0 0 8px rgba(0,255,136,0.6)' : '0 0 8px rgba(255,51,85,0.6)',
            }}>
            {totalPL >= 0 ? '+' : ''}${totalPL.toFixed(2)}
          </div>
          {trades.length > 0 && (
            <div className="px-2.5 py-1.5 rounded-xl text-xs font-black font-mono"
              style={{ background: 'rgba(0,212,255,0.06)', border: '1px solid rgba(0,212,255,0.15)', color: '#00d4ff' }}>
              {isNaN(winRate) ? 0 : winRate.toFixed(0)}% WR
            </div>
          )}
          {martingaleStake !== null && (
            <div className="px-2.5 py-1.5 rounded-xl text-xs font-black animate-pulse"
              style={{ background: 'rgba(0,212,255,0.07)', border: '1px solid rgba(0,212,255,0.2)', color: '#00d4ff' }}>
              Marti ${martingaleStake.toFixed(2)}
            </div>
          )}
          {account && balance !== null && (
            <>
              <div className="w-px h-5" style={{ background: 'rgba(0,255,136,0.1)' }} />
              <div className="px-2.5 py-1.5 rounded-xl text-xs font-black font-mono"
                style={{
                  background: account.is_virtual ? 'rgba(255,170,0,0.07)' : 'rgba(0,255,136,0.07)',
                  border: account.is_virtual ? '1px solid rgba(255,170,0,0.18)' : '1px solid rgba(0,255,136,0.18)',
                  color: account.is_virtual ? '#ffaa00' : '#00ff88',
                  textShadow: account.is_virtual ? '0 0 8px rgba(255,170,0,0.5)' : '0 0 8px rgba(0,255,136,0.5)',
                }}>
                {account.is_virtual ? 'DEMO' : 'REAL'} {balance.toFixed(2)} {account.currency}
              </div>
            </>
          )}
        </div>

        <div className="flex-1" />

        {/* Session toggle */}
        <button onClick={() => setSessionActive(v => !v)}
          className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all"
          style={{
            background: sessionActive ? 'rgba(0,255,136,0.08)' : 'rgba(0,255,136,0.03)',
            border: sessionActive ? '1px solid rgba(0,255,136,0.25)' : '1px solid rgba(0,255,136,0.1)',
            color: sessionActive ? '#00ff88' : 'rgba(0,255,136,0.35)',
            textShadow: sessionActive ? '0 0 8px rgba(0,255,136,0.5)' : 'none',
          }}>
          <div className={`w-1.5 h-1.5 rounded-full ${sessionActive ? 'animate-pulse' : ''}`}
            style={{ background: sessionActive ? '#00ff88' : 'rgba(100,100,100,0.5)', boxShadow: sessionActive ? '0 0 6px #00ff88' : 'none' }} />
          {sessionActive ? 'Session Active' : 'Session Off'}
        </button>

        {/* Auth */}
        <button onClick={() => setShowAuth(true)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-black transition-all"
          style={{
            background: account ? 'rgba(0,255,136,0.07)' : 'rgba(0,255,136,0.04)',
            border: account ? '1px solid rgba(0,255,136,0.22)' : '1px solid rgba(0,255,136,0.12)',
            color: '#00ff88', textShadow: '0 0 8px rgba(0,255,136,0.4)',
          }}>
          <Settings2 size={12} />
          <span className="hidden sm:block max-w-[80px] truncate">
            {account ? account.loginid : 'Connect'}
          </span>
        </button>
      </header>

      {/* ════════════════════════════════
          DESKTOP 3-column
      ════════════════════════════════ */}
      <div className="relative z-10 hidden lg:flex flex-1 min-h-0 overflow-hidden">

        {/* LEFT: Account + Risk */}
        <aside className="w-[290px] xl:w-[310px] shrink-0 flex flex-col overflow-hidden"
          style={{ borderRight: '1px solid rgba(0,255,136,0.07)' }}>
          <div className="flex-1 overflow-y-auto p-4 space-y-5 scrollbar-hide">
            <AccountBlock />
            <div className="neon-divider border-t" />
            <RiskBlock />
          </div>
        </aside>

        {/* CENTER: Scanner + Execute (stacked) */}
        <main className="flex-1 min-w-0 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto px-4 py-4 scrollbar-hide space-y-5">
            <div>
              <p className="section-label mb-3">AI Market Scanner</p>
              <ScannerSection
                scanning={scanning} progress={scanProgress}
                scanResults={scanResults} bestResult={bestResult}
                currentScanSymbol={scanSymbol}
                onScan={scanMarkets}
                onSelect={r => { setSymbol(r.symbol); setAnalysis(r.analysis); }}
                selectedSymbol={symbol}
              />
            </div>
            <div className="neon-divider border-t" />
            <ExecuteBlock />
          </div>
        </main>

        {/* RIGHT: History */}
        <aside className="w-[320px] xl:w-[360px] shrink-0 flex flex-col overflow-hidden"
          style={{ borderLeft: '1px solid rgba(0,255,136,0.07)' }}>
          <div className="flex-1 overflow-y-auto p-4 scrollbar-hide">
            <HistoryBlock />
          </div>
        </aside>
      </div>

      {/* ════════════════════════════════
          MOBILE tabs
      ════════════════════════════════ */}
      <div className="relative z-10 flex lg:hidden flex-col flex-1 min-h-0 overflow-hidden">

        <div className="shrink-0 flex"
          style={{ background: 'rgba(0,5,2,0.9)', borderBottom: '1px solid rgba(0,255,136,0.08)', backdropFilter: 'blur(20px)' }}>
          {mobileTabs.map(t => (
            <button key={t.id} onClick={() => setMobileTab(t.id)}
              className="flex-1 flex items-center justify-center gap-1.5 py-3.5 text-xs font-black uppercase tracking-wider transition-all"
              style={{
                color:        mobileTab === t.id ? '#00ff88' : 'rgba(0,255,136,0.25)',
                borderBottom: mobileTab === t.id ? '2px solid #00ff88' : '2px solid transparent',
                background:   mobileTab === t.id ? 'rgba(0,255,136,0.04)' : 'transparent',
                textShadow:   mobileTab === t.id ? '0 0 10px rgba(0,255,136,0.7)' : 'none',
              }}>
              {t.icon}{t.label}
              {t.id === 'history' && trades.length > 0 && (
                <span className="w-4 h-4 rounded-full text-2xs font-black flex items-center justify-center ml-0.5"
                  style={{ background: 'rgba(0,255,136,0.12)', color: '#00ff88', fontSize: '0.55rem' }}>
                  {trades.length > 9 ? '9+' : trades.length}
                </span>
              )}
            </button>
          ))}
        </div>

        <div className="flex-1 min-h-0 overflow-hidden">
          {mobileTab === 'execute' && (
            <div className="h-full overflow-y-auto scrollbar-hide">
              <div className="p-4 space-y-5 pb-8">
                <AccountBlock />
                <div className="neon-divider border-t" />
                <RiskBlock />
                <div className="neon-divider border-t" />
                <div>
                  <p className="section-label mb-3">AI Market Scanner</p>
                  <ScannerSection
                    scanning={scanning} progress={scanProgress}
                    scanResults={scanResults} bestResult={bestResult}
                    currentScanSymbol={scanSymbol}
                    onScan={scanMarkets}
                    onSelect={r => { setSymbol(r.symbol); setAnalysis(r.analysis); }}
                    selectedSymbol={symbol}
                  />
                </div>
                <div className="neon-divider border-t" />
                <ExecuteBlock />
              </div>
            </div>
          )}
          {mobileTab === 'history' && (
            <div className="h-full overflow-y-auto scrollbar-hide">
              <div className="p-4 pb-8"><HistoryBlock /></div>
            </div>
          )}
        </div>
      </div>

      {/* ── Auth Modal ── */}
      {showAuth && (
        <DerivAuthModal
          onLogin={login} onLogout={logout} onSwitchAccount={switchAccount}
          account={account} balance={balance} oauthAccounts={oauthAccounts}
          authState={authState} authError={authError}
          onClose={() => setShowAuth(false)}
        />
      )}

      {/* ── Result Popup ── */}
      {showResult && tradeResult && (
        <ResultPopup
          result={tradeResult.result}
          profitLoss={tradeResult.profitLoss}
          stake={tradeResult.stake}
          payout={tradeResult.payout}
          symbol={tradeResult.symbol}
          contractType={tradeResult.contractType}
          entryPrice={tradeResult.entryPrice}
          exitPrice={tradeResult.exitPrice}
          newBalance={tradeResult.newBalance}
          prevBalance={tradeResult.prevBalance}
          currency={account?.currency ?? 'USD'}
          analysis={tradeResult.analysis}
          closeReason={tradeResult.closeReason}
          martingaleNext={tradeResult.result === 'lost' && riskConfig.martingale
            ? (martingaleStake ?? riskConfig.stake)
            : null}
          onClose={() => setShowResult(false)}
          onRetrade={() => { setShowResult(false); setMobileTab('execute'); }}
        />
      )}
    </div>
  );
}

