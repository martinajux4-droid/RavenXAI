export type DerivTick = {
  epoch: number;
  quote: number;
  symbol: string;
};

export type DerivCandle = {
  epoch: number;
  open: number;
  high: number;
  close: number;
  low: number;
};

export type DerivBalance = {
  balance: number;
  currency: string;
  loginid: string;
};

export type DerivAccount = {
  loginid: string;
  email: string;
  fullname: string;
  currency: string;
  balance: number;
  is_virtual: boolean;
  token?: string;
};

export type DerivContract = {
  contract_id: number;
  status: 'open' | 'sold' | 'won' | 'lost';
  entry_spot: number;
  exit_tick?: number;
  profit: number;
  profit_percentage: number;
  buy_price: number;
  payout: number;
  sell_price?: number;
  current_spot?: number;
  date_start: number;
  date_expiry: number;
  symbol: string;
  contract_type: string;
  is_expired: boolean;
  is_valid_to_sell: boolean;
};

export type VolatilityIndex = {
  symbol: string;
  displayName: string;
  category: string;
  pip: number;
};

export const APP_ID = 68610;

export const VOLATILITY_INDICES: VolatilityIndex[] = [
  { symbol: 'R_10',      displayName: 'Volatility 10 Index',        category: 'Volatility',    pip: 3 },
  { symbol: 'R_25',      displayName: 'Volatility 25 Index',        category: 'Volatility',    pip: 3 },
  { symbol: 'R_50',      displayName: 'Volatility 50 Index',        category: 'Volatility',    pip: 4 },
  { symbol: 'R_75',      displayName: 'Volatility 75 Index',        category: 'Volatility',    pip: 4 },
  { symbol: 'R_100',     displayName: 'Volatility 100 Index',       category: 'Volatility',    pip: 2 },
  { symbol: '1HZ10V',    displayName: 'Volatility 10 (1s) Index',   category: 'Volatility 1s', pip: 3 },
  { symbol: '1HZ25V',    displayName: 'Volatility 25 (1s) Index',   category: 'Volatility 1s', pip: 3 },
  { symbol: '1HZ50V',    displayName: 'Volatility 50 (1s) Index',   category: 'Volatility 1s', pip: 4 },
  { symbol: '1HZ75V',    displayName: 'Volatility 75 (1s) Index',   category: 'Volatility 1s', pip: 4 },
  { symbol: '1HZ100V',   displayName: 'Volatility 100 (1s) Index',  category: 'Volatility 1s', pip: 2 },
  { symbol: 'BOOM500',   displayName: 'Boom 500 Index',             category: 'Crash/Boom',    pip: 2 },
  { symbol: 'BOOM1000',  displayName: 'Boom 1000 Index',            category: 'Crash/Boom',    pip: 2 },
  { symbol: 'CRASH500',  displayName: 'Crash 500 Index',            category: 'Crash/Boom',    pip: 2 },
  { symbol: 'CRASH1000', displayName: 'Crash 1000 Index',           category: 'Crash/Boom',    pip: 2 },
];

export type OAuthAccount = {
  loginid: string;
  token: string;
  is_virtual: boolean;
  account_type?: string;
  currency?: string;
};

type MsgHandler = (data: Record<string, unknown>) => void;
type AccountListener = (acc: DerivAccount | null) => void;
type BalanceListener = (bal: number) => void;
type AccountsListener = (accounts: OAuthAccount[]) => void;

class DerivAPIClient {
  private ws: WebSocket | null = null;
  private reqId = 1;
  private pending = new Map<number, (d: Record<string, unknown>) => void>();
  private subs = new Map<string, MsgHandler[]>();
  private connectingPromise: Promise<void> | null = null;
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private _connected = false;
  private _token: string | null = null;
  private _account: DerivAccount | null = null;
  private _oauthAccounts: OAuthAccount[] = [];
  private _accountListeners: AccountListener[] = [];
  private _balanceListeners: BalanceListener[] = [];
  private _accountsListeners: AccountsListener[] = [];

  // ─── Connection ──────────────────────────────────────────────────────────────

  async connect(): Promise<void> {
    if (this._connected && this.ws?.readyState === WebSocket.OPEN) return;
    if (this.connectingPromise) return this.connectingPromise;

    this.connectingPromise = new Promise((resolve, reject) => {
      try {
        this.ws = new WebSocket(`wss://ws.derivws.com/websockets/v3?app_id=${APP_ID}&l=EN&brand=deriv`);

        this.ws.onopen = () => {
          this._connected = true;
          this.connectingPromise = null;
          resolve();
          if (this._token) this._doAuthorize(this._token).catch(() => {});
        };

        this.ws.onmessage = (ev) => {
          try {
            const data = JSON.parse(ev.data) as Record<string, unknown>;
            const rid = data.req_id as number | undefined;
            if (rid && this.pending.has(rid)) {
              this.pending.get(rid)!(data);
              this.pending.delete(rid);
            }
            const mt = data.msg_type as string | undefined;
            if (mt) this.subs.get(mt)?.forEach(h => h(data));
          } catch {}
        };

        this.ws.onerror = () => {
          this._connected = false;
          this.connectingPromise = null;
          reject(new Error('WebSocket error'));
        };

        this.ws.onclose = () => {
          this._connected = false;
          this.connectingPromise = null;
          this._scheduleReconnect();
        };
      } catch (e) {
        this.connectingPromise = null;
        reject(e);
      }
    });

    return this.connectingPromise;
  }

  private _scheduleReconnect() {
    if (this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect().catch(() => {});
    }, 3000);
  }

  // ─── Low-level send ───────────────────────────────────────────────────────────

  send<T = Record<string, unknown>>(payload: Record<string, unknown>, timeoutMs = 15000): Promise<T> {
    return new Promise(async (resolve, reject) => {
      try { await this.connect(); } catch (e) { return reject(e); }

      const id = this.reqId++;
      const t = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Timeout: ${JSON.stringify(payload)}`));
      }, timeoutMs);

      this.pending.set(id, (data) => {
        clearTimeout(t);
        if (data.error) {
          const e = data.error as { message: string; code: string };
          reject(new Error(`${e.code}: ${e.message}`));
        } else {
          resolve(data as T);
        }
      });

      this.ws!.send(JSON.stringify({ ...payload, req_id: id }));
    });
  }

  subscribe(msgType: string, handler: MsgHandler): () => void {
    if (!this.subs.has(msgType)) this.subs.set(msgType, []);
    this.subs.get(msgType)!.push(handler);
    return () => {
      const arr = this.subs.get(msgType);
      if (!arr) return;
      const i = arr.indexOf(handler);
      if (i > -1) arr.splice(i, 1);
    };
  }

  // ─── Authentication ───────────────────────────────────────────────────────────

  async _doAuthorize(token: string): Promise<DerivAccount> {
    type AuthRes = {
      authorize?: {
        loginid: string; email: string; fullname: string;
        currency: string; balance: number;
        account_list?: { loginid: string; is_virtual: boolean; token?: string; currency?: string }[];
      };
      error?: { message: string; code: string };
    };

    const data = await this.send<AuthRes>({ authorize: token });
    if (!data.authorize) throw new Error('Authorization failed');

    const a = data.authorize;
    const acctEntry = a.account_list?.find(x => x.loginid === a.loginid);
    const isVirtual = acctEntry?.is_virtual ?? false;

    const acc: DerivAccount = {
      loginid: a.loginid,
      email: a.email,
      fullname: a.fullname,
      currency: a.currency,
      balance: a.balance,
      is_virtual: isVirtual,
      token,
    };

    this._account = acc;
    this._accountListeners.forEach(fn => fn(acc));

    // Subscribe to live balance updates
    this.send({ balance: 1, subscribe: 1 }).catch(() => {});
    this.subscribe('balance', (d) => {
      const b = (d as { balance?: { balance: number } }).balance;
      if (b && this._account) {
        this._account.balance = b.balance;
        this._balanceListeners.forEach(fn => fn(b.balance));
      }
    });

    return acc;
  }

  async login(token: string): Promise<DerivAccount> {
    this._token = token.trim();
    localStorage.setItem('deriv_api_token', this._token);
    await this.connect();
    return this._doAuthorize(this._token);
  }

  // OAuth: authorize multiple accounts at once and switch to the best one
  async loginWithOAuthAccounts(accounts: OAuthAccount[]): Promise<DerivAccount> {
    this._oauthAccounts = accounts;
    localStorage.setItem('deriv_oauth_accounts', JSON.stringify(accounts));

    // Prefer real account; fallback to first
    const preferred = accounts.find(a => !a.is_virtual) ?? accounts[0];
    this._token = preferred.token;
    localStorage.setItem('deriv_api_token', this._token);

    await this.connect();
    const acc = await this._doAuthorize(this._token);
    this._accountsListeners.forEach(fn => fn(accounts));
    return acc;
  }

  async switchAccount(loginid: string): Promise<DerivAccount> {
    const target = this._oauthAccounts.find(a => a.loginid === loginid);
    if (!target) throw new Error('Account not found');
    this._token = target.token;
    localStorage.setItem('deriv_api_token', this._token);
    const acc = await this._doAuthorize(this._token);
    return acc;
  }

  logout() {
    this._token = null;
    this._account = null;
    this._oauthAccounts = [];
    localStorage.removeItem('deriv_api_token');
    localStorage.removeItem('deriv_oauth_accounts');
    this._accountListeners.forEach(fn => fn(null));
    this._accountsListeners.forEach(fn => fn([]));
  }

  async restoreSession(): Promise<DerivAccount | null> {
    // Try restoring OAuth accounts first
    const savedOAuth = localStorage.getItem('deriv_oauth_accounts');
    if (savedOAuth) {
      try {
        const accounts: OAuthAccount[] = JSON.parse(savedOAuth);
        if (accounts.length > 0) {
          this._oauthAccounts = accounts;
          this._accountsListeners.forEach(fn => fn(accounts));
        }
      } catch {}
    }

    const saved = localStorage.getItem('deriv_api_token');
    if (!saved) return null;
    try {
      this._token = saved;
      await this.connect();
      return await this._doAuthorize(saved);
    } catch {
      localStorage.removeItem('deriv_api_token');
      this._token = null;
      return null;
    }
  }

  getAccount(): DerivAccount | null { return this._account; }
  getOAuthAccounts(): OAuthAccount[] { return this._oauthAccounts; }
  isAuthenticated(): boolean { return !!this._account; }

  onAccountChange(fn: AccountListener): () => void {
    this._accountListeners.push(fn);
    return () => { this._accountListeners = this._accountListeners.filter(f => f !== fn); };
  }

  onBalanceChange(fn: BalanceListener): () => void {
    this._balanceListeners.push(fn);
    return () => { this._balanceListeners = this._balanceListeners.filter(f => f !== fn); };
  }

  onAccountsChange(fn: AccountsListener): () => void {
    this._accountsListeners.push(fn);
    return () => { this._accountsListeners = this._accountsListeners.filter(f => f !== fn); };
  }

  // ─── Market data ─────────────────────────────────────────────────────────────

  async getTicks(symbol: string): Promise<string> {
    const d = await this.send<Record<string, unknown>>({ ticks: symbol, subscribe: 1 });
    return (d.subscription as { id: string } | undefined)?.id || '';
  }

  async getTicksHistory(symbol: string, count = 200): Promise<{ prices: number[]; times: number[] }> {
    const d = await this.send<{ history?: { prices: number[]; times: number[] } }>({
      ticks_history: symbol, adjust_start_time: 1, count, end: 'latest', style: 'ticks',
    });
    return d.history || { prices: [], times: [] };
  }

  async getCandles(symbol: string, granularity = 60): Promise<DerivCandle[]> {
    const d = await this.send<{ candles?: DerivCandle[] }>({
      ticks_history: symbol, adjust_start_time: 1, count: 100, end: 'latest', granularity, style: 'candles',
    });
    return d.candles || [];
  }

  // ─── Trading ─────────────────────────────────────────────────────────────────

  async buyContract(params: {
    symbol: string;
    contractType: string;
    duration: number;
    durationUnit: string;
    amount: number;
    basis: string;
    currency?: string;
    barrier?: string;
    prediction?: number;
  }): Promise<{
    buy: {
      contract_id: number;
      buy_price: number;
      payout: number;
      start_time: number;
      transaction_id: number;
      shortcode: string;
      longcode: string;
      spot?: number;
    };
  }> {
    if (!this._account) throw new Error('NOT_AUTHENTICATED: No active Deriv session');

    const parameters: Record<string, unknown> = {
      amount: params.amount,
      basis: params.basis,
      contract_type: params.contractType,
      currency: params.currency || this._account.currency,
      duration: params.duration,
      duration_unit: params.durationUnit,
      symbol: params.symbol,
    };
    if (params.barrier) parameters['barrier'] = params.barrier;
    if (params.prediction !== undefined) parameters['selected_tick'] = params.prediction;

    return this.send({
      buy: 1,
      price: params.amount,
      parameters,
    });
  }

  async getContractDetails(contractId: number): Promise<DerivContract> {
    const d = await this.send<{ proposal_open_contract?: DerivContract }>({
      proposal_open_contract: 1,
      contract_id: contractId,
    });
    return d.proposal_open_contract as DerivContract;
  }

  subscribeToContract(contractId: number): () => void {
    this.send({ proposal_open_contract: 1, contract_id: contractId, subscribe: 1 }).catch(() => {});
    return () => {
      this.send({ forget_all: 'proposal_open_contract' }).catch(() => {});
    };
  }

  async sellContract(contractId: number, price = 0): Promise<unknown> {
    return this.send({ sell: contractId, price });
  }

  // ─── Utilities ────────────────────────────────────────────────────────────────

  isConnected(): boolean {
    return this._connected && this.ws?.readyState === WebSocket.OPEN;
  }

  async getActiveSymbols() {
    return this.send({ active_symbols: 'brief', product_type: 'basic' });
  }

  // Build the OAuth URL
  getOAuthUrl(): string {
    const redirect = encodeURIComponent(window.location.origin + window.location.pathname);
    return `https://oauth.deriv.com/oauth2/authorize?app_id=${APP_ID}&l=EN&brand=deriv&redirect_uri=${redirect}`;
  }
}

export const derivAPI = new DerivAPIClient();
