export type AIAnalysis = {
  signal: 'CALL' | 'PUT' | 'NEUTRAL';
  confidence: number;
  reasoning: string[];
  indicators: {
    rsi: number;
    macd: { value: number; signal: number; histogram: number };
    bollinger: { upper: number; middle: number; lower: number; position: number };
    trend: 'UP' | 'DOWN' | 'SIDEWAYS';
    momentum: number;
    volatility: number;
    trendStrength: number;
    candleDirection: 'BULLISH' | 'BEARISH' | 'NEUTRAL';
  };
};

export type ScanResult = {
  symbol: string;
  displayName: string;
  analysis: AIAnalysis;
  score: number;
};

function calcSMA(prices: number[], period: number): number {
  if (prices.length < period) return prices[prices.length - 1] || 0;
  const slice = prices.slice(-period);
  return slice.reduce((a, b) => a + b, 0) / period;
}

function calcEMA(prices: number[], period: number): number {
  if (prices.length === 0) return 0;
  const k = 2 / (period + 1);
  let ema = prices[0];
  for (let i = 1; i < prices.length; i++) {
    ema = prices[i] * k + ema * (1 - k);
  }
  return ema;
}

function calcRSI(prices: number[], period = 14): number {
  if (prices.length < period + 1) return 50;
  const changes = prices.slice(1).map((p, i) => p - prices[i]);
  const gains = changes.map(c => (c > 0 ? c : 0));
  const losses = changes.map(c => (c < 0 ? -c : 0));
  const avgGain = gains.slice(-period).reduce((a, b) => a + b, 0) / period;
  const avgLoss = losses.slice(-period).reduce((a, b) => a + b, 0) / period;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - 100 / (1 + rs);
}

function calcMACD(prices: number[]) {
  const macdLine: number[] = [];
  for (let i = 0; i < prices.length; i++) {
    const slice = prices.slice(0, i + 1);
    macdLine.push(calcEMA(slice, 12) - calcEMA(slice, 26));
  }
  const signal = calcEMA(macdLine, 9);
  const value = macdLine[macdLine.length - 1] || 0;
  return { value, signal, histogram: value - signal };
}

function calcBollinger(prices: number[], period = 20, stdDev = 2) {
  const middle = calcSMA(prices, period);
  const slice = prices.slice(-period);
  const variance = slice.reduce((sum, p) => sum + Math.pow(p - middle, 2), 0) / period;
  const std = Math.sqrt(variance);
  const upper = middle + stdDev * std;
  const lower = middle - stdDev * std;
  const current = prices[prices.length - 1];
  const position = upper === lower ? 0.5 : (current - lower) / (upper - lower);
  return { upper, middle, lower, position };
}

function calcTrendStrength(prices: number[]): number {
  if (prices.length < 10) return 0;
  const sma5 = calcSMA(prices, 5);
  const sma10 = calcSMA(prices, Math.min(10, prices.length));
  const sma20 = calcSMA(prices, Math.min(20, prices.length));
  const aligned = (sma5 > sma10 && sma10 > sma20) || (sma5 < sma10 && sma10 < sma20);
  const spread = Math.abs(sma5 - sma20) / sma20 * 100;
  return aligned ? Math.min(100, spread * 50) : spread * 10;
}

function calcCandleDirection(prices: number[]): 'BULLISH' | 'BEARISH' | 'NEUTRAL' {
  if (prices.length < 5) return 'NEUTRAL';
  const recent = prices.slice(-5);
  const opens = recent.slice(0, -1);
  const closes = recent.slice(1);
  let bullCount = 0, bearCount = 0;
  opens.forEach((o, i) => {
    if (closes[i] > o) bullCount++;
    else if (closes[i] < o) bearCount++;
  });
  if (bullCount >= 3) return 'BULLISH';
  if (bearCount >= 3) return 'BEARISH';
  return 'NEUTRAL';
}

export function analyzeMarket(prices: number[]): AIAnalysis {
  if (prices.length < 30) {
    return {
      signal: 'NEUTRAL',
      confidence: 0,
      reasoning: ['Insufficient data for analysis'],
      indicators: {
        rsi: 50,
        macd: { value: 0, signal: 0, histogram: 0 },
        bollinger: { upper: 0, middle: 0, lower: 0, position: 0.5 },
        trend: 'SIDEWAYS',
        momentum: 0,
        volatility: 0,
        trendStrength: 0,
        candleDirection: 'NEUTRAL',
      },
    };
  }

  const rsi = calcRSI(prices);
  const macd = calcMACD(prices);
  const bollinger = calcBollinger(prices);
  const trendStrength = calcTrendStrength(prices);
  const candleDirection = calcCandleDirection(prices);

  const recent10 = prices.slice(-10);
  const momentum = ((recent10[recent10.length - 1] - recent10[0]) / recent10[0]) * 100;

  const slice20 = prices.slice(-20);
  const avg = slice20.reduce((a, b) => a + b, 0) / slice20.length;
  const volatility = Math.sqrt(slice20.reduce((sum, p) => sum + Math.pow(p - avg, 2), 0) / slice20.length) / avg * 100;

  const sma5 = calcSMA(prices, 5);
  const sma20 = calcSMA(prices, 20);
  const trend: 'UP' | 'DOWN' | 'SIDEWAYS' = sma5 > sma20 * 1.001 ? 'UP' : sma5 < sma20 * 0.999 ? 'DOWN' : 'SIDEWAYS';

  let callScore = 0;
  let putScore = 0;
  const reasoning: string[] = [];

  // RSI
  if (rsi < 25) { callScore += 28; reasoning.push('RSI deeply oversold — strong reversal signal'); }
  else if (rsi < 35) { callScore += 20; reasoning.push('RSI oversold — potential upward reversal'); }
  else if (rsi > 75) { putScore += 28; reasoning.push('RSI deeply overbought — strong reversal signal'); }
  else if (rsi > 65) { putScore += 20; reasoning.push('RSI overbought — potential downward reversal'); }
  else if (rsi < 48) { callScore += 8; }
  else if (rsi > 52) { putScore += 8; }

  // MACD
  if (macd.histogram > 0 && macd.value > 0) { callScore += 22; reasoning.push('MACD bullish crossover confirmed'); }
  else if (macd.histogram < 0 && macd.value < 0) { putScore += 22; reasoning.push('MACD bearish crossover confirmed'); }
  else if (macd.histogram > 0) { callScore += 12; reasoning.push('MACD histogram turning bullish'); }
  else if (macd.histogram < 0) { putScore += 12; reasoning.push('MACD histogram turning bearish'); }

  // Bollinger
  if (bollinger.position < 0.05) { callScore += 22; reasoning.push('Price at Bollinger lower band — mean reversion setup'); }
  else if (bollinger.position < 0.15) { callScore += 15; reasoning.push('Price near lower Bollinger Band'); }
  else if (bollinger.position > 0.95) { putScore += 22; reasoning.push('Price at Bollinger upper band — mean reversion setup'); }
  else if (bollinger.position > 0.85) { putScore += 15; reasoning.push('Price near upper Bollinger Band'); }

  // Trend
  if (trend === 'UP') { callScore += 15; reasoning.push('Uptrend confirmed by MA alignment'); }
  else if (trend === 'DOWN') { putScore += 15; reasoning.push('Downtrend confirmed by MA alignment'); }

  // Trend strength bonus
  if (trendStrength > 50) {
    if (trend === 'UP') { callScore += 10; reasoning.push(`Strong trend momentum (${trendStrength.toFixed(0)}%)`); }
    else if (trend === 'DOWN') { putScore += 10; }
  }

  // Momentum
  if (momentum > 0.15) { callScore += 12; reasoning.push('Strong positive price momentum detected'); }
  else if (momentum > 0.05) { callScore += 6; }
  else if (momentum < -0.15) { putScore += 12; reasoning.push('Strong negative price momentum detected'); }
  else if (momentum < -0.05) { putScore += 6; }

  // Candle direction
  if (candleDirection === 'BULLISH') { callScore += 8; reasoning.push('Consecutive bullish candles — momentum building'); }
  else if (candleDirection === 'BEARISH') { putScore += 8; reasoning.push('Consecutive bearish candles — momentum building'); }

  const total = callScore + putScore;
  let signal: 'CALL' | 'PUT' | 'NEUTRAL' = 'NEUTRAL';
  let confidence = 0;

  if (total > 0) {
    if (callScore > putScore && callScore > 35) {
      signal = 'CALL';
      confidence = Math.min(95, 40 + (callScore / total) * 60);
    } else if (putScore > callScore && putScore > 35) {
      signal = 'PUT';
      confidence = Math.min(95, 40 + (putScore / total) * 60);
    } else {
      signal = 'NEUTRAL';
      confidence = 40 + (Math.max(callScore, putScore) / total) * 20;
      if (!reasoning.some(r => r.includes('Mixed'))) reasoning.push('Mixed signals — market indecision');
    }
  }

  if (reasoning.length === 0) reasoning.push('No decisive technical setup found');

  return {
    signal,
    confidence: Math.round(confidence),
    reasoning,
    indicators: { rsi, macd, bollinger, trend, momentum, volatility, trendStrength, candleDirection },
  };
}
