import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Trade = {
  id: string;
  user_id: string;
  symbol: string;
  contract_type: string;
  stake: number;
  payout: number | null;
  entry_price: number | null;
  exit_price: number | null;
  result: string;
  profit_loss: number;
  duration: number;
  reference_id: string | null;
  created_at: string;
  closed_at: string | null;
  barrier: number | null;
  prediction: number | null;
  strategy_type: string | null;
};

export type AISignal = {
  id: string;
  symbol: string;
  signal_type: string;
  confidence: number;
  reasoning: string | null;
  indicators: Record<string, unknown>;
  created_at: string;
};
