import { useEffect, useRef, useState } from 'react';
import { TrendingUp, TrendingDown, X, RotateCcw, CheckCircle2, XCircle, Zap } from 'lucide-react';
import { AIAnalysis } from '../lib/aiEngine';

type Props = {
  result: 'won' | 'lost';
  profitLoss: number;
  stake: number;
  symbol: string;
  contractType: string;
  entryPrice?: number | null;
  exitPrice?: number | null;
  analysis: AIAnalysis | null;
  onClose: () => void;
  onRetrade: () => void;
};

const CT_LABEL: Record<string, string> = {
  CALL: 'RISE', PUT: 'FALL',
  EVEN: 'EVEN', ODD: 'ODD',
  DIGITMATCH: 'MATCHES', DIGITDIFF: 'DIFFERS',
  DIGITOVER: 'OVER', DIGITUNDER: 'UNDER',
};

export default function TradeResultModal({
  result, profitLoss, stake, symbol, contractType,
  entryPrice, exitPrice, analysis, onClose, onRetrade,
}: Props) {
  const confettiRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const [phase, setPhase] = useState<'flash' | 'panel'>('flash');
  const [panelVisible, setPanelVisible] = useState(false);

  const isWon = result === 'won';
  const pct = stake > 0 ? Math.abs((profitLoss / stake) * 100) : 0;
  const accentColor = isWon ? '#10b981' : '#ef4444';
  const accentRGB   = isWon ? '16,185,129' : '239,68,68';

  // Flash → panel transition
  useEffect(() => {
    const t1 = setTimeout(() => setPhase('panel'), isWon ? 700 : 500);
    const t2 = setTimeout(() => setPanelVisible(true), isWon ? 750 : 550);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [isWon]);

  // Confetti for wins
  useEffect(() => {
    if (!isWon || phase !== 'panel') return;
    const canvas = confettiRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    type Piece = { x: number; y: number; r: number; vx: number; vy: number; color: string; rot: number; rv: number; shape: 'rect' | 'circle' | 'triangle' };
    const colors = ['#10b981', '#06b6d4', '#34d399', '#22d3ee', '#f59e0b', '#a3e635', '#38bdf8'];
    const pieces: Piece[] = Array.from({ length: 90 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height * 0.5 - 60,
      r: Math.random() * 5 + 3,
      vx: (Math.random() - 0.5) * 3,
      vy: Math.random() * 3 + 1,
      color: colors[Math.floor(Math.random() * colors.length)],
      rot: Math.random() * 360,
      rv: (Math.random() - 0.5) * 10,
      shape: (['rect', 'circle', 'triangle'] as Piece['shape'][])[Math.floor(Math.random() * 3)],
    }));

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      pieces.forEach(p => {
        p.x += p.vx; p.y += p.vy; p.vy += 0.05; p.rot += p.rv;
        if (p.y > canvas.height + 10) { p.y = -10; p.x = Math.random() * canvas.width; p.vy = Math.random() * 2 + 1; }
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rot * Math.PI) / 180);
        ctx.globalAlpha = 0.9;
        ctx.fillStyle = p.color;
        if (p.shape === 'rect') {
          ctx.fillRect(-p.r * 0.5, -p.r * 1.2, p.r, p.r * 2.4);
        } else if (p.shape === 'circle') {
          ctx.beginPath(); ctx.arc(0, 0, p.r, 0, Math.PI * 2); ctx.fill();
        } else {
          ctx.beginPath(); ctx.moveTo(0, -p.r); ctx.lineTo(p.r, p.r); ctx.lineTo(-p.r, p.r); ctx.closePath(); ctx.fill();
        }
        ctx.restore();
      });
      rafRef.current = requestAnimationFrame(draw);
    };
    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [isWon, phase]);

  // Red particles for loss
  useEffect(() => {
    if (isWon || phase !== 'panel') return;
    const canvas = particlesRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    type Particle = { x: number; y: number; r: number; vy: number; vx: number; opacity: number; life: number };
    const particles: Particle[] = Array.from({ length: 40 }, () => ({
      x: Math.random() * canvas.width,
      y: canvas.height + 10,
      r: Math.random() * 3 + 1,
      vx: (Math.random() - 0.5) * 1.5,
      vy: -(Math.random() * 2 + 1),
      opacity: 0.7,
      life: 1,
    }));

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy; p.life -= 0.006;
        if (p.life <= 0) { p.y = canvas.height + 10; p.x = Math.random() * canvas.width; p.life = 1; p.vy = -(Math.random() * 2 + 1); }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(239,68,68,${p.life * 0.5})`;
        ctx.fill();
      });
      rafRef.current = requestAnimationFrame(draw);
    };
    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [isWon, phase]);

  const handleClose = () => {
    setPanelVisible(false);
    setTimeout(onClose, 200);
  };

  return (
    <div className="fixed inset-0 z-50">
      {/* ── PHASE 1: Full-screen flash ── */}
      {phase === 'flash' && (
        <div
          className="absolute inset-0 flex flex-col items-center justify-center"
          style={{
            background: isWon
              ? 'radial-gradient(ellipse at center, rgba(16,185,129,0.35) 0%, rgba(5,8,16,0.97) 70%)'
              : 'radial-gradient(ellipse at center, rgba(239,68,68,0.35) 0%, rgba(5,8,16,0.97) 70%)',
            animation: 'flashPulse 0.5s ease-out',
          }}>
          <style>{`
            @keyframes flashPulse {
              0% { opacity: 0; transform: scale(1.04); }
              30% { opacity: 1; transform: scale(1); }
              100% { opacity: 1; }
            }
            @keyframes popIn {
              0%  { opacity: 0; transform: scale(0.7) translateY(20px); }
              60% { transform: scale(1.06) translateY(-4px); }
              100%{ opacity: 1; transform: scale(1) translateY(0); }
            }
            @keyframes shimmer {
              0% { background-position: -200% center; }
              100% { background-position: 200% center; }
            }
          `}</style>

          <div className="text-center" style={{ animation: 'popIn 0.45s cubic-bezier(0.34,1.56,0.64,1) forwards' }}>
            <div className="flex justify-center mb-4">
              {isWon
                ? <CheckCircle2 size={80} style={{ color: '#10b981', filter: 'drop-shadow(0 0 30px #10b981)' }} />
                : <XCircle size={80} style={{ color: '#ef4444', filter: 'drop-shadow(0 0 30px #ef4444)' }} />}
            </div>
            <h1 className="text-6xl font-black tracking-tight mb-2"
              style={{
                color: accentColor,
                textShadow: `0 0 40px ${accentColor}, 0 0 80px ${accentColor}60`,
                background: `linear-gradient(135deg, ${accentColor}, white, ${accentColor})`,
                backgroundSize: '200% auto',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                animation: 'shimmer 1.5s linear infinite',
              }}>
              {isWon ? 'PROFIT!' : 'LOSS!'}
            </h1>
            <p className="text-2xl font-black font-mono"
              style={{ color: accentColor, textShadow: `0 0 20px ${accentColor}70` }}>
              {isWon ? '+' : '-'}${Math.abs(profitLoss).toFixed(2)}
            </p>
          </div>
        </div>
      )}

      {/* ── PHASE 2: Detail panel ── */}
      {phase === 'panel' && (
        <div className="absolute inset-0 flex items-center justify-center p-4">
          {/* Backdrop */}
          <div
            className="absolute inset-0 transition-opacity duration-300"
            style={{
              background: isWon
                ? 'radial-gradient(ellipse at 50% 30%, rgba(16,185,129,0.12) 0%, rgba(0,0,0,0.85) 60%)'
                : 'radial-gradient(ellipse at 50% 30%, rgba(239,68,68,0.12) 0%, rgba(0,0,0,0.85) 60%)',
              backdropFilter: 'blur(12px)',
              opacity: panelVisible ? 1 : 0,
            }}
            onClick={handleClose}
          />

          {/* Particle canvases */}
          {isWon && <canvas ref={confettiRef} className="absolute inset-0 w-full h-full pointer-events-none z-10" />}
          {!isWon && <canvas ref={particlesRef} className="absolute inset-0 w-full h-full pointer-events-none z-10" />}

          {/* Card */}
          <div
            className="relative z-20 w-full max-w-sm overflow-hidden"
            style={{
              transform: panelVisible ? 'scale(1) translateY(0)' : 'scale(0.88) translateY(24px)',
              opacity: panelVisible ? 1 : 0,
              transition: 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
              borderRadius: '22px',
              background: `rgba(8,12,24,0.98)`,
              border: `1px solid ${accentColor}30`,
              boxShadow: `0 0 0 1px rgba(${accentRGB},0.08), 0 0 60px rgba(${accentRGB},0.18), 0 24px 80px rgba(0,0,0,0.7)`,
            }}>

            {/* Glow strip top */}
            <div className="h-1 w-full"
              style={{ background: `linear-gradient(90deg, transparent, ${accentColor}, transparent)` }} />

            {/* Corner glow */}
            <div className="absolute top-0 left-0 w-32 h-32 pointer-events-none"
              style={{ background: `radial-gradient(circle at 0 0, ${accentColor}12, transparent 70%)` }} />
            <div className="absolute top-0 right-0 w-32 h-32 pointer-events-none"
              style={{ background: `radial-gradient(circle at 100% 0, ${accentColor}12, transparent 70%)` }} />

            <div className="p-5 relative">
              {/* Close */}
              <button onClick={handleClose}
                className="absolute top-4 right-4 p-1.5 rounded-lg transition-colors z-10"
                style={{ color: '#475569' }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.07)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                <X size={14} />
              </button>

              {/* Icon + title */}
              <div className="flex items-center gap-4 mb-5">
                <div className="relative shrink-0">
                  <div className="w-16 h-16 rounded-2xl flex items-center justify-center"
                    style={{ background: `rgba(${accentRGB},0.12)`, border: `1px solid ${accentColor}30` }}>
                    {isWon
                      ? <TrendingUp size={28} style={{ color: accentColor }} />
                      : <TrendingDown size={28} style={{ color: accentColor }} />}
                  </div>
                  {isWon && (
                    <div className="absolute inset-0 rounded-2xl"
                      style={{ border: `2px solid ${accentColor}40`, animation: 'ping 1.5s cubic-bezier(0,0,0.2,1) infinite' }} />
                  )}
                </div>
                <div>
                  <h2 className="text-2xl font-black leading-none"
                    style={{ color: accentColor, textShadow: `0 0 20px ${accentColor}50` }}>
                    TRADE {isWon ? 'WON' : 'LOST'}
                  </h2>
                  <p className="text-xs font-mono mt-1" style={{ color: '#475569' }}>
                    {symbol} · {CT_LABEL[contractType] ?? contractType}
                  </p>
                </div>
              </div>

              {/* P&L */}
              <div className="rounded-2xl px-5 py-4 text-center mb-3"
                style={{ background: `rgba(${accentRGB},0.07)`, border: `1px solid ${accentColor}18` }}>
                <p className="text-2xs mb-1.5 font-bold uppercase tracking-widest" style={{ color: accentColor + '99' }}>
                  {isWon ? 'Profit' : 'Loss'}
                </p>
                <p className="text-5xl font-black font-mono leading-none mb-1.5"
                  style={{ color: accentColor, textShadow: `0 0 30px ${accentColor}50` }}>
                  {isWon ? '+' : '-'}${Math.abs(profitLoss).toFixed(2)}
                </p>
                <p className="text-sm font-semibold" style={{ color: accentColor + 'aa' }}>
                  {isWon ? '+' : '-'}{pct.toFixed(1)}% on ${stake.toFixed(2)} stake
                </p>
              </div>

              {/* Entry / Exit spots */}
              {(entryPrice || exitPrice) && (
                <div className="grid grid-cols-2 gap-2 mb-3">
                  {entryPrice !== null && entryPrice !== undefined && (
                    <div className="px-3 py-2.5 rounded-xl text-center"
                      style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                      <p className="text-2xs mb-1 font-semibold uppercase" style={{ color: '#334155' }}>Entry Spot</p>
                      <p className="text-sm font-mono font-bold" style={{ color: '#94a3b8' }}>
                        {entryPrice.toFixed(4)}
                      </p>
                    </div>
                  )}
                  {exitPrice !== null && exitPrice !== undefined && (
                    <div className="px-3 py-2.5 rounded-xl text-center"
                      style={{ background: `rgba(${accentRGB},0.06)`, border: `1px solid ${accentColor}18` }}>
                      <p className="text-2xs mb-1 font-semibold uppercase" style={{ color: '#334155' }}>Exit Spot</p>
                      <p className="text-sm font-mono font-bold" style={{ color: accentColor }}>
                        {exitPrice.toFixed(4)}
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* AI analysis */}
              {analysis && (
                <div className="rounded-xl px-4 py-3 mb-4"
                  style={{
                    background: isWon ? 'rgba(16,185,129,0.05)' : 'rgba(255,255,255,0.025)',
                    border: isWon ? '1px solid rgba(16,185,129,0.12)' : '1px solid rgba(255,255,255,0.05)',
                  }}>
                  <div className="flex items-center gap-1.5 mb-2">
                    <Zap size={10} style={{ color: isWon ? '#10b981' : '#475569' }} />
                    <p className="text-2xs font-bold uppercase tracking-widest"
                      style={{ color: isWon ? '#10b981' : '#475569' }}>
                      AI Signal · {analysis.confidence}% confidence
                    </p>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mb-2">
                    <MiniStat label="RSI" value={analysis.indicators.rsi.toFixed(1)} />
                    <MiniStat label="Trend" value={analysis.indicators.trend} />
                    <MiniStat label="MACD" value={analysis.indicators.macd.histogram > 0 ? 'BULL' : 'BEAR'} />
                  </div>
                  {analysis.reasoning.slice(0, 2).map((r, i) => (
                    <p key={i} className="text-2xs leading-relaxed" style={{ color: '#475569' }}>• {r}</p>
                  ))}
                </div>
              )}

              {/* Actions */}
              <div className="grid grid-cols-2 gap-2">
                <button onClick={handleClose}
                  className="py-3 rounded-xl text-sm font-semibold transition-all"
                  style={{ background: 'rgba(255,255,255,0.04)', color: '#64748b', border: '1px solid rgba(255,255,255,0.07)' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.07)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.04)')}>
                  Close
                </button>
                <button
                  onClick={() => { handleClose(); setTimeout(onRetrade, 250); }}
                  className="py-3 rounded-xl text-sm font-bold flex items-center justify-center gap-1.5 transition-all active:scale-95"
                  style={{
                    background: `linear-gradient(135deg, ${isWon ? '#059669' : '#0891b2'}, ${isWon ? '#10b981' : '#06b6d4'})`,
                    color: '#fff',
                    boxShadow: `0 0 18px ${isWon ? 'rgba(16,185,129,0.3)' : 'rgba(6,182,212,0.3)'}`,
                  }}>
                  <RotateCcw size={13} />
                  Trade Again
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="text-center">
      <p className="text-2xs mb-0.5" style={{ color: '#334155' }}>{label}</p>
      <p className="text-xs font-bold font-mono" style={{ color: '#94a3b8' }}>{value}</p>
    </div>
  );
}
