import { useState, useRef, useEffect } from 'react';
import { VOLATILITY_INDICES } from '../lib/derivApi';
import { AIAnalysis } from '../lib/aiEngine';
import { Trade } from '../lib/supabase';
import {
  TrendingUp, TrendingDown, Bot, KeyRound,
  Hash, ArrowUpDown, Equal, Shuffle, ChevronDown,
  ToggleLeft, ToggleRight, DollarSign, Target, ShieldOff,
  Repeat2, Clock, List,
} from 'lucide-react';

export type StrategyType = 'rise_fall' | 'even_odd' | 'matches_differs' | 'over_under';

export type TradeRequest = Omit<Trade, 'id' | 'user_id' | 'created_at'> & {
  strategyType: StrategyType;
  takeProfit?: number;
  maxLosses?: number;
  stopLoss?: number;
  martingale?: boolean;
  martingaleMultiplier?: number;
  stakeList?: number[];
};

type Props = {
  selectedSymbol: string;
  currentPrice: number | null;
  analysis: AIAnalysis | null;
  autoTrade: boolean;
  onAutoTradeToggle: (v: boolean) => void;
  onTradePlaced: (t: TradeRequest) => void;
  disabled?: boolean;
  isAuthenticated?: boolean;
  onConnectDeriv?: () => void;
};

const STRATEGIES: { id: StrategyType; label: string; icon: React.ReactNode }[] = [
  { id: 'rise_fall',       label: 'Rise / Fall',       icon: <ArrowUpDown size={13} /> },
  { id: 'even_odd',        label: 'Even / Odd',        icon: <Hash size={13} /> },
  { id: 'matches_differs', label: 'Matches / Differs', icon: <Equal size={13} /> },
  { id: 'over_under',      label: 'Over / Under',      icon: <Shuffle size={13} /> },
];

const DURATIONS = [
  { label: '1m',  value: 1,  unit: 'm' },
  { label: '3m',  value: 3,  unit: 'm' },
  { label: '5m',  value: 5,  unit: 'm' },
  { label: '15m', value: 15, unit: 'm' },
  { label: '1h',  value: 1,  unit: 'h' },
];

const TICK_OPTIONS = [1, 2, 3, 4, 5];

/* ── small reusable toggle row ─────────────────────────────────── */
function ToggleRow({
  icon, label, enabled, onToggle, children,
}: {
  icon: React.ReactNode;
  label: string;
  enabled: boolean;
  onToggle: () => void;
  children?: React.ReactNode;
}) {
  return (
    <div className="rounded-xl overflow-hidden"
      style={{
        border: enabled ? '1px solid rgba(16,185,129,0.22)' : '1px solid rgba(255,255,255,0.07)',
        background: enabled ? 'rgba(16,185,129,0.04)' : 'rgba(255,255,255,0.02)',
      }}>
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-2.5 px-3 py-2.5 text-left transition-colors"
      >
        <span style={{ color: enabled ? '#10b981' : '#475569' }}>{icon}</span>
        <span className="flex-1 text-xs font-bold uppercase tracking-wider"
          style={{ color: enabled ? '#e2e8f0' : '#475569' }}>{label}</span>
        {enabled
          ? <ToggleRight size={18} style={{ color: '#10b981', flexShrink: 0 }} />
          : <ToggleLeft size={18} style={{ color: '#334155', flexShrink: 0 }} />}
      </button>
      {enabled && children && (
        <div className="px-3 pb-3">{children}</div>
      )}
    </div>
  );
}

/* ── small number input ─────────────────────────────────────────── */
function NumInput({
  prefix, value, onChange, min, step, placeholder,
}: {
  prefix?: string;
  value: string;
  onChange: (v: string) => void;
  min?: number;
  step?: number;
  placeholder?: string;
}) {
  return (
    <div className="relative">
      {prefix && (
        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs font-mono"
          style={{ color: '#475569' }}>{prefix}</span>
      )}
      <input
        type="number"
        value={value}
        min={min}
        step={step ?? 1}
        placeholder={placeholder}
        onChange={e => onChange(e.target.value)}
        className="w-full py-2 rounded-lg text-sm font-mono font-bold outline-none transition-all"
        style={{
          paddingLeft: prefix ? '1.75rem' : '0.75rem',
          paddingRight: '0.75rem',
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(255,255,255,0.08)',
          color: '#e2e8f0',
        }}
        onFocus={e => (e.target.style.borderColor = 'rgba(16,185,129,0.4)')}
        onBlur={e => (e.target.style.borderColor = 'rgba(255,255,255,0.08)')}
      />
    </div>
  );
}

/* ── strategy dropdown ──────────────────────────────────────────── */
function StrategyDropdown({ value, onChange }: { value: StrategyType; onChange: (v: StrategyType) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const current = STRATEGIES.find(s => s.id === value)!;

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl transition-all"
        style={{
          background: 'rgba(6,182,212,0.07)',
          border: '1px solid rgba(6,182,212,0.18)',
          color: '#06b6d4',
        }}>
        <span className="shrink-0">{current.icon}</span>
        <span className="flex-1 text-left text-sm font-bold">{current.label}</span>
        <ChevronDown size={14} className={`transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="absolute z-30 top-full left-0 right-0 mt-1 rounded-xl overflow-hidden"
          style={{
            background: 'rgba(8,12,24,0.98)',
            border: '1px solid rgba(6,182,212,0.18)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.5)',
          }}>
          {STRATEGIES.map(s => (
            <button key={s.id}
              onClick={() => { onChange(s.id); setOpen(false); }}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 text-left transition-colors hover:bg-white/5"
              style={{ color: s.id === value ? '#06b6d4' : '#64748b' }}>
              <span className="shrink-0">{s.icon}</span>
              <span className="text-sm font-semibold">{s.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════ */
export default function TradePanel({
  selectedSymbol, currentPrice, analysis, autoTrade,
  onAutoTradeToggle, onTradePlaced, disabled,
  isAuthenticated, onConnectDeriv,
}: Props) {
  // Core
  const [stake, setStake]       = useState('10');
  const [strategy, setStrategy] = useState<StrategyType>('rise_fall');
  const [placing, setPlacing]   = useState(false);

  // Duration / ticks
  const [useTicks, setUseTicks]     = useState(false);
  const [ticks, setTicks]           = useState(5);
  const [duration, setDuration]     = useState(DURATIONS[1]);

  // Digit selectors
  const [selectedDigit,   setSelectedDigit]   = useState(5);
  const [selectedBarrier, setSelectedBarrier] = useState(5);

  // Risk controls
  const [takeProfitOn, setTakeProfitOn] = useState(false);
  const [takeProfitVal, setTakeProfitVal] = useState('50');

  const [maxLossesOn, setMaxLossesOn]   = useState(false);
  const [maxLossesVal, setMaxLossesVal] = useState('5');

  const [stopLossOn, setStopLossOn]     = useState(false);
  const [stopLossVal, setStopLossVal]   = useState('20');

  const [martingaleOn, setMartingaleOn] = useState(false);
  const [martingaleMult, setMartingaleMult] = useState('2');

  const [stakeListOn, setStakeListOn]   = useState(false);
  const [stakeListRaw, setStakeListRaw] = useState('10,20,40,80');

  const symbolInfo = VOLATILITY_INDICES.find(v => v.symbol === selectedSymbol);
  const stakeVal   = parseFloat(stake) || 0;
  const payout     = stakeVal * 1.85;
  const profit     = payout - stakeVal;
  const isLive     = !!isAuthenticated;
  const isDigit    = strategy !== 'rise_fall';
  const hasSignal  = !!analysis && analysis.confidence >= 61;
  const canExecute = hasSignal && !disabled && !placing && currentPrice !== null;

  const durationSecs = isDigit
    ? (useTicks ? ticks * 2 : 60)
    : duration.value * (duration.unit === 'h' ? 3600 : 60);

  // Rise % bar from analysis
  const riseConf = analysis
    ? (analysis.signal === 'CALL' ? analysis.confidence : 100 - analysis.confidence)
    : 50;
  const fallConf = 100 - riseConf;

  const place = (contractType: string, barrier?: number, prediction?: number) => {
    if (!canExecute) return;
    setPlacing(true);

    const stakeListParsed = stakeListOn
      ? stakeListRaw.split(',').map(s => parseFloat(s.trim())).filter(n => !isNaN(n) && n > 0)
      : undefined;

    onTradePlaced({
      symbol: selectedSymbol,
      contract_type: contractType,
      stake: stakeVal,
      payout,
      entry_price: currentPrice,
      exit_price: null,
      result: 'open',
      profit_loss: 0,
      duration: durationSecs,
      reference_id: null,
      closed_at: null,
      barrier: barrier ?? null,
      prediction: prediction ?? null,
      strategy_type: strategy,
      strategyType: strategy,
      takeProfit: takeProfitOn ? parseFloat(takeProfitVal) || undefined : undefined,
      maxLosses:  maxLossesOn  ? parseInt(maxLossesVal)   || undefined : undefined,
      stopLoss:   stopLossOn   ? parseFloat(stopLossVal)  || undefined : undefined,
      martingale: martingaleOn || undefined,
      martingaleMultiplier: martingaleOn ? parseFloat(martingaleMult) || 2 : undefined,
      stakeList: stakeListParsed,
    });
    setTimeout(() => setPlacing(false), 500);
  };

  const renderTradeButtons = () => {
    switch (strategy) {
      case 'rise_fall': return (
        <div className="grid grid-cols-2 gap-2 mt-1">
          {(['RISE', 'FALL'] as const).map(dir => {
            const isRise = dir === 'RISE';
            const color  = isRise ? '#10b981' : '#ef4444';
            const dim    = isRise ? '#059669' : '#dc2626';
            return (
              <button key={dir} onClick={() => place(isRise ? 'CALL' : 'PUT')}
                disabled={!canExecute || placing}
                className="group relative overflow-hidden flex items-center justify-center gap-2 py-4 rounded-xl font-black text-base tracking-wide transition-all active:scale-95"
                style={{
                  background: canExecute ? `linear-gradient(135deg, ${dim}, ${color})` : 'rgba(255,255,255,0.04)',
                  color: canExecute ? '#fff' : '#334155',
                  border: canExecute ? `1px solid ${color}` : '1px solid rgba(255,255,255,0.06)',
                  boxShadow: canExecute ? `0 0 24px ${color}45, 0 4px 16px rgba(0,0,0,0.35)` : 'none',
                  cursor: canExecute ? 'pointer' : 'not-allowed',
                }}>
                {canExecute && (
                  <span className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/10 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 pointer-events-none" />
                )}
                {isRise ? <TrendingUp size={18} /> : <TrendingDown size={18} />}
                {dir}
              </button>
            );
          })}
        </div>
      );

      case 'even_odd': return (
        <div className="grid grid-cols-2 gap-2 mt-1">
          {(['EVEN', 'ODD'] as const).map(type => {
            const isEven = type === 'EVEN';
            const color  = isEven ? '#06b6d4' : '#f59e0b';
            return (
              <button key={type} onClick={() => place(type)}
                disabled={!canExecute || placing}
                className="flex items-center justify-center gap-2 py-4 rounded-xl font-black text-base transition-all active:scale-95"
                style={{
                  background: canExecute ? `rgba(${isEven ? '6,182,212' : '245,158,11'},0.14)` : 'rgba(255,255,255,0.04)',
                  color: canExecute ? color : '#334155',
                  border: canExecute ? `1px solid ${color}55` : '1px solid rgba(255,255,255,0.06)',
                  boxShadow: canExecute ? `0 0 18px ${color}28` : 'none',
                  cursor: canExecute ? 'pointer' : 'not-allowed',
                }}>
                <Hash size={16} /> {type}
              </button>
            );
          })}
        </div>
      );

      case 'matches_differs': return (
        <div className="flex flex-col gap-2 mt-1">
          <p className="text-2xs font-semibold uppercase tracking-wider" style={{ color: '#475569' }}>Select Last Digit</p>
          <div className="grid grid-cols-5 gap-1">
            {[0,1,2,3,4,5,6,7,8,9].map(d => (
              <button key={d} onClick={() => setSelectedDigit(d)}
                className="py-2 rounded text-xs font-bold transition-all"
                style={{
                  background: selectedDigit === d ? 'rgba(6,182,212,0.18)' : 'rgba(255,255,255,0.04)',
                  color: selectedDigit === d ? '#06b6d4' : '#64748b',
                  border: selectedDigit === d ? '1px solid rgba(6,182,212,0.35)' : '1px solid rgba(255,255,255,0.06)',
                }}>{d}</button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2">
            {(['DIGITMATCH', 'DIGITDIFF'] as const).map(type => {
              const isM = type === 'DIGITMATCH';
              const col = isM ? '#10b981' : '#ef4444';
              return (
                <button key={type} onClick={() => place(type, undefined, selectedDigit)}
                  disabled={!canExecute || placing}
                  className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-black text-sm transition-all active:scale-95"
                  style={{
                    background: canExecute ? `rgba(${isM ? '16,185,129' : '239,68,68'},0.12)` : 'rgba(255,255,255,0.04)',
                    color: canExecute ? col : '#334155',
                    border: canExecute ? `1px solid ${col}50` : '1px solid rgba(255,255,255,0.06)',
                    cursor: canExecute ? 'pointer' : 'not-allowed',
                  }}>
                  <Equal size={14} /> {isM ? 'MATCHES' : 'DIFFERS'}
                </button>
              );
            })}
          </div>
        </div>
      );

      case 'over_under': return (
        <div className="flex flex-col gap-2 mt-1">
          <p className="text-2xs font-semibold uppercase tracking-wider" style={{ color: '#475569' }}>Barrier Digit</p>
          <div className="grid grid-cols-5 gap-1">
            {[0,1,2,3,4,5,6,7,8,9].map(b => (
              <button key={b} onClick={() => setSelectedBarrier(b)}
                className="py-2 rounded text-xs font-bold transition-all"
                style={{
                  background: selectedBarrier === b ? 'rgba(245,158,11,0.18)' : 'rgba(255,255,255,0.04)',
                  color: selectedBarrier === b ? '#f59e0b' : '#64748b',
                  border: selectedBarrier === b ? '1px solid rgba(245,158,11,0.35)' : '1px solid rgba(255,255,255,0.06)',
                }}>{b}</button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2">
            {(['DIGITOVER', 'DIGITUNDER'] as const).map(type => {
              const isO = type === 'DIGITOVER';
              const col = isO ? '#10b981' : '#ef4444';
              return (
                <button key={type} onClick={() => place(type, selectedBarrier)}
                  disabled={!canExecute || placing}
                  className="flex items-center justify-center gap-2 py-3.5 rounded-xl font-black text-sm transition-all active:scale-95"
                  style={{
                    background: canExecute ? `rgba(${isO ? '16,185,129' : '239,68,68'},0.12)` : 'rgba(255,255,255,0.04)',
                    color: canExecute ? col : '#334155',
                    border: canExecute ? `1px solid ${col}50` : '1px solid rgba(255,255,255,0.06)',
                    cursor: canExecute ? 'pointer' : 'not-allowed',
                  }}>
                  {isO ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
                  {isO ? `OVER ${selectedBarrier}` : `UNDER ${selectedBarrier}`}
                </button>
              );
            })}
          </div>
        </div>
      );
    }
  };

  return (
    <div className="flex flex-col gap-2.5">

      {/* Live / Demo badge */}
      <div className="flex items-center gap-2 px-3 py-2 rounded-lg"
        style={{
          background: isLive ? 'rgba(16,185,129,0.06)' : 'rgba(245,158,11,0.05)',
          border: isLive ? '1px solid rgba(16,185,129,0.14)' : '1px solid rgba(245,158,11,0.11)',
        }}>
        <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${isLive ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
        <span className="text-2xs font-semibold flex-1" style={{ color: isLive ? '#10b981' : '#f59e0b' }}>
          {isLive ? 'Live Trading — Real money' : 'Demo Mode — Virtual funds'}
        </span>
        {!isLive && onConnectDeriv && (
          <button onClick={onConnectDeriv}
            className="flex items-center gap-1 text-2xs font-bold shrink-0 transition-opacity hover:opacity-75"
            style={{ color: '#06b6d4' }}>
            <KeyRound size={10} />
            Connect
          </button>
        )}
        <button onClick={() => onAutoTradeToggle(!autoTrade)}
          className="flex items-center gap-1.5 ml-2 px-2 py-0.5 rounded text-2xs font-bold uppercase transition-all"
          style={{
            background: autoTrade ? 'rgba(16,185,129,0.1)' : 'rgba(255,255,255,0.04)',
            color: autoTrade ? '#10b981' : '#475569',
            border: autoTrade ? '1px solid rgba(16,185,129,0.2)' : '1px solid rgba(255,255,255,0.06)',
          }}>
          <Bot size={9} />
          Auto {autoTrade ? 'ON' : 'OFF'}
        </button>
      </div>

      {/* ── Row 1: Stake + Take Profit + Max Losses ── */}
      <div className="grid grid-cols-3 gap-1.5">
        <div>
          <label className="block text-2xs font-bold uppercase tracking-wider mb-1" style={{ color: '#475569' }}>
            <DollarSign size={8} className="inline mr-0.5" />Stake
          </label>
          <NumInput prefix="$" value={stake} onChange={setStake} min={1} step={1} />
        </div>
        <div>
          <label className="block text-2xs font-bold uppercase tracking-wider mb-1" style={{ color: '#475569' }}>
            <Target size={8} className="inline mr-0.5" />Take Profit
          </label>
          <NumInput prefix="$" value={takeProfitOn ? takeProfitVal : ''} onChange={setTakeProfitVal}
            min={0.1} step={1} placeholder="Off" />
        </div>
        <div>
          <label className="block text-2xs font-bold uppercase tracking-wider mb-1" style={{ color: '#475569' }}>
            <ShieldOff size={8} className="inline mr-0.5" />Max Losses
          </label>
          <NumInput value={maxLossesOn ? maxLossesVal : ''} onChange={setMaxLossesVal}
            min={1} step={1} placeholder="Off" />
        </div>
      </div>

      {/* ── Row 2: Strategy + Stop Loss ── */}
      <div className="grid grid-cols-2 gap-1.5">
        <div>
          <label className="block text-2xs font-bold uppercase tracking-wider mb-1" style={{ color: '#475569' }}>Strategy</label>
          <StrategyDropdown value={strategy} onChange={s => setStrategy(s)} />
        </div>
        <div>
          <label className="block text-2xs font-bold uppercase tracking-wider mb-1" style={{ color: '#475569' }}>
            Stop Loss $
          </label>
          <NumInput prefix="$" value={stopLossOn ? stopLossVal : ''} onChange={setStopLossVal}
            min={0.1} step={1} placeholder="Off" />
        </div>
      </div>

      {/* Quick-enable row for Take Profit / Max Losses / Stop Loss */}
      <div className="flex gap-1.5">
        {[
          { label: 'Take Profit', on: takeProfitOn, toggle: () => setTakeProfitOn(v => !v), color: '#10b981' },
          { label: 'Max Losses',  on: maxLossesOn,  toggle: () => setMaxLossesOn(v => !v),  color: '#f59e0b' },
          { label: 'Stop Loss',   on: stopLossOn,   toggle: () => setStopLossOn(v => !v),   color: '#ef4444' },
        ].map(({ label, on, toggle, color }) => (
          <button key={label} onClick={toggle}
            className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-2xs font-bold transition-all"
            style={{
              background: on ? `rgba(${color === '#10b981' ? '16,185,129' : color === '#f59e0b' ? '245,158,11' : '239,68,68'},0.1)` : 'rgba(255,255,255,0.03)',
              color: on ? color : '#334155',
              border: on ? `1px solid ${color}35` : '1px solid rgba(255,255,255,0.06)',
            }}>
            {on
              ? <ToggleRight size={12} style={{ color }} />
              : <ToggleLeft size={12} style={{ color: '#334155' }} />}
            {label}
          </button>
        ))}
      </div>

      {/* ── Toggleable advanced controls ── */}
      <div className="flex flex-col gap-2">

        {/* Martingale */}
        <ToggleRow
          icon={<Repeat2 size={13} />}
          label="Martingale"
          enabled={martingaleOn}
          onToggle={() => setMartingaleOn(v => !v)}>
          <div className="flex items-center gap-2">
            <span className="text-xs" style={{ color: '#64748b' }}>Multiplier</span>
            <div className="flex gap-1 flex-1">
              {[1.5, 2, 2.5, 3].map(m => (
                <button key={m} onClick={() => setMartingaleMult(String(m))}
                  className="flex-1 py-1.5 rounded text-2xs font-bold transition-all"
                  style={{
                    background: parseFloat(martingaleMult) === m ? 'rgba(16,185,129,0.18)' : 'rgba(255,255,255,0.04)',
                    color: parseFloat(martingaleMult) === m ? '#10b981' : '#475569',
                    border: parseFloat(martingaleMult) === m ? '1px solid rgba(16,185,129,0.3)' : '1px solid rgba(255,255,255,0.06)',
                  }}>{m}x</button>
              ))}
            </div>
          </div>
          <p className="text-2xs mt-1.5" style={{ color: '#334155' }}>
            Stake doubles ×{martingaleMult} after each loss until recovery
          </p>
        </ToggleRow>

        {/* Ticks */}
        <ToggleRow
          icon={<Clock size={13} />}
          label="Ticks (Override Duration)"
          enabled={useTicks}
          onToggle={() => setUseTicks(v => !v)}>
          <div className="flex gap-1">
            {TICK_OPTIONS.map(t => (
              <button key={t} onClick={() => setTicks(t)}
                className="flex-1 py-2 rounded text-xs font-bold transition-all"
                style={{
                  background: ticks === t ? 'rgba(6,182,212,0.18)' : 'rgba(255,255,255,0.04)',
                  color: ticks === t ? '#06b6d4' : '#475569',
                  border: ticks === t ? '1px solid rgba(6,182,212,0.3)' : '1px solid rgba(255,255,255,0.06)',
                }}>{t}t</button>
            ))}
          </div>
        </ToggleRow>

        {/* Stake List */}
        <ToggleRow
          icon={<List size={13} />}
          label="Stake List"
          enabled={stakeListOn}
          onToggle={() => setStakeListOn(v => !v)}>
          <div>
            <p className="text-2xs mb-1.5" style={{ color: '#475569' }}>
              Comma-separated stakes — cycles in order
            </p>
            <input
              type="text"
              value={stakeListRaw}
              onChange={e => setStakeListRaw(e.target.value)}
              placeholder="e.g. 10,20,40,80"
              className="w-full px-3 py-2 rounded-lg text-xs font-mono font-bold outline-none transition-all"
              style={{
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.08)',
                color: '#e2e8f0',
              }}
              onFocus={e => (e.target.style.borderColor = 'rgba(16,185,129,0.4)')}
              onBlur={e => (e.target.style.borderColor = 'rgba(255,255,255,0.08)')}
            />
            <div className="flex gap-1 mt-1.5 flex-wrap">
              {stakeListRaw.split(',').map(s => s.trim()).filter(Boolean).map((v, i) => (
                <span key={i} className="px-2 py-0.5 rounded text-2xs font-mono font-bold"
                  style={{ background: 'rgba(6,182,212,0.1)', color: '#06b6d4', border: '1px solid rgba(6,182,212,0.2)' }}>
                  ${v}
                </span>
              ))}
            </div>
          </div>
        </ToggleRow>

        {/* Duration (only for rise_fall when ticks off) */}
        {strategy === 'rise_fall' && !useTicks && (
          <ToggleRow
            icon={<Clock size={13} />}
            label="Duration"
            enabled={true}
            onToggle={() => {}}>
            <div className="grid grid-cols-5 gap-1">
              {DURATIONS.map(d => (
                <button key={d.label} onClick={() => setDuration(d)}
                  className="py-2 rounded text-2xs font-bold transition-all"
                  style={{
                    background: duration.label === d.label ? 'rgba(6,182,212,0.15)' : 'rgba(255,255,255,0.03)',
                    color: duration.label === d.label ? '#06b6d4' : '#475569',
                    border: duration.label === d.label ? '1px solid rgba(6,182,212,0.25)' : '1px solid transparent',
                  }}>{d.label}</button>
              ))}
            </div>
          </ToggleRow>
        )}
      </div>

      {/* ── Rise / Fall confidence bar ── */}
      <div className="rounded-xl overflow-hidden" style={{ border: '1px solid rgba(255,255,255,0.06)' }}>
        <div className="flex h-8 text-xs font-black">
          <div className="flex items-center justify-center transition-all duration-700"
            style={{ width: `${riseConf}%`, background: 'linear-gradient(135deg, #059669, #10b981)', color: '#fff', fontSize: '11px' }}>
            RISE: {riseConf.toFixed(1)}%
          </div>
          <div className="flex items-center justify-center transition-all duration-700"
            style={{ width: `${fallConf}%`, background: 'linear-gradient(135deg, #dc2626, #ef4444)', color: '#fff', fontSize: '11px' }}>
            FALL: {fallConf.toFixed(1)}%
          </div>
        </div>
      </div>

      {/* ── Payout summary ── */}
      {strategy === 'rise_fall' && (
        <div className="flex items-center justify-between px-3 py-2 rounded-xl"
          style={{ background: 'rgba(16,185,129,0.04)', border: '1px solid rgba(16,185,129,0.09)' }}>
          <span className="text-2xs" style={{ color: '#334155' }}>Payout</span>
          <span className="text-sm font-mono font-bold" style={{ color: '#10b981' }}>${payout.toFixed(2)}</span>
          <div className="w-px h-4" style={{ background: 'rgba(255,255,255,0.06)' }} />
          <span className="text-2xs" style={{ color: '#334155' }}>Profit</span>
          <span className="text-sm font-mono font-bold" style={{ color: '#10b981' }}>+${profit.toFixed(2)}</span>
          <div className="w-px h-4" style={{ background: 'rgba(255,255,255,0.06)' }} />
          <span className="text-2xs" style={{ color: '#334155' }}>ROI</span>
          <span className="text-sm font-mono font-bold" style={{ color: '#10b981' }}>85%</span>
        </div>
      )}

      {/* Active risk guards summary */}
      {(takeProfitOn || maxLossesOn || stopLossOn || martingaleOn) && (
        <div className="px-3 py-2 rounded-xl flex flex-wrap gap-x-3 gap-y-1"
          style={{ background: 'rgba(6,182,212,0.04)', border: '1px solid rgba(6,182,212,0.1)' }}>
          {takeProfitOn && <span className="text-2xs font-bold" style={{ color: '#10b981' }}>TP: ${takeProfitVal}</span>}
          {stopLossOn   && <span className="text-2xs font-bold" style={{ color: '#ef4444' }}>SL: ${stopLossVal}</span>}
          {maxLossesOn  && <span className="text-2xs font-bold" style={{ color: '#f59e0b' }}>Max: {maxLossesVal} losses</span>}
          {martingaleOn && <span className="text-2xs font-bold" style={{ color: '#06b6d4' }}>Martingale ×{martingaleMult}</span>}
          {stakeListOn  && <span className="text-2xs font-bold" style={{ color: '#94a3b8' }}>Stake list active</span>}
        </div>
      )}

      {/* ── Trade buttons ── */}
      {renderTradeButtons()}

      {disabled && (
        <p className="text-center text-2xs" style={{ color: '#475569' }}>
          Trade in progress — wait for it to close
        </p>
      )}
    </div>
  );
}
