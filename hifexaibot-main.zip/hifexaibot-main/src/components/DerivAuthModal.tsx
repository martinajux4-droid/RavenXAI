import { useState, useRef, useEffect } from 'react';
import {
  Shield, Eye, EyeOff, X, ExternalLink, KeyRound,
  AlertCircle, CheckCircle2, User, LogOut, Wifi,
  ArrowLeftRight, Globe, Lock,
} from 'lucide-react';
import { DerivAccount, OAuthAccount, derivAPI } from '../lib/derivApi';
import { AuthState } from '../hooks/useDerivAuth';

type Props = {
  onLogin: (token: string) => Promise<DerivAccount>;
  onLogout: () => void;
  onSwitchAccount: (loginid: string) => void;
  account: DerivAccount | null;
  balance: number | null;
  oauthAccounts: OAuthAccount[];
  authState: AuthState;
  authError: string | null;
  onClose: () => void;
};

export default function DerivAuthModal({
  onLogin, onLogout, onSwitchAccount,
  account, balance, oauthAccounts,
  authState, authError, onClose,
}: Props) {
  const [token, setToken] = useState('');
  const [showToken, setShowToken] = useState(false);
  const [visible, setVisible] = useState(false);
  const [mode, setMode] = useState<'oauth' | 'token'>('oauth');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    requestAnimationFrame(() => setVisible(true));
    if (!account && mode === 'token') setTimeout(() => inputRef.current?.focus(), 200);
  }, [account, mode]);

  const close = () => { setVisible(false); setTimeout(onClose, 220); };

  const handleTokenSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token.trim() || authState === 'loading') return;
    try { await onLogin(token); } catch { /* error shown via authError */ }
  };

  const handleOAuth = () => {
    window.location.href = derivAPI.getOAuthUrl();
  };

  const isLoading = authState === 'loading';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        onClick={close}
        className="absolute inset-0 transition-opacity duration-200"
        style={{ background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(12px)', opacity: visible ? 1 : 0 }}
      />

      {/* Panel */}
      <div
        className="relative z-10 w-full max-w-md"
        style={{
          borderRadius: '20px',
          background: 'rgba(4,8,18,0.98)',
          border: '1px solid rgba(0,255,136,0.1)',
          boxShadow: '0 24px 80px rgba(0,0,0,0.75), 0 0 60px rgba(0,255,136,0.04)',
          transform: visible ? 'scale(1) translateY(0)' : 'scale(0.94) translateY(14px)',
          opacity: visible ? 1 : 0,
          transition: 'all 0.24s cubic-bezier(0.34, 1.5, 0.64, 1)',
        }}
      >
        {/* Top accent line */}
        <div className="h-px w-full rounded-t-[20px]"
          style={{ background: 'linear-gradient(90deg, transparent 0%, rgba(0,255,136,0.6) 50%, transparent 100%)' }} />

        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center"
                style={{ background: 'rgba(0,255,136,0.08)', border: '1px solid rgba(0,255,136,0.18)' }}>
                <Shield size={17} style={{ color: '#00ff88', filter: 'drop-shadow(0 0 6px rgba(0,255,136,0.6))' }} />
              </div>
              <div>
                <p className="text-sm font-bold t-white">Deriv Connection</p>
                <p className="text-2xs mt-0.5 t-muted">App ID: {derivAPI.getOAuthUrl().match(/app_id=(\d+)/)?.[1] ?? '68610'}</p>
              </div>
            </div>
            <button onClick={close}
              className="p-1.5 rounded-lg transition-colors t-muted hover:t-sub"
              style={{ background: 'transparent' }}
              onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.05)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
              <X size={14} />
            </button>
          </div>

          {/* ── AUTHENTICATED VIEW ── */}
          {account ? (
            <div className="space-y-4">
              {/* Account card */}
              <div className="flex items-center gap-3 p-4 rounded-2xl"
                style={{ background: 'rgba(0,255,136,0.05)', border: '1px solid rgba(0,255,136,0.15)' }}>
                <div className="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: 'rgba(0,255,136,0.1)' }}>
                  <User size={20} style={{ color: '#00ff88', filter: 'drop-shadow(0 0 6px rgba(0,255,136,0.7))' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold truncate t-white">
                    {account.fullname || account.email || account.loginid}
                  </p>
                  <p className="text-xs font-mono font-semibold t-green">{account.loginid}</p>
                  {account.email && (
                    <p className="text-2xs truncate mt-0.5 t-muted">{account.email}</p>
                  )}
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <div className="w-1.5 h-1.5 rounded-full animate-pulse"
                    style={{ background: '#00ff88', boxShadow: '0 0 6px #00ff88' }} />
                  <CheckCircle2 size={16} style={{ color: '#00ff88' }} />
                </div>
              </div>

              {/* Balance + account type grid */}
              <div className="grid grid-cols-3 gap-2">
                {[
                  {
                    label: 'Balance',
                    value: balance !== null ? `${balance.toFixed(2)}` : '—',
                    sub: account.currency,
                    color: account.is_virtual ? '#ffaa00' : '#00ff88',
                  },
                  {
                    label: 'Account',
                    value: account.is_virtual ? 'Demo' : 'Real',
                    sub: account.is_virtual ? 'Virtual funds' : 'Live funds',
                    color: account.is_virtual ? '#ffaa00' : '#00ff88',
                  },
                  {
                    label: 'Status',
                    value: 'Active',
                    sub: 'Connected',
                    color: '#00ff88',
                  },
                ].map(c => (
                  <div key={c.label} className="p-3 rounded-xl text-center"
                    style={{ background: 'rgba(0,255,136,0.03)', border: '1px solid rgba(0,255,136,0.08)' }}>
                    <p className="text-2xs mb-1 t-muted">{c.label}</p>
                    <p className="text-sm font-mono font-bold leading-none"
                      style={{ color: c.color, textShadow: `0 0 8px ${c.color}60` }}>{c.value}</p>
                    <p className="text-2xs mt-0.5 t-muted">{c.sub}</p>
                  </div>
                ))}
              </div>

              {/* Account switcher (when OAuth accounts are available) */}
              {oauthAccounts.length > 1 && (
                <div className="rounded-2xl overflow-hidden"
                  style={{ border: '1px solid rgba(0,255,136,0.08)' }}>
                  <p className="text-2xs font-black uppercase tracking-wider px-3 pt-3 pb-2 t-muted">
                    Switch Account
                  </p>
                  <div className="divide-y" style={{ borderColor: 'rgba(0,255,136,0.05)' }}>
                    {oauthAccounts.map(a => {
                      const isActive = a.loginid === account.loginid;
                      return (
                        <button
                          key={a.loginid}
                          onClick={() => !isActive && onSwitchAccount(a.loginid)}
                          disabled={isActive}
                          className="w-full flex items-center gap-3 px-3 py-2.5 text-left transition-colors"
                          style={{
                            background: isActive ? 'rgba(0,255,136,0.05)' : 'transparent',
                            cursor: isActive ? 'default' : 'pointer',
                          }}
                          onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = 'rgba(0,255,136,0.04)'; }}
                          onMouseLeave={e => { e.currentTarget.style.background = isActive ? 'rgba(0,255,136,0.05)' : 'transparent'; }}>
                          <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                            style={{
                              background: a.is_virtual ? 'rgba(255,170,0,0.1)' : 'rgba(0,255,136,0.08)',
                              border: a.is_virtual ? '1px solid rgba(255,170,0,0.2)' : '1px solid rgba(0,255,136,0.15)',
                            }}>
                            <User size={12} style={{ color: a.is_virtual ? '#ffaa00' : '#00ff88' }} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="text-xs font-black font-mono"
                                style={{ color: a.is_virtual ? '#ffaa00' : '#00ff88' }}>
                                {a.loginid}
                              </span>
                              <span className="text-2xs font-black px-1 py-0.5 rounded"
                                style={{
                                  background: a.is_virtual ? 'rgba(255,170,0,0.1)' : 'rgba(0,255,136,0.08)',
                                  color: a.is_virtual ? '#ffaa00' : '#00ff88',
                                }}>
                                {a.is_virtual ? 'DEMO' : 'REAL'}
                              </span>
                            </div>
                            {a.currency && <p className="text-2xs t-muted">{a.currency}</p>}
                          </div>
                          {isActive && (
                            <div className="w-1.5 h-1.5 rounded-full shrink-0"
                              style={{ background: '#00ff88', boxShadow: '0 0 6px #00ff88' }} />
                          )}
                          {!isActive && (
                            <ArrowLeftRight size={11} className="shrink-0 t-muted" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {account.is_virtual && (
                <div className="flex items-start gap-2.5 p-3 rounded-xl"
                  style={{ background: 'rgba(255,170,0,0.05)', border: '1px solid rgba(255,170,0,0.14)' }}>
                  <AlertCircle size={13} className="shrink-0 mt-0.5" style={{ color: '#ffaa00' }} />
                  <p className="text-2xs leading-relaxed" style={{ color: '#ffaa00' }}>
                    Demo account — trades use virtual money. Switch to a Real account above for live trading.
                  </p>
                </div>
              )}

              <div className="flex gap-2 pt-1">
                <button onClick={close}
                  className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-xl text-xs font-bold transition-all"
                  style={{ background: 'rgba(0,255,136,0.07)', color: '#00ff88', border: '1px solid rgba(0,255,136,0.18)' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'rgba(0,255,136,0.12)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'rgba(0,255,136,0.07)')}>
                  <Wifi size={12} />
                  Continue Trading
                </button>
                <button
                  onClick={() => { onLogout(); close(); }}
                  className="flex items-center gap-1.5 px-4 py-3 rounded-xl text-xs font-bold transition-all"
                  style={{ background: 'rgba(255,51,85,0.07)', color: '#ff3355', border: '1px solid rgba(255,51,85,0.14)' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,51,85,0.12)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,51,85,0.07)')}>
                  <LogOut size={12} />
                  Disconnect
                </button>
              </div>
            </div>
          ) : (
            /* ── LOGIN FORM ── */
            <div className="space-y-4">
              {/* Mode switcher */}
              <div className="flex p-1 rounded-xl gap-1"
                style={{ background: 'rgba(0,255,136,0.04)', border: '1px solid rgba(0,255,136,0.08)' }}>
                {[
                  { id: 'oauth' as const, label: 'OAuth Login', icon: <Globe size={11} /> },
                  { id: 'token' as const, label: 'API Token', icon: <Lock size={11} /> },
                ].map(m => (
                  <button
                    key={m.id}
                    onClick={() => setMode(m.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-bold transition-all"
                    style={{
                      background: mode === m.id ? 'rgba(0,255,136,0.1)' : 'transparent',
                      color: mode === m.id ? '#00ff88' : 'rgba(0,255,136,0.35)',
                      border: mode === m.id ? '1px solid rgba(0,255,136,0.2)' : '1px solid transparent',
                      textShadow: mode === m.id ? '0 0 8px rgba(0,255,136,0.5)' : 'none',
                    }}>
                    {m.icon}{m.label}
                  </button>
                ))}
              </div>

              {mode === 'oauth' ? (
                /* OAuth mode */
                <div className="space-y-4">
                  <div className="p-4 rounded-2xl space-y-3"
                    style={{ background: 'rgba(0,255,136,0.04)', border: '1px solid rgba(0,255,136,0.09)' }}>
                    <p className="text-xs font-bold t-green">One-click OAuth login:</p>
                    <ol className="space-y-2">
                      {[
                        'Click "Login with Deriv" below',
                        'Sign in on deriv.com (opens in same tab)',
                        'You\'ll be redirected back automatically',
                        'Both Real and Demo accounts will load',
                      ].map((s, i) => (
                        <li key={i} className="flex items-start gap-2.5">
                          <span className="w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5 text-2xs font-bold"
                            style={{ background: 'rgba(0,255,136,0.12)', color: '#00ff88' }}>
                            {i + 1}
                          </span>
                          <span className="text-2xs leading-relaxed t-sub">{s}</span>
                        </li>
                      ))}
                    </ol>
                  </div>

                  <button
                    onClick={handleOAuth}
                    disabled={isLoading}
                    className="w-full py-4 rounded-xl text-sm font-black flex items-center justify-center gap-2.5 transition-all"
                    style={{
                      background: 'linear-gradient(135deg, rgba(0,255,136,0.15) 0%, rgba(0,200,100,0.08) 100%)',
                      color: '#00ff88',
                      border: '1px solid rgba(0,255,136,0.3)',
                      boxShadow: '0 0 30px rgba(0,255,136,0.12), 0 0 80px rgba(0,255,136,0.04)',
                      textShadow: '0 0 10px rgba(0,255,136,0.7)',
                    }}>
                    <Globe size={16} style={{ filter: 'drop-shadow(0 0 6px rgba(0,255,136,0.8))' }} />
                    Login with Deriv
                    <ExternalLink size={12} />
                  </button>

                  <p className="text-center text-2xs t-muted">
                    Secure OAuth 2.0 — your credentials stay on deriv.com
                  </p>
                </div>
              ) : (
                /* Token mode */
                <form onSubmit={handleTokenSubmit} className="space-y-4">
                  <div className="p-4 rounded-2xl space-y-3"
                    style={{ background: 'rgba(0,255,136,0.03)', border: '1px solid rgba(0,255,136,0.08)' }}>
                    <p className="text-xs font-bold t-green">How to get your API token:</p>
                    <ol className="space-y-2">
                      {[
                        'Log in at deriv.com',
                        'Go to Account Settings → API token',
                        'Create a token with Read + Trade permissions',
                        'Copy and paste the token below',
                      ].map((s, i) => (
                        <li key={i} className="flex items-start gap-2.5">
                          <span className="w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5 text-2xs font-bold"
                            style={{ background: 'rgba(0,255,136,0.1)', color: '#00ff88' }}>
                            {i + 1}
                          </span>
                          <span className="text-2xs leading-relaxed t-sub">{s}</span>
                        </li>
                      ))}
                    </ol>
                    <a
                      href="https://app.deriv.com/account/api-token"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-2xs font-semibold transition-colors t-green hover:text-white">
                      <ExternalLink size={10} />
                      Open Deriv API Token page →
                    </a>
                  </div>

                  <div>
                    <label className="flex items-center gap-1.5 text-2xs font-semibold uppercase tracking-wider mb-2 t-muted">
                      <KeyRound size={10} />API Token
                    </label>
                    <div className="relative">
                      <input
                        ref={inputRef}
                        type={showToken ? 'text' : 'password'}
                        value={token}
                        onChange={e => setToken(e.target.value)}
                        placeholder="Paste your Deriv API token here..."
                        spellCheck={false}
                        autoComplete="off"
                        className="neon-input pr-10"
                        style={{
                          borderColor: authError ? 'rgba(255,51,85,0.35)' : undefined,
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => setShowToken(v => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 t-muted hover:t-sub transition-colors">
                        {showToken ? <EyeOff size={13} /> : <Eye size={13} />}
                      </button>
                    </div>
                  </div>

                  {authError && (
                    <div className="flex items-start gap-2 p-3 rounded-xl"
                      style={{ background: 'rgba(255,51,85,0.06)', border: '1px solid rgba(255,51,85,0.18)' }}>
                      <AlertCircle size={12} className="shrink-0 mt-0.5" style={{ color: '#ff3355' }} />
                      <p className="text-2xs leading-relaxed" style={{ color: '#ff3355' }}>{authError}</p>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={!token.trim() || isLoading}
                    className="w-full py-3.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all"
                    style={{
                      background: !token.trim() || isLoading
                        ? 'rgba(0,255,136,0.04)'
                        : 'linear-gradient(135deg, rgba(0,255,136,0.18) 0%, rgba(0,200,100,0.1) 100%)',
                      color: !token.trim() || isLoading ? 'rgba(0,255,136,0.25)' : '#00ff88',
                      border: !token.trim() ? '1px solid rgba(0,255,136,0.06)' : '1px solid rgba(0,255,136,0.28)',
                      boxShadow: token.trim() && !isLoading ? '0 0 20px rgba(0,255,136,0.12)' : 'none',
                      cursor: !token.trim() || isLoading ? 'not-allowed' : 'pointer',
                      textShadow: token.trim() && !isLoading ? '0 0 8px rgba(0,255,136,0.6)' : 'none',
                    }}>
                    {isLoading ? (
                      <>
                        <div className="w-3.5 h-3.5 border-2 rounded-full animate-spin"
                          style={{ borderColor: 'rgba(0,255,136,0.2)', borderTopColor: '#00ff88' }} />
                        Authenticating...
                      </>
                    ) : (
                      <>
                        <Shield size={13} />
                        Connect to Deriv
                      </>
                    )}
                  </button>

                  <p className="text-center text-2xs t-muted">
                    Token stored locally, never sent to third-party servers.
                  </p>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
