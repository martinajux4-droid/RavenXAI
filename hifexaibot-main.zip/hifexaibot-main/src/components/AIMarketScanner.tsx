import { useEffect, useRef, useState } from 'react';
import { ScanResult } from '../lib/aiEngine';
import { VOLATILITY_INDICES } from '../lib/derivApi';
import { TrendingUp, TrendingDown, Minus, ChevronRight, Radar } from 'lucide-react';

type Props = {
  scanning: boolean;
  progress: number;
  scanResults: ScanResult[];
  bestResult: ScanResult | null;
  currentScanSymbol: string;
  onSelectResult: (r: ScanResult) => void;
  selectedSymbol: string;
};

export default function AIMarketScanner({
  scanning, progress, scanResults, bestResult,
  currentScanSymbol, onSelectResult, selectedSymbol,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);
  const angleRef = useRef(0);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const S = 120;
    canvas.width = S; canvas.height = S;
    const cx = S / 2, cy = S / 2, R = 50;

    const draw = () => {
      ctx.clearRect(0, 0, S, S);

      // Background circle
      ctx.beginPath();
      ctx.arc(cx, cy, R + 4, 0, Math.PI * 2);
      ctx.fillStyle = scanning ? 'rgba(6,182,212,0.04)' : 'rgba(15,20,35,0.6)';
      ctx.fill();

      // Rings
      [R * 0.35, R * 0.65, R].forEach((r, i) => {
        ctx.beginPath();
        ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.strokeStyle = scanning
          ? `rgba(6,182,212,${0.12 + i * 0.06})`
          : `rgba(51,65,85,${0.3 + i * 0.1})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      });

      // Cross lines
      ctx.strokeStyle = scanning ? 'rgba(6,182,212,0.1)' : 'rgba(51,65,85,0.2)';
      ctx.lineWidth = 1;
      [[cx - R, cy, cx + R, cy], [cx, cy - R, cx, cy + R]].forEach(([x1, y1, x2, y2]) => {
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      });

      if (scanning) {
        // Sweep
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(angleRef.current);
        const grad = ctx.createLinearGradient(0, 0, R, 0);
        grad.addColorStop(0, 'rgba(6,182,212,0.0)');
        grad.addColorStop(0.4, 'rgba(6,182,212,0.15)');
        grad.addColorStop(1, 'rgba(6,182,212,0.4)');
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, R, -Math.PI / 5, 0);
        ctx.closePath();
        ctx.fillStyle = grad;
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(R, 0);
        ctx.strokeStyle = 'rgba(6,182,212,0.8)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        ctx.restore();
        angleRef.current += 0.05;
      }

      // Dots for results
      scanResults.forEach((res, i) => {
        const a = (i / VOLATILITY_INDICES.length) * Math.PI * 2 - Math.PI / 2;
        const dr = R * (0.28 + (res.score / 100) * 0.65);
        const dx = cx + Math.cos(a) * dr;
        const dy = cy + Math.sin(a) * dr;
        const isHigh = res.score >= 61;
        const isMed = res.score >= 45;
        const dotColor = isHigh ? '#10b981' : isMed ? '#f59e0b' : '#334155';
        if (isHigh) {
          ctx.beginPath();
          ctx.arc(dx, dy, 8, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(16,185,129,0.15)';
          ctx.fill();
        }
        ctx.beginPath();
        ctx.arc(dx, dy, isHigh ? 3.5 : 2, 0, Math.PI * 2);
        ctx.fillStyle = dotColor;
        ctx.fill();
      });

      // Center
      ctx.beginPath();
      ctx.arc(cx, cy, 3, 0, Math.PI * 2);
      ctx.fillStyle = scanning ? '#06b6d4' : '#334155';
      ctx.fill();

      rafRef.current = requestAnimationFrame(draw);
    };
    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [scanning, scanResults]);

  const displayed = expanded ? scanResults : scanResults.slice(0, 7);

  return (
    <div className="flex flex-col gap-4">
      {/* Radar + info */}
      <div className="flex items-center gap-4">
        <div className="relative shrink-0">
          <canvas ref={canvasRef} className="w-[100px] h-[100px]" />
          {scanning && (
            <div className="absolute inset-0 rounded-full animate-ping-slow pointer-events-none"
              style={{ border: '1px solid rgba(6,182,212,0.2)' }} />
          )}
        </div>

        <div className="flex-1 min-w-0">
          {scanning ? (
            <div className="space-y-2">
              <p className="text-xs font-bold" style={{ color: '#06b6d4' }}>
                Scanning {currentScanSymbol}
              </p>
              <div className="w-full h-1 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
                <div className="h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${progress}%`,
                    background: 'linear-gradient(90deg, #0891b2, #06b6d4)',
                    boxShadow: '0 0 8px rgba(6,182,212,0.4)',
                  }} />
              </div>
              <p className="text-2xs" style={{ color: '#475569' }}>
                {scanResults.length} / {VOLATILITY_INDICES.length} markets analyzed
              </p>
            </div>
          ) : bestResult && bestResult.score >= 61 ? (
            <div className="animate-fade-in space-y-1">
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-2xs font-bold uppercase tracking-widest" style={{ color: '#10b981' }}>Best Market Found</span>
              </div>
              <p className="text-sm font-bold truncate" style={{ color: '#e2e8f0' }}>
                {bestResult.displayName.replace(' Index', '')}
              </p>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold font-mono" style={{ color: '#10b981' }}>{bestResult.score}%</span>
                <span className="text-2xs" style={{ color: '#475569' }}>confidence</span>
                <span className={`text-2xs font-semibold ${bestResult.analysis.signal === 'CALL' ? 'text-emerald-400' : 'text-red-400'}`}>
                  {bestResult.analysis.signal}
                </span>
              </div>
            </div>
          ) : scanResults.length > 0 ? (
            <div className="space-y-1">
              <p className="text-xs font-semibold" style={{ color: '#f59e0b' }}>No Strong Setup</p>
              <p className="text-2xs" style={{ color: '#475569' }}>
                {scanResults.length} markets scanned — below 61% threshold
              </p>
            </div>
          ) : (
            <div className="space-y-1">
              <p className="text-xs font-semibold" style={{ color: '#64748b' }}>Scanner Ready</p>
              <p className="text-2xs" style={{ color: '#334155' }}>Click Scan Market to begin</p>
            </div>
          )}
        </div>
      </div>

      {/* Results */}
      {scanResults.length > 0 && (
        <div className="space-y-1">
          <div className="flex items-center justify-between mb-1.5">
            <div className="flex items-center gap-1.5">
              <Radar size={10} style={{ color: '#475569' }} />
              <span className="text-2xs font-bold uppercase tracking-widest" style={{ color: '#475569' }}>Scan Results</span>
            </div>
            {scanResults.length > 7 && (
              <button onClick={() => setExpanded(v => !v)}
                className="text-2xs font-semibold transition-colors"
                style={{ color: '#0891b2' }}>
                {expanded ? 'Less' : `+${scanResults.length - 7}`}
              </button>
            )}
          </div>

          {displayed.map(res => {
            const isSelected = res.symbol === selectedSymbol;
            const isHigh = res.score >= 61;
            const isMed = res.score >= 45 && res.score < 61;
            const scoreColor = isHigh ? '#10b981' : isMed ? '#f59e0b' : '#475569';
            const signalIcon = res.analysis.signal === 'CALL'
              ? <TrendingUp size={9} />
              : res.analysis.signal === 'PUT'
              ? <TrendingDown size={9} />
              : <Minus size={9} />;

            return (
              <button key={res.symbol} onClick={() => onSelectResult(res)}
                className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg transition-all text-left group"
                style={{
                  background: isSelected
                    ? 'rgba(6,182,212,0.08)'
                    : isHigh
                    ? 'rgba(16,185,129,0.04)'
                    : 'rgba(255,255,255,0.02)',
                  border: isSelected
                    ? '1px solid rgba(6,182,212,0.2)'
                    : isHigh
                    ? '1px solid rgba(16,185,129,0.15)'
                    : '1px solid transparent',
                  boxShadow: isHigh && !isSelected ? '0 0 12px rgba(16,185,129,0.06)' : 'none',
                }}>
                <div className="w-1.5 h-1.5 rounded-full shrink-0 transition-all"
                  style={{
                    background: scoreColor,
                    boxShadow: isHigh ? `0 0 6px ${scoreColor}` : 'none',
                  }} />

                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold truncate" style={{ color: '#cbd5e1' }}>
                    {res.displayName.replace(' Index', '')}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="text-xs font-bold font-mono" style={{ color: scoreColor }}>{res.score}%</span>
                  <div className="flex items-center gap-0.5 text-2xs font-semibold"
                    style={{
                      color: res.analysis.signal === 'CALL' ? '#10b981' :
                             res.analysis.signal === 'PUT' ? '#ef4444' : '#64748b',
                    }}>
                    {signalIcon}
                  </div>
                  <ChevronRight size={10} style={{ color: '#334155' }} />
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
