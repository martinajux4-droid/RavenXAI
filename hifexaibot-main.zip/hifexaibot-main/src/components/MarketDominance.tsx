import { useEffect, useRef, useMemo } from 'react';
import { AIAnalysis } from '../lib/aiEngine';
import { DerivTick } from '../lib/derivApi';
import { TrendingUp, TrendingDown, Zap } from 'lucide-react';

type Props = {
  analysis: AIAnalysis | null;
  ticks: DerivTick[];
  symbol: string;
};

function calcDominance(analysis: AIAnalysis | null, ticks: DerivTick[]) {
  if (!analysis) {
    return { rise: 50, fall: 50, signal: 'NEUTRAL' as const, confidence: 0, signalStrength: 0 };
  }

  const { indicators, signal, confidence } = analysis;

  // Build a weighted score from indicators
  let riseScore = 0;
  let fallScore = 0;

  // RSI weight: 25
  if (indicators.rsi < 30)       riseScore += 25;
  else if (indicators.rsi < 45)  riseScore += 12;
  else if (indicators.rsi > 70)  fallScore += 25;
  else if (indicators.rsi > 55)  fallScore += 12;
  else { riseScore += 8; fallScore += 8; }

  // MACD weight: 20
  if (indicators.macd.histogram > 0 && indicators.macd.value > 0)       riseScore += 20;
  else if (indicators.macd.histogram > 0)                                 riseScore += 10;
  else if (indicators.macd.histogram < 0 && indicators.macd.value < 0)  fallScore += 20;
  else if (indicators.macd.histogram < 0)                                 fallScore += 10;

  // Bollinger weight: 20
  if (indicators.bollinger.position < 0.1)       riseScore += 20;
  else if (indicators.bollinger.position < 0.3)  riseScore += 10;
  else if (indicators.bollinger.position > 0.9)  fallScore += 20;
  else if (indicators.bollinger.position > 0.7)  fallScore += 10;

  // Trend weight: 20
  if (indicators.trend === 'UP')        riseScore += 20;
  else if (indicators.trend === 'DOWN') fallScore += 20;
  else { riseScore += 5; fallScore += 5; }

  // Momentum weight: 10
  if (indicators.momentum > 0.1)       riseScore += 10;
  else if (indicators.momentum > 0)    riseScore += 5;
  else if (indicators.momentum < -0.1) fallScore += 10;
  else if (indicators.momentum < 0)    fallScore += 5;

  // Candle direction weight: 5
  if (indicators.candleDirection === 'BULLISH')      riseScore += 5;
  else if (indicators.candleDirection === 'BEARISH') fallScore += 5;

  const total = riseScore + fallScore || 1;
  const risePct = Math.round((riseScore / total) * 100);
  const fallPct = 100 - risePct;

  // Tick-based live momentum (last 10 ticks)
  const recentTicks = ticks.slice(-10);
  let tickRise = 0;
  for (let i = 1; i < recentTicks.length; i++) {
    if (recentTicks[i].quote > recentTicks[i - 1].quote) tickRise++;
  }
  const tickBias = recentTicks.length > 1 ? tickRise / (recentTicks.length - 1) : 0.5;

  // Blend AI score with tick momentum
  const blendedRise = Math.round(risePct * 0.75 + tickBias * 100 * 0.25);
  const blendedFall = 100 - blendedRise;

  return {
    rise: blendedRise,
    fall: blendedFall,
    signal: signal as 'CALL' | 'PUT' | 'NEUTRAL',
    confidence,
    signalStrength: Math.abs(blendedRise - 50) * 2,
  };
}

export default function MarketDominance({ analysis, ticks, symbol }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const progressRef = useRef(0);

  const dom = useMemo(() => calcDominance(analysis, ticks), [analysis, ticks]);

  const isRise = dom.signal === 'CALL' || dom.rise > dom.fall;
  const dominantColor = dom.rise > dom.fall ? '#10b981' : dom.fall > dom.rise ? '#ef4444' : '#f59e0b';
  const riseColor = '#10b981';
  const fallColor = '#ef4444';

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const S = 200;
    canvas.width = S * (window.devicePixelRatio || 1);
    canvas.height = S * (window.devicePixelRatio || 1);
    canvas.style.width = `${S}px`;
    canvas.style.height = `${S}px`;
    ctx.scale(window.devicePixelRatio || 1, window.devicePixelRatio || 1);

    const cx = S / 2;
    const cy = S / 2;
    const R_outer = 82;
    const R_inner = 66;

    const targetProgress = dom.confidence / 100;
    let currentProgress = progressRef.current;

    const draw = (t: number) => {
      ctx.clearRect(0, 0, S, S);

      // Pulsing outer glow ring
      const pulse = 0.5 + 0.5 * Math.sin(t * 0.002);

      // Outer ambient glow
      const glowGrad = ctx.createRadialGradient(cx, cy, R_outer - 10, cx, cy, R_outer + 18);
      glowGrad.addColorStop(0, dominantColor + '00');
      glowGrad.addColorStop(0.5, dominantColor + Math.round(pulse * 0x18).toString(16).padStart(2, '0'));
      glowGrad.addColorStop(1, dominantColor + '00');
      ctx.beginPath();
      ctx.arc(cx, cy, R_outer + 14, 0, Math.PI * 2);
      ctx.fillStyle = glowGrad;
      ctx.fill();

      // ── Track (background ring) ──
      ctx.beginPath();
      ctx.arc(cx, cy, R_outer, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255,255,255,0.05)';
      ctx.lineWidth = 14;
      ctx.stroke();

      // Inner track
      ctx.beginPath();
      ctx.arc(cx, cy, R_inner, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255,255,255,0.03)';
      ctx.lineWidth = 8;
      ctx.stroke();

      // ── Rise arc (top half) ──
      const riseAngle = (dom.rise / 100) * Math.PI * 2;
      const startA = -Math.PI / 2;

      if (dom.rise > 0) {
        // Glow
        ctx.beginPath();
        ctx.arc(cx, cy, R_outer, startA, startA + riseAngle);
        ctx.strokeStyle = riseColor + '28';
        ctx.lineWidth = 22;
        ctx.lineCap = 'round';
        ctx.stroke();
        // Main
        ctx.beginPath();
        ctx.arc(cx, cy, R_outer, startA, startA + riseAngle);
        const rGrad = ctx.createLinearGradient(cx - R_outer, cy, cx + R_outer, cy);
        rGrad.addColorStop(0, riseColor + 'aa');
        rGrad.addColorStop(1, riseColor);
        ctx.strokeStyle = rGrad;
        ctx.lineWidth = 14;
        ctx.lineCap = 'round';
        ctx.stroke();
      }

      // ── Fall arc (remaining) ──
      if (dom.fall > 0) {
        // Glow
        ctx.beginPath();
        ctx.arc(cx, cy, R_inner, startA + riseAngle, startA + Math.PI * 2);
        ctx.strokeStyle = fallColor + '28';
        ctx.lineWidth = 16;
        ctx.lineCap = 'round';
        ctx.stroke();
        // Main
        ctx.beginPath();
        ctx.arc(cx, cy, R_inner, startA + riseAngle, startA + Math.PI * 2);
        const fGrad = ctx.createLinearGradient(cx - R_inner, cy, cx + R_inner, cy);
        fGrad.addColorStop(0, fallColor + 'aa');
        fGrad.addColorStop(1, fallColor);
        ctx.strokeStyle = fGrad;
        ctx.lineWidth = 8;
        ctx.lineCap = 'round';
        ctx.stroke();
      }

      // ── Confidence arc (animated) ──
      currentProgress += (targetProgress - currentProgress) * 0.04;
      progressRef.current = currentProgress;

      if (currentProgress > 0.01) {
        const confAngle = currentProgress * Math.PI * 2;
        // Glow
        ctx.beginPath();
        ctx.arc(cx, cy, R_outer + 14, startA, startA + confAngle);
        ctx.strokeStyle = dominantColor + '18';
        ctx.lineWidth = 6;
        ctx.lineCap = 'round';
        ctx.stroke();
        // Line
        ctx.beginPath();
        ctx.arc(cx, cy, R_outer + 14, startA, startA + confAngle);
        ctx.strokeStyle = dominantColor + '60';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
        ctx.stroke();
        // Dot at tip
        const tipA = startA + confAngle;
        const tipR = R_outer + 14;
        ctx.beginPath();
        ctx.arc(cx + Math.cos(tipA) * tipR, cy + Math.sin(tipA) * tipR, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = dominantColor;
        ctx.fill();
      }

      // ── Center glass circle ──
      const centerGrad = ctx.createRadialGradient(cx, cy - 8, 4, cx, cy, R_inner - 12);
      centerGrad.addColorStop(0, 'rgba(30,40,70,0.9)');
      centerGrad.addColorStop(1, 'rgba(8,12,26,0.95)');
      ctx.beginPath();
      ctx.arc(cx, cy, R_inner - 10, 0, Math.PI * 2);
      ctx.fillStyle = centerGrad;
      ctx.fill();
      ctx.beginPath();
      ctx.arc(cx, cy, R_inner - 10, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255,255,255,0.06)';
      ctx.lineWidth = 1;
      ctx.stroke();

      animRef.current = requestAnimationFrame(draw);
    };

    animRef.current = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(animRef.current);
  }, [dom, dominantColor]);

  const strengthLabel = dom.signalStrength > 60 ? 'STRONG' : dom.signalStrength > 30 ? 'MODERATE' : 'WEAK';
  const strengthColor = dom.signalStrength > 60 ? '#10b981' : dom.signalStrength > 30 ? '#f59e0b' : '#ef4444';

  return (
    <div className="relative rounded-2xl overflow-hidden"
      style={{
        background: 'rgba(8,12,24,0.85)',
        border: '1px solid rgba(255,255,255,0.07)',
        backdropFilter: 'blur(20px)',
        boxShadow: `0 0 40px ${dominantColor}12, 0 8px 32px rgba(0,0,0,0.5)`,
      }}>

      {/* Top accent */}
      <div className="h-px w-full"
        style={{ background: `linear-gradient(90deg, transparent 0%, ${dominantColor}70 50%, transparent 100%)` }} />

      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-3 pb-2">
        <div className="flex items-center gap-2">
          <Zap size={12} style={{ color: dominantColor }} />
          <span className="text-xs font-bold uppercase tracking-widest" style={{ color: '#64748b' }}>
            Market Dominance
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: dominantColor }} />
          <span className="text-2xs font-bold" style={{ color: dominantColor }}>{symbol}</span>
        </div>
      </div>

      <div className="flex items-center gap-4 px-4 pb-4">

        {/* ── Rise pressure bar (left) ── */}
        <div className="flex flex-col items-center gap-1.5 shrink-0" style={{ width: 40 }}>
          <div className="flex items-center gap-1 mb-1">
            <TrendingUp size={10} style={{ color: riseColor }} />
            <span className="text-2xs font-bold" style={{ color: riseColor }}>RISE</span>
          </div>
          <div className="relative w-3 rounded-full overflow-hidden"
            style={{ height: 120, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.06)' }}>
            <div
              className="absolute bottom-0 left-0 right-0 rounded-full transition-all duration-700"
              style={{
                height: `${dom.rise}%`,
                background: `linear-gradient(to top, #059669, ${riseColor})`,
                boxShadow: `0 0 10px ${riseColor}40`,
              }} />
          </div>
          <span className="text-sm font-bold font-mono" style={{ color: riseColor }}>{dom.rise}%</span>
        </div>

        {/* ── Center circular meter ── */}
        <div className="flex-1 flex flex-col items-center">
          <div className="relative" style={{ width: 200, height: 200 }}>
            <canvas ref={canvasRef} />
            {/* Center text */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <div className="flex items-center gap-1 mb-1">
                {isRise
                  ? <TrendingUp size={14} style={{ color: riseColor }} />
                  : <TrendingDown size={14} style={{ color: fallColor }} />}
                <span className="text-xs font-bold uppercase tracking-wider"
                  style={{ color: isRise ? riseColor : fallColor }}>
                  {dom.signal === 'NEUTRAL' ? 'NEUTRAL' : isRise ? 'RISE' : 'FALL'}
                </span>
              </div>
              <span className="text-3xl font-black font-mono leading-none"
                style={{ color: dominantColor, textShadow: `0 0 20px ${dominantColor}60` }}>
                {dom.confidence}%
              </span>
              <span className="text-2xs mt-1 font-semibold" style={{ color: '#475569' }}>confidence</span>
              <div className="mt-2 px-2 py-0.5 rounded"
                style={{
                  background: `rgba(${dom.signalStrength > 60 ? '16,185,129' : dom.signalStrength > 30 ? '245,158,11' : '239,68,68'},0.12)`,
                  border: `1px solid ${strengthColor}30`,
                }}>
                <span className="text-2xs font-bold" style={{ color: strengthColor }}>{strengthLabel}</span>
              </div>
            </div>
          </div>

          {/* Dominance label below meter */}
          <div className="flex items-center justify-between w-full mt-1 px-2">
            <span className="text-2xs font-semibold" style={{ color: riseColor }}>Rise {dom.rise}%</span>
            <span className="text-2xs" style={{ color: '#334155' }}>vs</span>
            <span className="text-2xs font-semibold" style={{ color: fallColor }}>Fall {dom.fall}%</span>
          </div>
        </div>

        {/* ── Fall pressure bar (right) ── */}
        <div className="flex flex-col items-center gap-1.5 shrink-0" style={{ width: 40 }}>
          <div className="flex items-center gap-1 mb-1">
            <TrendingDown size={10} style={{ color: fallColor }} />
            <span className="text-2xs font-bold" style={{ color: fallColor }}>FALL</span>
          </div>
          <div className="relative w-3 rounded-full overflow-hidden"
            style={{ height: 120, background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.06)' }}>
            <div
              className="absolute bottom-0 left-0 right-0 rounded-full transition-all duration-700"
              style={{
                height: `${dom.fall}%`,
                background: `linear-gradient(to top, #b91c1c, ${fallColor})`,
                boxShadow: `0 0 10px ${fallColor}40`,
              }} />
          </div>
          <span className="text-sm font-bold font-mono" style={{ color: fallColor }}>{dom.fall}%</span>
        </div>
      </div>

      {/* Bottom stats row */}
      <div className="grid grid-cols-3 gap-px mx-4 mb-4 rounded-xl overflow-hidden"
        style={{ border: '1px solid rgba(255,255,255,0.05)' }}>
        {[
          { label: 'Dominance', value: `${Math.max(dom.rise, dom.fall)}%`, color: dominantColor },
          { label: 'Signal',    value: dom.signal === 'CALL' ? 'RISE' : dom.signal === 'PUT' ? 'FALL' : 'NEUTRAL', color: dominantColor },
          { label: 'Strength',  value: strengthLabel, color: strengthColor },
        ].map((s, i) => (
          <div key={i} className="flex flex-col items-center py-2.5 px-2"
            style={{ background: 'rgba(255,255,255,0.025)' }}>
            <span className="text-2xs mb-0.5" style={{ color: '#334155' }}>{s.label}</span>
            <span className="text-xs font-bold font-mono" style={{ color: s.color }}>{s.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
