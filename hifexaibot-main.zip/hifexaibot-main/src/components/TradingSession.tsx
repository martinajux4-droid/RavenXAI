import { useState, useEffect, useRef } from 'react';
import { Play, Pause, Square, Zap, TrendingUp, TrendingDown, Activity } from 'lucide-react';

export type SessionState = 'idle' | 'running' | 'paused';

type Props = {
  sessionState: SessionState;
  onStart: () => void;
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
  sessionPL: number;
  sessionTrades: number;
  sessionWins: number;
  isTradeActive: boolean;
};

export default function TradingSession({
  sessionState, onStart, onPause, onResume, onStop,
  sessionPL, sessionTrades, sessionWins, isTradeActive,
}: Props) {
  const [elapsed, setElapsed] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startTimeRef = useRef<number>(0);
  const pausedAtRef = useRef<number>(0);

  useEffect(() => {
    if (sessionState === 'running') {
      if (startTimeRef.current === 0) startTimeRef.current = Date.now() - elapsed * 1000;
      timerRef.current = setInterval(() => {
        setElapsed(Math.floor((Date.now() - startTimeRef.current) / 1000));
      }, 1000);
    } else if (sessionState === 'paused') {
      if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
      pausedAtRef.current = elapsed;
    } else {
      if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
      setElapsed(0);
      startTimeRef.current = 0;
      pausedAtRef.current = 0;
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessionState]);

  useEffect(() => {
    if (sessionState === 'running' && pausedAtRef.current > 0) {
      startTimeRef.current = Date.now() - pausedAtRef.current * 1000;
      pausedAtRef.current = 0;
    }
  }, [sessionState]);

  const fmt = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) return `${h}:${m.toString().padStart(2,'0')}:${sec.toString().padStart(2,'0')}`;
    return `${m.toString().padStart(2,'0')}:${sec.toString().padStart(2,'0')}`;
  };

  const winRate = sessionTrades > 0 ? Math.round((sessionWins / sessionTrades) * 100) : 0;
  const plPos = sessionPL >= 0;
  const isIdle = sessionState === 'idle';
  const isRunning = sessionState === 'running';
  const isPaused = sessionState === 'paused';

  const accentColor = isRunning ? '#10b981' : isPaused ? '#f59e0b' : '#475569';

  return (
    <div className="relative rounded-2xl overflow-hidden"
      style={{
        background: 'rgba(8,12,24,0.9)',
        border: `1px solid ${isRunning ? 'rgba(16,185,129,0.2)' : isPaused ? 'rgba(245,158,11,0.18)' : 'rgba(255,255,255,0.07)'}`,
        backdropFilter: 'blur(20px)',
        boxShadow: isRunning ? '0 0 30px rgba(16,185,129,0.08)' : 'none',
      }}>

      {/* Top accent */}
      <div className="h-px w-full"
        style={{ background: `linear-gradient(90deg, transparent, ${accentColor}60, transparent)` }} />

      <div className="p-4">

        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Activity size={12} style={{ color: accentColor }} />
            <span className="text-xs font-bold uppercase tracking-widest" style={{ color: '#64748b' }}>Trading Session</span>
          </div>
          <div className="flex items-center gap-1.5">
            {isRunning && <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />}
            {isPaused && <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />}
            <span className="text-2xs font-bold uppercase"
              style={{ color: accentColor }}>
              {isRunning ? 'RUNNING' : isPaused ? 'PAUSED' : 'IDLE'}
            </span>
          </div>
        </div>

        {/* Session timer + stats */}
        {!isIdle && (
          <div className="grid grid-cols-4 gap-1.5 mb-3">
            <div className="col-span-1 flex flex-col items-center justify-center px-2 py-2.5 rounded-xl"
              style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.05)' }}>
              <span className="text-2xs mb-0.5" style={{ color: '#334155' }}>Time</span>
              <span className="text-xs font-mono font-bold" style={{ color: '#94a3b8' }}>{fmt(elapsed)}</span>
            </div>
            <div className="flex flex-col items-center justify-center px-2 py-2.5 rounded-xl"
              style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.05)' }}>
              <span className="text-2xs mb-0.5" style={{ color: '#334155' }}>Trades</span>
              <span className="text-xs font-mono font-bold" style={{ color: '#94a3b8' }}>{sessionTrades}</span>
            </div>
            <div className="flex flex-col items-center justify-center px-2 py-2.5 rounded-xl"
              style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.05)' }}>
              <span className="text-2xs mb-0.5" style={{ color: '#334155' }}>Win %</span>
              <span className="text-xs font-mono font-bold" style={{ color: '#06b6d4' }}>{winRate}%</span>
            </div>
            <div className="flex flex-col items-center justify-center px-2 py-2.5 rounded-xl"
              style={{
                background: plPos ? 'rgba(16,185,129,0.07)' : 'rgba(239,68,68,0.07)',
                border: plPos ? '1px solid rgba(16,185,129,0.15)' : '1px solid rgba(239,68,68,0.15)',
              }}>
              <span className="text-2xs mb-0.5" style={{ color: '#334155' }}>P&L</span>
              <span className="text-xs font-mono font-bold" style={{ color: plPos ? '#10b981' : '#ef4444' }}>
                {plPos ? '+' : ''}${sessionPL.toFixed(0)}
              </span>
            </div>
          </div>
        )}

        {/* Session P&L large display when active */}
        {!isIdle && (
          <div className="flex items-center justify-between px-3 py-2.5 rounded-xl mb-3"
            style={{
              background: plPos ? 'rgba(16,185,129,0.05)' : 'rgba(239,68,68,0.05)',
              border: plPos ? '1px solid rgba(16,185,129,0.12)' : '1px solid rgba(239,68,68,0.12)',
            }}>
            <div className="flex items-center gap-2">
              {plPos ? <TrendingUp size={14} style={{ color: '#10b981' }} /> : <TrendingDown size={14} style={{ color: '#ef4444' }} />}
              <span className="text-xs font-semibold" style={{ color: '#475569' }}>Session P&L</span>
            </div>
            <span className="text-xl font-black font-mono"
              style={{ color: plPos ? '#10b981' : '#ef4444', textShadow: `0 0 16px ${plPos ? '#10b981' : '#ef4444'}40` }}>
              {plPos ? '+' : ''}${sessionPL.toFixed(2)}
            </span>
          </div>
        )}

        {/* Control buttons */}
        <div className="flex gap-2">
          {isIdle && (
            <button onClick={onStart}
              className="group relative flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm overflow-hidden transition-all active:scale-95"
              style={{
                background: 'linear-gradient(135deg, #059669, #10b981)',
                color: '#fff',
                border: '1px solid #10b981',
                boxShadow: '0 0 24px rgba(16,185,129,0.35), 0 4px 14px rgba(0,0,0,0.3)',
              }}>
              <span className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/10 to-white/0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 pointer-events-none" />
              <Play size={16} className="fill-white" />
              Start Trading Now
            </button>
          )}

          {isRunning && (
            <>
              <button onClick={onPause}
                disabled={isTradeActive}
                className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm transition-all active:scale-95"
                style={{
                  background: isTradeActive ? 'rgba(255,255,255,0.04)' : 'rgba(245,158,11,0.12)',
                  color: isTradeActive ? '#334155' : '#f59e0b',
                  border: isTradeActive ? '1px solid rgba(255,255,255,0.06)' : '1px solid rgba(245,158,11,0.25)',
                  cursor: isTradeActive ? 'not-allowed' : 'pointer',
                }}>
                <Pause size={15} />
                Pause
              </button>
              <button onClick={onStop}
                disabled={isTradeActive}
                className="flex items-center justify-center gap-2 px-4 py-3.5 rounded-xl font-bold text-sm transition-all active:scale-95"
                style={{
                  background: isTradeActive ? 'rgba(255,255,255,0.04)' : 'rgba(239,68,68,0.08)',
                  color: isTradeActive ? '#334155' : '#ef4444',
                  border: isTradeActive ? '1px solid rgba(255,255,255,0.06)' : '1px solid rgba(239,68,68,0.18)',
                  cursor: isTradeActive ? 'not-allowed' : 'pointer',
                }}>
                <Square size={14} />
              </button>
            </>
          )}

          {isPaused && (
            <>
              <button onClick={onResume}
                className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-bold text-sm transition-all active:scale-95"
                style={{
                  background: 'linear-gradient(135deg, #059669, #10b981)',
                  color: '#fff',
                  border: '1px solid #10b981',
                  boxShadow: '0 0 18px rgba(16,185,129,0.25)',
                }}>
                <Play size={15} className="fill-white" />
                Resume
              </button>
              <button onClick={onStop}
                className="flex items-center justify-center gap-2 px-4 py-3.5 rounded-xl font-bold text-sm transition-all active:scale-95"
                style={{
                  background: 'rgba(239,68,68,0.08)',
                  color: '#ef4444',
                  border: '1px solid rgba(239,68,68,0.18)',
                }}>
                <Square size={14} />
              </button>
            </>
          )}
        </div>

        {isRunning && isTradeActive && (
          <p className="text-center text-2xs mt-2" style={{ color: '#475569' }}>
            <Zap size={9} className="inline mr-1" style={{ color: '#06b6d4' }} />
            Trade in progress — controls locked
          </p>
        )}
      </div>
    </div>
  );
}
