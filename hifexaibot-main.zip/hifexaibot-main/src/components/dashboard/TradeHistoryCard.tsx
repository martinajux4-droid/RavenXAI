import { useState } from 'react';
import { TrendingUp, TrendingDown, ChevronDown, DollarSign, Clock, Target, Shield } from 'lucide-react';
import { Trade } from '../../lib/supabase';

const CONTRACT_META: Record<string, { label: string; dir: 'up' | 'dn' | 'neutral' }> = {
  CALL:       { label: 'RISE',   dir: 'up' },
  PUT:        { label: 'FALL',   dir: 'dn' },
  DIGITEVEN:  { label: 'EVEN',   dir: 'up' },
  DIGITODD:   { label: 'ODD',    dir: 'dn' },
  DIGITOVER:  { label: 'OVER',   dir: 'up' },
  DIGITUNDER: { label: 'UNDER',  dir: 'dn' },
  DIGITMATCH: { label: 'MATCH',  dir: 'up' },
  DIGITDIFF:  { label: 'DIFFER', dir: 'dn' },
};

type Props = { trade: Trade; isNew?: boolean };

export default function TradeHistoryCard({ trade, isNew }: Props) {
  const [expanded, setExpanded] = useState(false);

  const won   = trade.result === 'won';
  const lost  = trade.result === 'lost';
  const open  = trade.result === 'open';
  const ct    = CONTRACT_META[trade.contract_type] ?? { label: trade.contract_type, dir: 'neutral' as const };

  const accent    = won ? '#00ff88' : lost ? '#ff3355' : '#ffaa00';
  const accentRgb = won ? '0,255,136' : lost ? '255,51,85' : '255,170,0';

  const resultLabel = won ? 'WON' : lost ? 'LOST' : 'OPEN';
  const plPos = trade.profit_loss >= 0;

  const fmt = (ts: string) => {
    const d = new Date(ts);
    return d.toLocaleTimeString('en', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  return (
    <div className={`rounded-2xl overflow-hidden transition-all duration-300 ${isNew ? 'anim-slide-left' : ''}`}
      style={{
        background: `rgba(${accentRgb},0.04)`,
        border: `1px solid rgba(${accentRgb},0.15)`,
        boxShadow: isNew ? `0 0 20px rgba(${accentRgb},0.1)` : 'none',
      }}>

      {/* Left accent bar */}
      <div className="flex">
        <div className="w-0.5 shrink-0"
          style={{ background: accent, boxShadow: `0 0 6px ${accent}` }} />

        <div className="flex-1 min-w-0">
          {/* Main row */}
          <button
            onClick={() => setExpanded(v => !v)}
            className="w-full flex items-center gap-3 px-3 py-3 text-left">

            {/* Result badge */}
            <div className="flex flex-col items-center shrink-0 w-10">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{
                  background: `rgba(${accentRgb},0.1)`,
                  border: `1px solid rgba(${accentRgb},0.22)`,
                  boxShadow: open ? `0 0 8px rgba(${accentRgb},0.15)` : 'none',
                }}>
                {won
                  ? <TrendingUp size={14} style={{ color: accent, filter: `drop-shadow(0 0 4px ${accent})` }} />
                  : lost
                  ? <TrendingDown size={14} style={{ color: accent, filter: `drop-shadow(0 0 4px ${accent})` }} />
                  : <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: '#ffaa00', boxShadow: '0 0 6px #ffaa00' }} />}
              </div>
              <span className="text-2xs font-black mt-0.5"
                style={{ color: accent, textShadow: `0 0 6px rgba(${accentRgb},0.5)` }}>
                {resultLabel}
              </span>
            </div>

            {/* Symbol + contract */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 mb-0.5">
                <span className="text-sm font-black t-sub truncate">{trade.symbol}</span>
                <span className="text-2xs font-black px-1.5 py-0.5 rounded shrink-0"
                  style={{
                    background: ct.dir === 'up' ? 'rgba(0,255,136,0.08)' : ct.dir === 'dn' ? 'rgba(255,51,85,0.08)' : 'rgba(255,170,0,0.08)',
                    color: ct.dir === 'up' ? '#00ff88' : ct.dir === 'dn' ? '#ff3355' : '#ffaa00',
                    border: ct.dir === 'up' ? '1px solid rgba(0,255,136,0.15)' : ct.dir === 'dn' ? '1px solid rgba(255,51,85,0.15)' : '1px solid rgba(255,170,0,0.15)',
                  }}>
                  {ct.label}
                </span>
              </div>
              <div className="flex items-center gap-2 text-2xs t-muted">
                <DollarSign size={9} />
                <span>${trade.stake.toFixed(2)} stake</span>
                {trade.created_at && (
                  <>
                    <span>·</span>
                    <Clock size={9} />
                    <span>{fmt(trade.created_at)}</span>
                  </>
                )}
              </div>
            </div>

            {/* P&L + expand */}
            <div className="flex items-center gap-2 shrink-0">
              <div className="text-right">
                <p className="text-base font-black font-mono leading-none"
                  style={{
                    color: accent,
                    textShadow: `0 0 10px rgba(${accentRgb},0.6)`,
                  }}>
                  {trade.profit_loss >= 0 ? '+' : ''}{trade.profit_loss.toFixed(2)}
                </p>
                {!open && (
                  <p className="text-2xs font-bold mt-0.5"
                    style={{ color: `rgba(${accentRgb},0.45)` }}>
                    {((Math.abs(trade.profit_loss) / trade.stake) * 100).toFixed(1)}%
                  </p>
                )}
              </div>
              <ChevronDown size={12} className={`t-muted transition-transform duration-200 ${expanded ? 'rotate-180' : ''}`} />
            </div>
          </button>

          {/* Expanded detail */}
          {expanded && (
            <div className="px-3 pb-3 anim-fade-up">
              <div className="h-px mb-3" style={{ background: `rgba(${accentRgb},0.08)` }} />
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: 'Contract', val: trade.contract_type, icon: <TrendingUp size={10} /> },
                  { label: 'Payout',   val: `$${trade.payout.toFixed(2)}`, icon: <Target size={10} /> },
                  { label: 'Entry',    val: trade.entry_price?.toFixed(3) ?? '—', icon: <Shield size={10} /> },
                  { label: 'Exit',     val: trade.exit_price?.toFixed(3)  ?? '—', icon: <Shield size={10} /> },
                ].map(s => (
                  <div key={s.label} className="flex items-center gap-2 px-3 py-2 rounded-xl"
                    style={{ background: `rgba(${accentRgb},0.04)`, border: `1px solid rgba(${accentRgb},0.08)` }}>
                    <span style={{ color: `rgba(${accentRgb},0.4)` }}>{s.icon}</span>
                    <div>
                      <p className="text-2xs t-muted">{s.label}</p>
                      <p className="text-xs font-black font-mono" style={{ color: `rgba(${accentRgb},0.7)` }}>{s.val}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
