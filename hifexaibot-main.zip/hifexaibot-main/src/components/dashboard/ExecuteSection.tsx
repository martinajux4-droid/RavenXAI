import { useEffect, useRef, useState } from 'react';
import {
  TrendingUp, TrendingDown, Zap, Clock, Shield, Target,
  Activity, ArrowRight, Square, Play, Repeat2,
} from 'lucide-react';
import { AIAnalysis } from '../../lib/aiEngine';
import { Trade } from '../../lib/supabase';
import { RiskConfig } from './RiskPanel';

type Props = {
  analysis:          AIAnalysis | null;
  currentPrice:      number | null;
  activeTrade:       Trade | null;
  liveProfit:        number;
  liveCurrentSpot:   number | null;
  liveEntrySpot:     number | null;
  riskConfig:        RiskConfig;
  sessionActive:     boolean;
  autoContractType:  string | null;
  balance:           number | null;
  currency:          string;
  martingaleStake:   number | null;
  consecutiveLosses: number;
  sessionPL:         number;
  onExecute:         () => void;
  onStartSession:    () => void;
  onStopSession:     () => void;
};

const CONTRACT_META: Record<string, { label: string; dir: 'up' | 'dn' }> = {
  CALL:       { label: 'RISE',   dir: 'up' },
  PUT:        { label: 'FALL',   dir: 'dn' },
  DIGITEVEN:  { label: 'EVEN',   dir: 'up' },
  DIGITODD:   { label: 'ODD',    dir: 'dn' },
  DIGITOVER:  { label: 'OVER',   dir: 'up' },
  DIGITUNDER: { label: 'UNDER',  dir: 'dn' },
  DIGITMATCH: { label: 'MATCH',  dir: 'up' },
  DIGITDIFF:  { label: 'DIFFER', dir: 'dn' },
};

export default function ExecuteSection({
  analysis, currentPrice, activeTrade, liveProfit,
  liveCurrentSpot, liveEntrySpot, riskConfig, sessionActive,
  autoContractType, balance, currency, martingaleStake,
  consecutiveLosses, sessionPL,
  onExecute, onStartSession, onStopSession,
}: Props) {
  const [elapsed, setElapsed]           = useState(0);
  const [priceFlash, setPriceFlash]     = useState<'up' | 'dn' | null>(null);
  const [balFlash, setBalFlash]         = useState<'up' | 'dn' | null>(null);
  const [prevBal, setPrevBal]           = useState<number | null>(null);
  const startRef    = useRef<number | null>(null);
  const rafRef      = useRef<number>(0);
  const prevSpotRef = useRef<number | null>(null);

  /* Tick timer */
  useEffect(() => {
    if (!activeTrade) {
      setElapsed(0); startRef.current = null;
      cancelAnimationFrame(rafRef.current); return;
    }
    startRef.current = Date.now();
    const loop = () => {
      setElapsed(Math.floor((Date.now() - (startRef.current ?? Date.now())) / 1000));
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [activeTrade?.id]);

  /* Price flash */
  useEffect(() => {
    const cur = liveCurrentSpot ?? currentPrice;
    if (cur !== null && prevSpotRef.current !== null && cur !== prevSpotRef.current) {
      setPriceFlash(cur > prevSpotRef.current ? 'up' : 'dn');
      const t = setTimeout(() => setPriceFlash(null), 350);
      return () => clearTimeout(t);
    }
    prevSpotRef.current = cur;
  }, [liveCurrentSpot, currentPrice]);

  /* Balance flash */
  useEffect(() => {
    if (balance !== null && prevBal !== null && balance !== prevBal) {
      setBalFlash(balance > prevBal ? 'up' : 'dn');
      const t = setTimeout(() => setBalFlash(null), 1200);
      return () => clearTimeout(t);
    }
    if (balance !== null) setPrevBal(balance);
  }, [balance, prevBal]);

  const duration       = activeTrade ? activeTrade.duration : riskConfig.ticks * 2;
  const ticksLeft      = activeTrade ? Math.max(0, Math.ceil((duration - elapsed) / 2)) : riskConfig.ticks;
  const progPct        = activeTrade ? Math.min(100, (elapsed / duration) * 100) : 0;
  const profitPos      = liveProfit >= 0;
  const hasSignal      = !!analysis && analysis.confidence >= 55 && analysis.signal !== 'NEUTRAL';
  const confidence     = analysis?.confidence ?? 0;
  const signal         = analysis?.signal;
  const displayPrice   = liveCurrentSpot ?? currentPrice;
  const ctMeta         = autoContractType ? CONTRACT_META[autoContractType] : null;
  const effectiveStake = martingaleStake ?? riskConfig.stake;
  const profitPct      = activeTrade && activeTrade.stake > 0
    ? ((liveProfit / activeTrade.stake) * 100).toFixed(1)
    : '0';

  /* SL/TP proximity during live trade */
  const slProximity = riskConfig.stopLoss  !== null && activeTrade
    ? liveProfit <= -(riskConfig.stopLoss * 0.75) : false;
  const tpProximity = riskConfig.takeProfit !== null && activeTrade
    ? liveProfit >=  (riskConfig.takeProfit * 0.75) : false;

  return (
    <div className="flex flex-col gap-4">

      {/* ── Balance + session PL bar ── */}
      {(balance !== null || sessionActive) && (
        <div className="grid grid-cols-2 gap-2">
          {balance !== null && (
            <div className="flex flex-col px-4 py-3 rounded-2xl"
              style={{
                background: 'rgba(0,8,4,0.6)',
                border: balFlash === 'up' ? '1px solid rgba(0,255,136,0.25)' : balFlash === 'dn' ? '1px solid rgba(255,51,85,0.25)' : '1px solid rgba(0,255,136,0.08)',
                boxShadow: balFlash === 'up' ? '0 0 20px rgba(0,255,136,0.1)' : balFlash === 'dn' ? '0 0 20px rgba(255,51,85,0.1)' : 'none',
                backdropFilter: 'blur(20px)',
                transition: 'border-color 0.3s, box-shadow 0.3s',
              }}>
              <p className="text-2xs t-muted mb-0.5">Balance</p>
              <span className="text-xl font-black font-mono"
                style={{
                  color: balFlash === 'up' ? '#00ff88' : balFlash === 'dn' ? '#ff3355' : 'rgba(0,255,136,0.8)',
                  textShadow: balFlash === 'up' ? '0 0 20px rgba(0,255,136,0.9)' : balFlash === 'dn' ? '0 0 20px rgba(255,51,85,0.8)' : 'none',
                }}>
                {balance.toFixed(2)}
              </span>
              <span className="text-2xs t-muted">{currency}</span>
            </div>
          )}
          <div className="flex flex-col px-4 py-3 rounded-2xl"
            style={{
              background: sessionPL >= 0 ? 'rgba(0,255,136,0.04)' : 'rgba(255,51,85,0.04)',
              border: sessionPL >= 0 ? '1px solid rgba(0,255,136,0.1)' : '1px solid rgba(255,51,85,0.1)',
              backdropFilter: 'blur(20px)',
            }}>
            <p className="text-2xs t-muted mb-0.5">Session P&L</p>
            <span className="text-xl font-black font-mono"
              style={{
                color: sessionPL >= 0 ? '#00ff88' : '#ff3355',
                textShadow: sessionPL >= 0 ? '0 0 12px rgba(0,255,136,0.6)' : '0 0 12px rgba(255,51,85,0.6)',
              }}>
              {sessionPL >= 0 ? '+' : ''}{sessionPL.toFixed(2)}
            </span>
            {consecutiveLosses > 0 && (
              <span className="text-2xs font-black mt-0.5" style={{ color: 'rgba(255,170,0,0.7)' }}>
                {consecutiveLosses} losses
              </span>
            )}
          </div>
        </div>
      )}

      {/* ── Live price card ── */}
      <div className="flex items-center justify-between px-4 py-3 rounded-2xl"
        style={{
          background: 'rgba(0,8,4,0.6)',
          border: activeTrade
            ? profitPos ? '1px solid rgba(0,255,136,0.18)' : '1px solid rgba(255,51,85,0.18)'
            : '1px solid rgba(0,255,136,0.08)',
          backdropFilter: 'blur(20px)',
        }}>
        <div>
          <p className="text-2xs t-muted mb-1">{activeTrade ? 'Current Spot' : 'Live Price'}</p>
          <span className="text-3xl font-black font-mono transition-colors duration-100"
            style={{
              color: priceFlash === 'up' ? '#00ff88' : priceFlash === 'dn' ? '#ff3355' : 'rgba(0,255,136,0.75)',
              textShadow: priceFlash
                ? priceFlash === 'up' ? '0 0 24px rgba(0,255,136,0.9)' : '0 0 24px rgba(255,51,85,0.9)'
                : 'none',
            }}>
            {displayPrice !== null ? displayPrice.toFixed(3) : '—'}
          </span>
          {activeTrade && liveEntrySpot !== null && (
            <div className="flex items-center gap-1.5 mt-1">
              <span className="text-2xs t-muted">Entry</span>
              <span className="text-2xs font-black font-mono" style={{ color: 'rgba(0,255,136,0.5)' }}>
                {liveEntrySpot.toFixed(3)}
              </span>
              <ArrowRight size={9} style={{ color: 'rgba(0,255,136,0.3)' }} />
              <span className="text-2xs font-black font-mono"
                style={{ color: profitPos ? 'rgba(0,255,136,0.7)' : 'rgba(255,51,85,0.7)' }}>
                {displayPrice?.toFixed(3) ?? '—'}
              </span>
            </div>
          )}
        </div>

        <div className="flex flex-col items-end gap-1.5">
          {activeTrade ? (
            <>
              <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl"
                style={{
                  background: profitPos ? 'rgba(0,255,136,0.09)' : 'rgba(255,51,85,0.09)',
                  border: profitPos ? '1px solid rgba(0,255,136,0.22)' : '1px solid rgba(255,51,85,0.22)',
                }}>
                {profitPos
                  ? <TrendingUp size={11} style={{ color: '#00ff88' }} />
                  : <TrendingDown size={11} style={{ color: '#ff3355' }} />}
                <span className="text-xs font-black"
                  style={{ color: profitPos ? '#00ff88' : '#ff3355', textShadow: profitPos ? '0 0 8px rgba(0,255,136,0.7)' : '0 0 8px rgba(255,51,85,0.7)' }}>
                  {CONTRACT_META[activeTrade.contract_type]?.label ?? activeTrade.contract_type}
                </span>
              </div>
              <span className="text-xs font-black font-mono"
                style={{ color: profitPos ? 'rgba(0,255,136,0.6)' : 'rgba(255,51,85,0.6)' }}>
                {profitPos ? '+' : ''}{profitPct}%
              </span>
            </>
          ) : analysis ? (
            <>
              <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl"
                style={{
                  background: hasSignal ? signal === 'CALL' ? 'rgba(0,255,136,0.08)' : 'rgba(255,51,85,0.08)' : 'rgba(255,170,0,0.06)',
                  border: hasSignal ? signal === 'CALL' ? '1px solid rgba(0,255,136,0.22)' : '1px solid rgba(255,51,85,0.22)' : '1px solid rgba(255,170,0,0.15)',
                }}>
                {signal === 'CALL' ? <TrendingUp size={11} style={{ color: '#00ff88' }} />
                  : signal === 'PUT' ? <TrendingDown size={11} style={{ color: '#ff3355' }} />
                  : null}
                <span className="text-xs font-black"
                  style={{ color: signal === 'CALL' ? '#00ff88' : signal === 'PUT' ? '#ff3355' : '#ffaa00' }}>
                  {signal === 'CALL' ? 'RISE' : signal === 'PUT' ? 'FALL' : 'WAIT'}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <div className="h-1.5 w-16 rounded-full overflow-hidden" style={{ background: 'rgba(0,255,136,0.07)' }}>
                  <div className="h-full rounded-full"
                    style={{
                      width: `${confidence}%`,
                      background: confidence >= 61 ? '#00ff88' : confidence >= 45 ? '#ffaa00' : '#ff3355',
                      boxShadow: confidence >= 61 ? '0 0 6px rgba(0,255,136,0.5)' : 'none',
                    }} />
                </div>
                <span className="text-2xs font-black font-mono"
                  style={{ color: confidence >= 61 ? '#00ff88' : confidence >= 45 ? '#ffaa00' : 'rgba(0,255,136,0.3)' }}>
                  {confidence}%
                </span>
              </div>
            </>
          ) : null}
        </div>
      </div>

      {/* ── LIVE TRADE PANEL ── */}
      {activeTrade && (
        <div className="rounded-2xl overflow-hidden anim-scale-in"
          style={{
            background: 'rgba(0,4,2,0.95)',
            border: profitPos ? '1px solid rgba(0,255,136,0.35)' : '1px solid rgba(255,51,85,0.35)',
            boxShadow: profitPos
              ? '0 0 50px rgba(0,255,136,0.15), 0 0 100px rgba(0,255,136,0.06)'
              : '0 0 50px rgba(255,51,85,0.15), 0 0 100px rgba(255,51,85,0.06)',
            backdropFilter: 'blur(30px)',
          }}>

          {/* Animated sweep line on top */}
          <div className="h-0.5 relative overflow-hidden"
            style={{ background: profitPos ? 'rgba(0,255,136,0.12)' : 'rgba(255,51,85,0.12)' }}>
            <div className="absolute inset-0"
              style={{
                background: profitPos
                  ? 'linear-gradient(90deg, transparent, #00ff88, transparent)'
                  : 'linear-gradient(90deg, transparent, #ff3355, transparent)',
                boxShadow: profitPos ? '0 0 10px #00ff88' : '0 0 10px #ff3355',
                animation: 'sweepLine 2.5s linear infinite',
              }} />
          </div>

          <div className="p-5 space-y-4">

            {/* Header */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="relative w-2.5 h-2.5">
                  <div className="absolute inset-0 rounded-full" style={{ background: '#00ff88', boxShadow: '0 0 8px #00ff88' }} />
                  <div className="absolute inset-0 rounded-full animate-ping" style={{ background: '#00ff88', opacity: 0.4 }} />
                </div>
                <span className="text-xs font-black tracking-widest" style={{ color: '#00ff88', textShadow: '0 0 8px rgba(0,255,136,0.5)' }}>
                  LIVE TRADE
                </span>
                <span className="text-2xs font-black px-1.5 py-0.5 rounded"
                  style={{
                    background: profitPos ? 'rgba(0,255,136,0.1)' : 'rgba(255,51,85,0.1)',
                    color: profitPos ? '#00ff88' : '#ff3355',
                    border: profitPos ? '1px solid rgba(0,255,136,0.2)' : '1px solid rgba(255,51,85,0.2)',
                  }}>
                  {CONTRACT_META[activeTrade.contract_type]?.label ?? activeTrade.contract_type}
                </span>
              </div>
              {/* Tick countdown */}
              <div className="flex flex-col items-end">
                <div className="flex items-center gap-1.5">
                  <Clock size={11} style={{ color: ticksLeft <= 2 ? '#ff3355' : 'rgba(0,255,136,0.5)' }} />
                  <span className="text-2xl font-black font-mono"
                    style={{
                      color: ticksLeft <= 2 ? '#ff3355' : 'rgba(0,255,136,0.9)',
                      textShadow: ticksLeft <= 2 ? '0 0 14px rgba(255,51,85,0.8)' : '0 0 8px rgba(0,255,136,0.4)',
                      animation: ticksLeft <= 3 ? 'tickBeat 0.6s ease-in-out infinite' : 'none',
                    }}>
                    {ticksLeft}
                  </span>
                </div>
                <span className="text-2xs t-muted">ticks left</span>
              </div>
            </div>

            {/* HUGE P&L */}
            <div className="text-center py-3">
              <div className="text-6xl font-black font-mono leading-none transition-all"
                style={{
                  color: profitPos ? '#00ff88' : '#ff3355',
                  textShadow: profitPos
                    ? '0 0 30px rgba(0,255,136,0.9), 0 0 60px rgba(0,255,136,0.3), 0 0 100px rgba(0,255,136,0.1)'
                    : '0 0 30px rgba(255,51,85,0.9), 0 0 60px rgba(255,51,85,0.3), 0 0 100px rgba(255,51,85,0.1)',
                  letterSpacing: '-0.03em',
                  animation: 'neonPulse 1.5s ease-in-out infinite',
                }}>
                {profitPos ? '+' : ''}{liveProfit.toFixed(2)}
              </div>
              <div className="flex items-center justify-center gap-3 mt-2">
                <span className="text-sm font-black font-mono"
                  style={{ color: profitPos ? 'rgba(0,255,136,0.5)' : 'rgba(255,51,85,0.5)' }}>
                  {profitPos ? '+' : ''}{profitPct}%
                </span>
                <span className="text-2xs t-muted">on ${activeTrade.stake.toFixed(2)} stake</span>
              </div>
            </div>

            {/* Progress bar */}
            <div>
              <div className="flex justify-between mb-1.5">
                <span className="text-2xs t-muted">Execution Progress</span>
                <span className="text-2xs font-mono t-muted">{elapsed}s / {duration}s</span>
              </div>
              <div className="h-2 rounded-full overflow-hidden relative" style={{ background: 'rgba(0,255,136,0.06)' }}>
                <div className="h-full rounded-full relative overflow-hidden"
                  style={{
                    width: `${progPct}%`,
                    background: profitPos ? 'linear-gradient(90deg, #00aa55, #00ff88)' : 'linear-gradient(90deg, #aa2233, #ff3355)',
                    boxShadow: profitPos ? '0 0 10px rgba(0,255,136,0.7)' : '0 0 10px rgba(255,51,85,0.7)',
                    transition: 'width 0.5s linear',
                  }}>
                  <span className="absolute inset-0 anim-shimmer"
                    style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.22), transparent)', width: '30%' }} />
                </div>
              </div>
            </div>

            {/* Entry / Current spots */}
            <div className="grid grid-cols-2 gap-2">
              <div className="flex flex-col px-3 py-2.5 rounded-xl"
                style={{ background: 'rgba(0,255,136,0.03)', border: '1px solid rgba(0,255,136,0.08)' }}>
                <span className="text-2xs t-muted mb-0.5">Entry Spot</span>
                <span className="text-sm font-black font-mono" style={{ color: 'rgba(0,255,136,0.7)' }}>
                  {liveEntrySpot?.toFixed(3) ?? activeTrade.entry_price?.toFixed(3) ?? '—'}
                </span>
              </div>
              <div className="flex flex-col px-3 py-2.5 rounded-xl"
                style={{
                  background: profitPos ? 'rgba(0,255,136,0.05)' : 'rgba(255,51,85,0.05)',
                  border: profitPos ? '1px solid rgba(0,255,136,0.12)' : '1px solid rgba(255,51,85,0.12)',
                }}>
                <span className="text-2xs t-muted mb-0.5">Current Spot</span>
                <span className="text-sm font-black font-mono"
                  style={{ color: profitPos ? '#00ff88' : '#ff3355' }}>
                  {displayPrice?.toFixed(3) ?? '—'}
                </span>
              </div>
            </div>

            {/* TP/SL proximity warning */}
            {(slProximity || tpProximity) && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl"
                style={{
                  background: tpProximity ? 'rgba(0,255,136,0.07)' : 'rgba(255,51,85,0.07)',
                  border: tpProximity ? '1px solid rgba(0,255,136,0.22)' : '1px solid rgba(255,51,85,0.22)',
                  animation: 'borderGlow 1s ease-in-out infinite',
                }}>
                {tpProximity
                  ? <><Target size={12} style={{ color: '#00ff88' }} /><span className="text-xs font-black t-green ml-1">Approaching Take Profit</span></>
                  : <><Shield size={12} style={{ color: '#ff3355' }} /><span className="text-xs font-black ml-1" style={{ color: '#ff3355' }}>Approaching Stop Loss</span></>}
              </div>
            )}

            {/* TP / SL display bars */}
            {(riskConfig.stopLoss !== null || riskConfig.takeProfit !== null) && (
              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl"
                  style={{
                    background: 'rgba(255,51,85,0.04)',
                    border: slProximity ? '1px solid rgba(255,51,85,0.35)' : '1px solid rgba(255,51,85,0.1)',
                    boxShadow: slProximity ? '0 0 12px rgba(255,51,85,0.2)' : 'none',
                  }}>
                  <Shield size={10} style={{ color: '#ff3355' }} />
                  <span className="text-2xs t-muted">SL</span>
                  <span className="text-xs font-black font-mono ml-auto" style={{ color: '#ff3355' }}>
                    {riskConfig.stopLoss !== null ? `-$${riskConfig.stopLoss}` : 'Off'}
                  </span>
                </div>
                <div className="flex items-center gap-1.5 px-3 py-2 rounded-xl"
                  style={{
                    background: 'rgba(0,255,136,0.03)',
                    border: tpProximity ? '1px solid rgba(0,255,136,0.35)' : '1px solid rgba(0,255,136,0.08)',
                    boxShadow: tpProximity ? '0 0 12px rgba(0,255,136,0.15)' : 'none',
                  }}>
                  <Target size={10} style={{ color: '#00ff88' }} />
                  <span className="text-2xs t-muted">TP</span>
                  <span className="text-xs font-black font-mono ml-auto t-green">
                    {riskConfig.takeProfit !== null ? `+$${riskConfig.takeProfit}` : 'Off'}
                  </span>
                </div>
              </div>
            )}

            {/* Martingale alert */}
            {martingaleStake !== null && (
              <div className="flex items-center gap-2 px-3 py-2 rounded-xl animate-pulse"
                style={{ background: 'rgba(0,212,255,0.06)', border: '1px solid rgba(0,212,255,0.2)' }}>
                <Repeat2 size={11} style={{ color: '#00d4ff' }} />
                <span className="text-xs font-black" style={{ color: '#00d4ff' }}>
                  Next stake: ${martingaleStake.toFixed(2)}
                </span>
                <span className="text-2xs t-muted ml-auto">Martingale</span>
              </div>
            )}

            {/* Trade meta */}
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'Symbol', val: activeTrade.symbol.replace('_', ' ') },
                { label: 'Stake',  val: `$${activeTrade.stake.toFixed(2)}` },
                { label: 'Payout', val: `$${(activeTrade.payout ?? activeTrade.stake * 1.85).toFixed(2)}` },
              ].map(s => (
                <div key={s.label} className="flex flex-col items-center py-2 rounded-xl"
                  style={{ background: 'rgba(0,255,136,0.03)', border: '1px solid rgba(0,255,136,0.06)' }}>
                  <span className="text-2xs t-muted">{s.label}</span>
                  <span className="text-xs font-black font-mono mt-0.5 t-sub">{s.val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Session controls ── */}
      {!activeTrade && (
        <div className="space-y-3">

          {/* Session start / stop */}
          {!sessionActive ? (
            <button onClick={onStartSession}
              className="group relative w-full py-4 rounded-2xl font-black text-sm uppercase tracking-widest overflow-hidden transition-all active:scale-[0.98]"
              style={{
                background: 'linear-gradient(135deg, rgba(0,255,136,0.12), rgba(0,200,100,0.05))',
                border: '1px solid rgba(0,255,136,0.28)',
                color: '#00ff88',
                textShadow: '0 0 12px rgba(0,255,136,0.7)',
                boxShadow: '0 0 28px rgba(0,255,136,0.1)',
              }}>
              <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 pointer-events-none"
                style={{ background: 'linear-gradient(90deg, transparent, rgba(0,255,136,0.07), transparent)', width: '40%' }} />
              <div className="flex items-center justify-center gap-2.5">
                <Play size={16} style={{ filter: 'drop-shadow(0 0 5px #00ff88)' }} />
                Activate Trading Session
              </div>
            </button>
          ) : (
            <div className="flex gap-2">
              {/* EXECUTE TRADE */}
              <button
                onClick={onExecute}
                disabled={!hasSignal}
                className="group relative flex-1 rounded-2xl overflow-hidden transition-all active:scale-[0.97]"
                style={{
                  padding: '1.1rem 1rem',
                  background: hasSignal
                    ? signal === 'CALL'
                      ? 'linear-gradient(135deg, rgba(0,255,136,0.2), rgba(0,180,100,0.08))'
                      : 'linear-gradient(135deg, rgba(255,51,85,0.2), rgba(180,20,50,0.08))'
                    : 'rgba(0,8,4,0.5)',
                  border: hasSignal
                    ? signal === 'CALL' ? '1px solid rgba(0,255,136,0.5)' : '1px solid rgba(255,51,85,0.5)'
                    : '1px solid rgba(0,255,136,0.08)',
                  boxShadow: hasSignal
                    ? signal === 'CALL'
                      ? '0 0 50px rgba(0,255,136,0.22), 0 0 100px rgba(0,255,136,0.07)'
                      : '0 0 50px rgba(255,51,85,0.22), 0 0 100px rgba(255,51,85,0.07)'
                    : 'none',
                  cursor: hasSignal ? 'pointer' : 'not-allowed',
                }}>

                {hasSignal && (
                  <>
                    <div className="absolute top-0 left-0 right-0 h-px"
                      style={{
                        background: signal === 'CALL'
                          ? 'linear-gradient(90deg, transparent, rgba(0,255,136,1), transparent)'
                          : 'linear-gradient(90deg, transparent, rgba(255,51,85,1), transparent)',
                      }} />
                    <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 pointer-events-none"
                      style={{
                        background: `linear-gradient(90deg, transparent, ${signal === 'CALL' ? 'rgba(0,255,136,0.1)' : 'rgba(255,51,85,0.1)'}, transparent)`,
                        width: '40%',
                      }} />
                  </>
                )}

                {hasSignal ? (
                  <div className="flex flex-col items-center gap-1">
                    {signal === 'CALL'
                      ? <TrendingUp size={22} style={{ color: '#00ff88', filter: 'drop-shadow(0 0 8px #00ff88)' }} />
                      : <TrendingDown size={22} style={{ color: '#ff3355', filter: 'drop-shadow(0 0 8px #ff3355)' }} />}
                    <span className="text-lg font-black tracking-widest"
                      style={{
                        color: signal === 'CALL' ? '#00ff88' : '#ff3355',
                        textShadow: signal === 'CALL'
                          ? '0 0 16px rgba(0,255,136,1), 0 0 32px rgba(0,255,136,0.5)'
                          : '0 0 16px rgba(255,51,85,1), 0 0 32px rgba(255,51,85,0.5)',
                        letterSpacing: '0.1em',
                      }}>
                      EXECUTE
                    </span>
                    <span className="text-2xs font-bold"
                      style={{ color: signal === 'CALL' ? 'rgba(0,255,136,0.5)' : 'rgba(255,51,85,0.5)' }}>
                      {ctMeta?.label} · ${effectiveStake} · {riskConfig.ticks}T
                    </span>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-1">
                    <Activity size={16} style={{ color: 'rgba(0,255,136,0.2)' }} />
                    <span className="text-xs font-black tracking-widest t-muted">AWAITING SIGNAL</span>
                  </div>
                )}
              </button>

              {/* STOP SESSION */}
              <button onClick={onStopSession}
                className="flex flex-col items-center justify-center gap-1 px-4 py-3 rounded-2xl transition-all"
                style={{
                  background: 'rgba(255,51,85,0.06)',
                  border: '1px solid rgba(255,51,85,0.15)',
                  color: '#ff3355',
                  minWidth: 64,
                }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,51,85,0.1)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,51,85,0.06)')}>
                <Square size={14} style={{ color: '#ff3355' }} />
                <span className="text-2xs font-black">STOP</span>
              </button>
            </div>
          )}

          {/* No signal hint */}
          {sessionActive && !hasSignal && (
            <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl"
              style={{ background: 'rgba(255,170,0,0.05)', border: '1px solid rgba(255,170,0,0.15)' }}>
              <Activity size={12} style={{ color: '#ffaa00' }} />
              <span className="text-xs font-bold" style={{ color: 'rgba(255,170,0,0.85)' }}>
                {analysis ? `AI confidence ${confidence}% — below 55% threshold` : 'Scan markets first to get a signal'}
              </span>
            </div>
          )}

          {/* AI contract preview */}
          {sessionActive && hasSignal && ctMeta && (
            <div className="flex items-center gap-3 px-4 py-3 rounded-2xl"
              style={{
                background: ctMeta.dir === 'up' ? 'rgba(0,255,136,0.04)' : 'rgba(255,51,85,0.04)',
                border: ctMeta.dir === 'up' ? '1px solid rgba(0,255,136,0.16)' : '1px solid rgba(255,51,85,0.16)',
              }}>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
                style={{
                  background: ctMeta.dir === 'up' ? 'rgba(0,255,136,0.1)' : 'rgba(255,51,85,0.1)',
                  border: ctMeta.dir === 'up' ? '1px solid rgba(0,255,136,0.2)' : '1px solid rgba(255,51,85,0.2)',
                }}>
                {ctMeta.dir === 'up'
                  ? <TrendingUp size={16} style={{ color: '#00ff88', filter: 'drop-shadow(0 0 5px #00ff88)' }} />
                  : <TrendingDown size={16} style={{ color: '#ff3355', filter: 'drop-shadow(0 0 5px #ff3355)' }} />}
              </div>
              <div className="flex-1">
                <p className="text-2xs t-muted">AI Selected Contract</p>
                <p className="text-base font-black"
                  style={{
                    color: ctMeta.dir === 'up' ? '#00ff88' : '#ff3355',
                    textShadow: ctMeta.dir === 'up' ? '0 0 10px rgba(0,255,136,0.7)' : '0 0 10px rgba(255,51,85,0.7)',
                  }}>
                  {ctMeta.label}
                </p>
              </div>
              <div className="text-right">
                <p className="text-2xs t-muted">Payout</p>
                <p className="text-sm font-black font-mono t-green">${(effectiveStake * 1.85).toFixed(2)}</p>
              </div>
            </div>
          )}

          {/* Payout breakdown */}
          {sessionActive && hasSignal && (
            <div className="grid grid-cols-4 gap-1.5">
              {[
                { label: 'Stake',  val: `$${effectiveStake.toFixed(2)}`,         col: 'rgba(0,255,136,0.6)' },
                { label: 'Payout', val: `$${(effectiveStake * 1.85).toFixed(2)}`, col: '#00ff88' },
                { label: 'ROI',    val: '85%',                                     col: '#00ff88' },
                { label: 'Ticks',  val: String(riskConfig.ticks),                  col: 'rgba(0,255,136,0.6)' },
              ].map(s => (
                <div key={s.label} className="text-center py-2.5 rounded-xl"
                  style={{ background: 'rgba(0,255,136,0.03)', border: '1px solid rgba(0,255,136,0.06)' }}>
                  <p className="text-2xs t-muted">{s.label}</p>
                  <p className="text-xs font-black font-mono mt-0.5" style={{ color: s.col }}>{s.val}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
