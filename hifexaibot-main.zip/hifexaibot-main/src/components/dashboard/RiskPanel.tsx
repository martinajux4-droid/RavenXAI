import { useState } from 'react';
import {
  DollarSign, Shield, Target, Repeat2, Clock, ChevronDown,
  ToggleLeft, ToggleRight, TrendingUp, Hash, Layers, BarChart,
} from 'lucide-react';

export type StrategyType = 'rise_fall' | 'even_odd' | 'over_under' | 'matches_differs';

export type RiskConfig = {
  stake: number;
  stopLoss: number | null;
  takeProfit: number | null;
  martingale: boolean;
  martingaleMultiplier: number;
  ticks: number;
  strategy: StrategyType;
};

const STRATEGIES = [
  { id: 'rise_fall'       as StrategyType, label: 'Rise / Fall',       icon: <TrendingUp size={13} />,  desc: 'Predict market direction' },
  { id: 'even_odd'        as StrategyType, label: 'Even / Odd',        icon: <Hash size={13} />,        desc: 'Predict last digit parity' },
  { id: 'over_under'      as StrategyType, label: 'Over / Under',      icon: <BarChart size={13} />,    desc: 'Predict digit threshold' },
  { id: 'matches_differs' as StrategyType, label: 'Matches / Differs', icon: <Layers size={13} />,     desc: 'Predict exact digit match' },
];

const QUICK_STAKES  = [1, 5, 10, 25, 50];
const TICK_OPTIONS  = [1, 2, 3, 4, 5];
const MARTI_MULTS   = [1.5, 2, 2.5, 3];

type Props = { onChange: (cfg: RiskConfig) => void };

export default function RiskPanel({ onChange }: Props) {
  const [stake,      setStakeRaw]  = useState('10');
  const [slOn,       setSlOn]      = useState(false);
  const [sl,         setSl]        = useState('20');
  const [tpOn,       setTpOn]      = useState(false);
  const [tp,         setTp]        = useState('50');
  const [marti,      setMarti]     = useState(false);
  const [martiMult,  setMartiMult] = useState(2);
  const [ticks,      setTicks]     = useState(5);
  const [strategy,   setStrategy]  = useState<StrategyType>('rise_fall');
  const [stratOpen,  setStratOpen] = useState(false);

  const stakeVal = parseFloat(stake) || 1;

  const emit = (patch: Partial<{
    stake: number; slOn: boolean; sl: string; tpOn: boolean; tp: string;
    marti: boolean; martiMult: number; ticks: number; strategy: StrategyType;
  }> = {}) => {
    const s  = patch.stake    ?? stakeVal;
    const so = patch.slOn     ?? slOn;
    const sv = patch.sl       ?? sl;
    const to = patch.tpOn     ?? tpOn;
    const tv = patch.tp       ?? tp;
    const m  = patch.marti    ?? marti;
    const mm = patch.martiMult ?? martiMult;
    const t  = patch.ticks    ?? ticks;
    const st = patch.strategy ?? strategy;
    onChange({
      stake: s,
      stopLoss:   so ? (parseFloat(sv) || null) : null,
      takeProfit: to ? (parseFloat(tv) || null) : null,
      martingale: m,
      martingaleMultiplier: mm,
      ticks: t,
      strategy: st,
    });
  };

  const curStrategy = STRATEGIES.find(s => s.id === strategy)!;

  return (
    <div className="flex flex-col gap-4">

      {/* ── Stake ── */}
      <div className="flex flex-col gap-2">
        <label className="section-label flex items-center gap-1.5">
          <DollarSign size={10} style={{ color: 'var(--green)' }} /> Stake Amount
        </label>
        <div className="relative">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-black font-mono t-green pointer-events-none">$</span>
          <input
            type="number" value={stake} min="1"
            onChange={e => { setStakeRaw(e.target.value); emit({ stake: parseFloat(e.target.value) || 1 }); }}
            className="neon-input"
            style={{ paddingLeft: '1.6rem' }}
          />
        </div>
        <div className="grid grid-cols-5 gap-1">
          {QUICK_STAKES.map(v => (
            <button key={v}
              onClick={() => { setStakeRaw(String(v)); emit({ stake: v }); }}
              className="py-1.5 rounded-lg text-2xs font-black transition-all"
              style={{
                background: stakeVal === v ? 'rgba(0,255,136,0.12)' : 'rgba(0,255,136,0.03)',
                color:      stakeVal === v ? '#00ff88' : 'rgba(0,255,136,0.3)',
                border:     stakeVal === v ? '1px solid rgba(0,255,136,0.35)' : '1px solid rgba(0,255,136,0.07)',
                textShadow: stakeVal === v ? '0 0 6px rgba(0,255,136,0.7)' : 'none',
              }}>
              ${v}
            </button>
          ))}
        </div>
      </div>

      {/* ── Stop Loss ── */}
      <div className="flex flex-col gap-2">
        <label className="section-label flex items-center gap-1.5">
          <Shield size={10} style={{ color: slOn ? '#ff3355' : 'rgba(0,255,136,0.4)' }} /> Stop Loss
        </label>
        <button
          onClick={() => { setSlOn(v => !v); emit({ slOn: !slOn }); }}
          className="flex items-center gap-2 px-3 py-2 rounded-xl transition-all"
          style={{
            background: slOn ? 'rgba(255,51,85,0.07)' : 'rgba(0,255,136,0.03)',
            border: slOn ? '1px solid rgba(255,51,85,0.22)' : '1px solid rgba(0,255,136,0.08)',
            boxShadow: slOn ? '0 0 12px rgba(255,51,85,0.1)' : 'none',
          }}>
          <span style={{ color: slOn ? '#ff3355' : 'rgba(0,255,136,0.25)' }}>
            {slOn ? <ToggleRight size={17} /> : <ToggleLeft size={17} />}
          </span>
          <span className="text-xs font-bold" style={{ color: slOn ? '#ff3355' : 'rgba(0,255,136,0.3)' }}>
            {slOn ? `Stop at $${sl} loss` : 'Disabled'}
          </span>
        </button>
        {slOn && (
          <div className="relative anim-fade-up">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-black font-mono pointer-events-none" style={{ color: '#ff3355' }}>$</span>
            <input type="number" value={sl} min="1"
              onChange={e => { setSl(e.target.value); emit({ sl: e.target.value }); }}
              className="neon-input"
              style={{ paddingLeft: '1.6rem', borderColor: 'rgba(255,51,85,0.25)', color: '#ff3355' }}
              onFocus={e => { e.target.style.borderColor = 'rgba(255,51,85,0.5)'; e.target.style.boxShadow = '0 0 14px rgba(255,51,85,0.15)'; }}
              onBlur={e  => { e.target.style.borderColor = 'rgba(255,51,85,0.25)'; e.target.style.boxShadow = 'none'; }}
            />
          </div>
        )}
      </div>

      {/* ── Take Profit ── */}
      <div className="flex flex-col gap-2">
        <label className="section-label flex items-center gap-1.5">
          <Target size={10} style={{ color: tpOn ? '#00ff88' : 'rgba(0,255,136,0.4)' }} /> Take Profit
        </label>
        <button
          onClick={() => { setTpOn(v => !v); emit({ tpOn: !tpOn }); }}
          className="flex items-center gap-2 px-3 py-2 rounded-xl transition-all"
          style={{
            background: tpOn ? 'rgba(0,255,136,0.06)' : 'rgba(0,255,136,0.03)',
            border: tpOn ? '1px solid rgba(0,255,136,0.22)' : '1px solid rgba(0,255,136,0.08)',
            boxShadow: tpOn ? '0 0 12px rgba(0,255,136,0.08)' : 'none',
          }}>
          <span style={{ color: tpOn ? '#00ff88' : 'rgba(0,255,136,0.25)' }}>
            {tpOn ? <ToggleRight size={17} /> : <ToggleLeft size={17} />}
          </span>
          <span className="text-xs font-bold" style={{ color: tpOn ? '#00ff88' : 'rgba(0,255,136,0.3)' }}>
            {tpOn ? `Close at $${tp} profit` : 'Disabled'}
          </span>
        </button>
        {tpOn && (
          <div className="relative anim-fade-up">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-black font-mono t-green pointer-events-none">$</span>
            <input type="number" value={tp} min="1"
              onChange={e => { setTp(e.target.value); emit({ tp: e.target.value }); }}
              className="neon-input"
              style={{ paddingLeft: '1.6rem' }}
            />
          </div>
        )}
      </div>

      {/* ── Strategy ── */}
      <div className="flex flex-col gap-2">
        <label className="section-label flex items-center gap-1.5">
          <TrendingUp size={10} style={{ color: 'var(--green)' }} /> Strategy
        </label>
        <div className="relative">
          <button
            onClick={() => setStratOpen(v => !v)}
            className="w-full flex items-center gap-2.5 px-3.5 py-3 rounded-xl transition-all"
            style={{
              background: 'rgba(0,255,136,0.06)',
              border: '1px solid rgba(0,255,136,0.2)',
              boxShadow: '0 0 16px rgba(0,255,136,0.06)',
            }}>
            <span className="t-green">{curStrategy.icon}</span>
            <div className="flex-1 text-left">
              <p className="text-sm font-black t-green">{curStrategy.label}</p>
              <p className="text-2xs t-muted">{curStrategy.desc}</p>
            </div>
            <ChevronDown size={13} className={`t-sub transition-transform duration-200 ${stratOpen ? 'rotate-180' : ''}`} />
          </button>

          {stratOpen && (
            <div className="absolute z-30 top-full left-0 right-0 mt-1 rounded-xl overflow-hidden anim-scale-in"
              style={{
                background: 'rgba(0,5,2,0.98)',
                border: '1px solid rgba(0,255,136,0.18)',
                boxShadow: '0 12px 50px rgba(0,0,0,0.8), 0 0 24px rgba(0,255,136,0.07)',
                backdropFilter: 'blur(40px)',
              }}>
              {STRATEGIES.map(s => (
                <button key={s.id}
                  onClick={() => { setStrategy(s.id); setStratOpen(false); emit({ strategy: s.id }); }}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left transition-all"
                  style={{
                    background: s.id === strategy ? 'rgba(0,255,136,0.07)' : 'transparent',
                    borderBottom: '1px solid rgba(0,255,136,0.05)',
                  }}
                  onMouseEnter={e => { if (s.id !== strategy) e.currentTarget.style.background = 'rgba(0,255,136,0.04)'; }}
                  onMouseLeave={e => { if (s.id !== strategy) e.currentTarget.style.background = 'transparent'; }}>
                  <span style={{ color: s.id === strategy ? '#00ff88' : 'rgba(0,255,136,0.35)' }}>{s.icon}</span>
                  <div className="flex-1">
                    <p className="text-sm font-black" style={{ color: s.id === strategy ? '#00ff88' : 'rgba(0,255,136,0.55)' }}>{s.label}</p>
                    <p className="text-2xs t-muted">{s.desc}</p>
                  </div>
                  {s.id === strategy && (
                    <span className="text-2xs font-black px-1.5 py-0.5 rounded"
                      style={{ background: 'rgba(0,255,136,0.1)', color: '#00ff88', border: '1px solid rgba(0,255,136,0.2)' }}>
                      ACTIVE
                    </span>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ── Ticks ── */}
      <div className="flex flex-col gap-2">
        <label className="section-label flex items-center gap-1.5">
          <Clock size={10} style={{ color: 'var(--green)' }} /> Duration (Ticks)
        </label>
        <div className="grid grid-cols-5 gap-1.5">
          {TICK_OPTIONS.map(t => (
            <button key={t}
              onClick={() => { setTicks(t); emit({ ticks: t }); }}
              className="py-3 rounded-xl text-sm font-black transition-all relative overflow-hidden"
              style={{
                background: ticks === t ? 'rgba(0,255,136,0.12)' : 'rgba(0,255,136,0.03)',
                color:      ticks === t ? '#00ff88' : 'rgba(0,255,136,0.3)',
                border:     ticks === t ? '1px solid rgba(0,255,136,0.4)' : '1px solid rgba(0,255,136,0.07)',
                textShadow: ticks === t ? '0 0 10px rgba(0,255,136,0.8)' : 'none',
                boxShadow:  ticks === t ? '0 0 16px rgba(0,255,136,0.15)' : 'none',
              }}>
              {ticks === t && (
                <span className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none" />
              )}
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* ── Martingale ── */}
      <div className="flex flex-col gap-2">
        <label className="section-label flex items-center gap-1.5">
          <Repeat2 size={10} style={{ color: 'var(--green)' }} /> Martingale
        </label>
        <button
          onClick={() => { setMarti(v => !v); emit({ marti: !marti }); }}
          className="flex items-center gap-2 px-3 py-2 rounded-xl transition-all"
          style={{
            background: marti ? 'rgba(0,212,255,0.06)' : 'rgba(0,255,136,0.03)',
            border: marti ? '1px solid rgba(0,212,255,0.2)' : '1px solid rgba(0,255,136,0.08)',
            boxShadow: marti ? '0 0 14px rgba(0,212,255,0.08)' : 'none',
          }}>
          <span style={{ color: marti ? '#00d4ff' : 'rgba(0,255,136,0.25)' }}>
            {marti ? <ToggleRight size={17} /> : <ToggleLeft size={17} />}
          </span>
          <span className="text-xs font-bold" style={{ color: marti ? '#00d4ff' : 'rgba(0,255,136,0.3)' }}>
            {marti ? `Double stake ${martiMult}× on loss` : 'Disabled'}
          </span>
        </button>
        {marti && (
          <div className="grid grid-cols-4 gap-1.5 anim-fade-up">
            {MARTI_MULTS.map(m => (
              <button key={m}
                onClick={() => { setMartiMult(m); emit({ martiMult: m }); }}
                className="py-2 rounded-xl text-xs font-black transition-all"
                style={{
                  background: martiMult === m ? 'rgba(0,212,255,0.1)' : 'rgba(0,212,255,0.03)',
                  color:      martiMult === m ? '#00d4ff' : 'rgba(0,212,255,0.3)',
                  border:     martiMult === m ? '1px solid rgba(0,212,255,0.3)' : '1px solid rgba(0,212,255,0.07)',
                  textShadow: martiMult === m ? '0 0 8px rgba(0,212,255,0.7)' : 'none',
                }}>
                {m}×
              </button>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
