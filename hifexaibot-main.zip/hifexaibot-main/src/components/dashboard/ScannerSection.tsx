import { useEffect, useRef, useState } from 'react';
import { ScanResult } from '../../lib/aiEngine';
import { VOLATILITY_INDICES } from '../../lib/derivApi';
import { TrendingUp, TrendingDown, Minus, Radar, Zap, Activity } from 'lucide-react';

type Props = {
  scanning: boolean;
  progress: number;
  scanResults: ScanResult[];
  bestResult: ScanResult | null;
  currentScanSymbol: string;
  onScan: () => void;
  onSelect: (r: ScanResult) => void;
  selectedSymbol: string;
};

export default function ScannerSection({
  scanning, progress, scanResults, bestResult,
  currentScanSymbol, onScan, onSelect, selectedSymbol,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef    = useRef<number>(0);
  const angleRef  = useRef(0);
  const [showAll, setShowAll] = useState(false);

  /* ── Radar canvas ── */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const S = 160, cx = S / 2, cy = S / 2, R = 66;
    canvas.width = S; canvas.height = S;

    const draw = () => {
      ctx.clearRect(0, 0, S, S);

      // Outer glow disc
      const bgGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, R + 10);
      bgGrad.addColorStop(0, scanning ? 'rgba(0,255,136,0.05)' : 'rgba(0,255,136,0.02)');
      bgGrad.addColorStop(1, 'transparent');
      ctx.beginPath(); ctx.arc(cx, cy, R + 10, 0, Math.PI * 2);
      ctx.fillStyle = bgGrad; ctx.fill();

      // Rings
      [R * 0.28, R * 0.57, R].forEach((r, i) => {
        ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2);
        ctx.strokeStyle = scanning
          ? `rgba(0,255,136,${0.1 + i * 0.07})`
          : `rgba(0,255,136,${0.04 + i * 0.03})`;
        ctx.lineWidth = 1; ctx.stroke();
      });

      // Cross lines
      ctx.strokeStyle = scanning ? 'rgba(0,255,136,0.1)' : 'rgba(0,255,136,0.04)';
      ctx.lineWidth = 0.7;
      ctx.setLineDash([2, 4]);
      [[cx - R, cy, cx + R, cy], [cx, cy - R, cx, cy + R]].forEach(([x1, y1, x2, y2]) => {
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();
      });
      ctx.setLineDash([]);

      // Sweep
      if (scanning) {
        ctx.save(); ctx.translate(cx, cy); ctx.rotate(angleRef.current);
        const g = ctx.createLinearGradient(0, 0, R, 0);
        g.addColorStop(0,   'rgba(0,255,136,0)');
        g.addColorStop(0.5, 'rgba(0,255,136,0.1)');
        g.addColorStop(1,   'rgba(0,255,136,0.45)');
        ctx.beginPath(); ctx.moveTo(0,0); ctx.arc(0,0,R,-Math.PI/3.5,0); ctx.closePath();
        ctx.fillStyle = g; ctx.fill();
        // Sweep line
        ctx.beginPath(); ctx.moveTo(0,0); ctx.lineTo(R,0);
        ctx.strokeStyle = '#00ff88'; ctx.lineWidth = 1.5;
        ctx.shadowColor = '#00ff88'; ctx.shadowBlur = 10;
        ctx.stroke(); ctx.shadowBlur = 0;
        ctx.restore();
        angleRef.current += 0.035;
      }

      // Result dots
      scanResults.forEach((res, i) => {
        const a  = (i / VOLATILITY_INDICES.length) * Math.PI * 2 - Math.PI / 2;
        const dr = R * (0.22 + (res.score / 100) * 0.72);
        const dx = cx + Math.cos(a) * dr;
        const dy = cy + Math.sin(a) * dr;
        const hi  = res.score >= 61;
        const med = res.score >= 45 && res.score < 61;
        const col = hi ? '#00ff88' : med ? '#ffaa00' : '#1a3020';
        const dotR = hi ? 4 : med ? 3 : 2;

        if (hi) {
          ctx.beginPath(); ctx.arc(dx, dy, dotR + 6, 0, Math.PI * 2);
          ctx.fillStyle = 'rgba(0,255,136,0.12)'; ctx.fill();
          ctx.shadowColor = '#00ff88'; ctx.shadowBlur = 10;
        }
        ctx.beginPath(); ctx.arc(dx, dy, dotR, 0, Math.PI * 2);
        ctx.fillStyle = col; ctx.fill();
        ctx.shadowBlur = 0;
      });

      // Center
      ctx.beginPath(); ctx.arc(cx, cy, 3.5, 0, Math.PI * 2);
      if (scanning) { ctx.shadowColor = '#00ff88'; ctx.shadowBlur = 14; }
      ctx.fillStyle = scanning ? '#00ff88' : 'rgba(0,255,136,0.25)';
      ctx.fill(); ctx.shadowBlur = 0;

      rafRef.current = requestAnimationFrame(draw);
    };
    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [scanning, scanResults]);

  const topResults = showAll ? scanResults : scanResults.slice(0, 8);

  return (
    <div className="flex flex-col gap-5">

      {/* ── BIG SCAN BUTTON ── */}
      <button onClick={onScan} disabled={scanning}
        className="group relative w-full rounded-2xl overflow-hidden transition-all duration-300 active:scale-[0.98]"
        style={{
          padding: '1.1rem 1.5rem',
          background: scanning
            ? 'rgba(0,8,4,0.8)'
            : 'linear-gradient(135deg, rgba(0,255,136,0.16) 0%, rgba(0,200,100,0.07) 100%)',
          border: scanning
            ? '1px solid rgba(0,255,136,0.12)'
            : '1px solid rgba(0,255,136,0.45)',
          boxShadow: scanning
            ? 'none'
            : '0 0 40px rgba(0,255,136,0.16), 0 0 100px rgba(0,255,136,0.05), inset 0 1px 0 rgba(0,255,136,0.12)',
        }}>

        {/* Shimmer */}
        {!scanning && (
          <span className="absolute inset-0 overflow-hidden pointer-events-none rounded-2xl">
            <span className="absolute inset-y-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700"
              style={{ width: '40%', background: 'linear-gradient(90deg, transparent, rgba(0,255,136,0.1), transparent)' }} />
          </span>
        )}

        {/* Top glow line */}
        {!scanning && (
          <div className="absolute top-0 left-0 right-0 h-px"
            style={{ background: 'linear-gradient(90deg, transparent, rgba(0,255,136,0.8), transparent)', boxShadow: '0 0 8px rgba(0,255,136,0.5)' }} />
        )}

        <div className="flex items-center justify-center gap-3">
          {scanning ? (
            <>
              <div className="relative w-5 h-5">
                <div className="absolute inset-0 rounded-full border-2 animate-spin"
                  style={{ borderColor: 'rgba(0,255,136,0.15)', borderTopColor: '#00ff88' }} />
              </div>
              <div className="flex flex-col items-start">
                <span className="text-sm font-black tracking-widest t-green">SCANNING MARKETS</span>
                <span className="text-2xs t-muted">{currentScanSymbol || 'Initializing...'} · {progress.toFixed(0)}%</span>
              </div>
            </>
          ) : (
            <>
              <Radar size={20} style={{ color: '#00ff88', filter: 'drop-shadow(0 0 6px #00ff88)' }} />
              <span className="text-base font-black tracking-widest t-green" style={{ letterSpacing: '0.12em' }}>
                SCAN ALL MARKETS
              </span>
              <Zap size={16} style={{ color: '#00ff88', filter: 'drop-shadow(0 0 4px #00ff88)' }} />
            </>
          )}
        </div>

        {/* Progress bar */}
        {scanning && (
          <div className="absolute bottom-0 left-0 right-0 h-0.5" style={{ background: 'rgba(0,255,136,0.06)' }}>
            <div className="h-full transition-all duration-300"
              style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #00cc66, #00ff88)', boxShadow: '0 0 8px #00ff88' }} />
          </div>
        )}
      </button>

      {/* ── Radar + Status ── */}
      <div className="flex items-center gap-4">
        <div className="relative shrink-0">
          <canvas ref={canvasRef} style={{ width: 100, height: 100 }} />
          {scanning && (
            <div className="absolute inset-0 rounded-full pointer-events-none anim-ping"
              style={{ border: '1px solid rgba(0,255,136,0.2)' }} />
          )}
        </div>

        <div className="flex-1 min-w-0">
          {scanning ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Activity size={12} style={{ color: '#00ff88', filter: 'drop-shadow(0 0 4px #00ff88)' }} className="anim-neon-pulse" />
                <span className="text-xs font-black t-green">Analyzing {currentScanSymbol}</span>
              </div>
              <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(0,255,136,0.07)' }}>
                <div className="h-full rounded-full transition-all duration-300"
                  style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #00cc66, #00ff88)', boxShadow: '0 0 8px rgba(0,255,136,0.5)' }} />
              </div>
              <p className="text-2xs t-muted">{scanResults.length} / {VOLATILITY_INDICES.length} markets ranked</p>
            </div>
          ) : bestResult && bestResult.score >= 61 ? (
            <div className="space-y-2 anim-fade-up">
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full anim-neon-pulse"
                  style={{ background: '#00ff88', boxShadow: '0 0 6px #00ff88' }} />
                <span className="text-2xs font-black t-green" style={{ letterSpacing: '0.12em' }}>STRONGEST SIGNAL</span>
              </div>
              <p className="text-xl font-black t-white truncate">{bestResult.displayName.replace(' Index', '')}</p>
              <div className="flex items-center gap-3">
                <span className="text-2xl font-black font-mono t-green">{bestResult.score}%</span>
                <div className="flex flex-col gap-0.5">
                  <span className="text-2xs t-muted">confidence</span>
                  <span className="text-xs font-black flex items-center gap-1"
                    style={{
                      color: bestResult.analysis.signal === 'CALL' ? '#00ff88' : '#ff3355',
                      textShadow: bestResult.analysis.signal === 'CALL' ? '0 0 8px rgba(0,255,136,0.7)' : '0 0 8px rgba(255,51,85,0.7)',
                    }}>
                    {bestResult.analysis.signal === 'CALL'
                      ? <><TrendingUp size={11} /> RISE</>
                      : <><TrendingDown size={11} /> FALL</>}
                  </span>
                </div>
              </div>
            </div>
          ) : scanResults.length > 0 ? (
            <div className="space-y-1 anim-fade-up">
              <p className="text-sm font-black" style={{ color: '#ffaa00', textShadow: '0 0 8px rgba(255,170,0,0.4)' }}>No Strong Signal</p>
              <p className="text-2xs t-muted">{scanResults.length} markets — below 61% threshold</p>
            </div>
          ) : (
            <div className="space-y-1.5">
              <p className="text-sm font-bold t-sub">Scanner Ready</p>
              <p className="text-2xs t-muted">AI will scan all {VOLATILITY_INDICES.length} volatility markets and rank them by momentum strength</p>
            </div>
          )}
        </div>
      </div>

      {/* ── Ranked results ── */}
      {scanResults.length > 0 && (
        <div className="space-y-1 anim-fade-up">
          <div className="flex items-center justify-between mb-2">
            <span className="section-label">Market Rankings</span>
            {scanResults.length > 8 && (
              <button onClick={() => setShowAll(v => !v)} className="text-2xs font-black t-green">
                {showAll ? '← Less' : `+${scanResults.length - 8} more`}
              </button>
            )}
          </div>

          {topResults.map((res, idx) => {
            const isSelected = res.symbol === selectedSymbol;
            const isHigh  = res.score >= 61;
            const isMed   = res.score >= 45 && res.score < 61;
            const col     = isHigh ? '#00ff88' : isMed ? '#ffaa00' : 'rgba(0,255,136,0.2)';
            const isCall  = res.analysis.signal === 'CALL';
            const isPut   = res.analysis.signal === 'PUT';

            return (
              <button key={res.symbol} onClick={() => onSelect(res)}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-left"
                style={{
                  background: isSelected
                    ? 'rgba(0,255,136,0.08)'
                    : isHigh ? 'rgba(0,255,136,0.03)' : 'rgba(0,255,136,0.01)',
                  border: isSelected
                    ? '1px solid rgba(0,255,136,0.25)'
                    : isHigh ? '1px solid rgba(0,255,136,0.1)' : '1px solid transparent',
                  boxShadow: isSelected ? '0 0 16px rgba(0,255,136,0.07)' : 'none',
                }}
                onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background = 'rgba(0,255,136,0.04)'; }}
                onMouseLeave={e => { if (!isSelected) e.currentTarget.style.background = isHigh ? 'rgba(0,255,136,0.03)' : 'rgba(0,255,136,0.01)'; }}>

                {/* Rank */}
                <span className="text-2xs font-black w-5 text-center shrink-0 t-muted">{idx + 1}</span>

                {/* Dot */}
                <div className="w-1.5 h-1.5 rounded-full shrink-0"
                  style={{ background: col, boxShadow: isHigh ? `0 0 6px ${col}` : 'none' }} />

                {/* Name */}
                <span className="flex-1 text-xs font-bold truncate"
                  style={{ color: isSelected ? '#00ff88' : 'rgba(0,255,136,0.55)' }}>
                  {res.displayName.replace(' Index', '')}
                </span>

                {/* Score */}
                <span className="text-xs font-black font-mono shrink-0"
                  style={{ color: col, textShadow: isHigh ? `0 0 6px ${col}` : 'none' }}>
                  {res.score}%
                </span>

                {/* Signal */}
                <span className="flex items-center gap-0.5 text-2xs font-black shrink-0 w-12 justify-end"
                  style={{ color: isCall ? '#00ff88' : isPut ? '#ff3355' : 'rgba(0,255,136,0.2)' }}>
                  {isCall ? <TrendingUp size={9}/> : isPut ? <TrendingDown size={9}/> : <Minus size={9}/>}
                  {isCall ? 'RISE' : isPut ? 'FALL' : 'NEUT'}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
