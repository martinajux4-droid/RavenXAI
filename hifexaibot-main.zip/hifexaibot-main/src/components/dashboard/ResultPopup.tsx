import { useEffect, useRef, useState } from 'react';
import { TrendingUp, TrendingDown, X, RotateCcw, DollarSign, Target, Shield, Zap, ArrowRight } from 'lucide-react';
import { AIAnalysis } from '../../lib/aiEngine';

type CloseReason = 'takeprofit' | 'stoploss' | 'expired' | null;

type Props = {
  result: 'won' | 'lost';
  profitLoss: number;
  stake: number;
  payout: number;
  symbol: string;
  contractType: string;
  entryPrice: number | null;
  exitPrice: number | null;
  newBalance: number | null;
  prevBalance: number | null;
  currency: string;
  analysis: AIAnalysis | null;
  closeReason: CloseReason;
  martingaleNext: number | null;
  onClose: () => void;
  onRetrade: () => void;
};

type Particle = {
  x: number; y: number; vx: number; vy: number;
  life: number; color: string; size: number; angle: number;
};

const CONTRACT_META: Record<string, string> = {
  CALL: 'RISE', PUT: 'FALL',
  DIGITEVEN: 'EVEN', DIGITODD: 'ODD',
  DIGITOVER: 'OVER', DIGITUNDER: 'UNDER',
  DIGITMATCH: 'MATCH', DIGITDIFF: 'DIFFER',
};

export default function ResultPopup({
  result, profitLoss, stake, payout, symbol, contractType,
  entryPrice, exitPrice, newBalance, prevBalance, currency,
  analysis, closeReason, martingaleNext,
  onClose, onRetrade,
}: Props) {
  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const rafRef      = useRef<number>(0);
  const particles   = useRef<Particle[]>([]);
  const [phase, setPhase] = useState<'flash' | 'detail'>('flash');
  const [balVisible, setBalVisible] = useState(false);

  const won       = result === 'won';
  const accent    = won ? '#00ff88' : '#ff3355';
  const accentRgb = won ? '0,255,136' : '255,51,85';
  const roi       = ((Math.abs(profitLoss) / stake) * 100).toFixed(1);
  const balDiff   = (newBalance !== null && prevBalance !== null) ? newBalance - prevBalance : null;

  /* ── Phase: flash → detail ── */
  useEffect(() => {
    const t = setTimeout(() => { setPhase('detail'); setBalVisible(true); }, 400);
    return () => clearTimeout(t);
  }, []);

  /* ── Particle burst ── */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    canvas.width  = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    const W = canvas.width, H = canvas.height;

    const N    = won ? 100 : 50;
    const cols = won
      ? ['#00ff88', '#00cc66', '#00ffaa', '#88ffcc', '#ccffee', '#ffffff']
      : ['#ff3355', '#cc1133', '#ff6677', '#ffaaaa'];

    particles.current = Array.from({ length: N }, () => {
      const angle = Math.random() * Math.PI * 2;
      const spd   = won ? 2 + Math.random() * 6 : 1.5 + Math.random() * 3.5;
      return {
        x: W / 2, y: H * 0.35,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd - (won ? 4 : 2),
        life: 1,
        color: cols[Math.floor(Math.random() * cols.length)],
        size: won ? 2 + Math.random() * 5 : 2 + Math.random() * 3.5,
        angle: Math.random() * Math.PI * 2,
      };
    });

    const animate = () => {
      ctx.clearRect(0, 0, W, H);
      particles.current = particles.current.filter(p => p.life > 0.01);
      for (const p of particles.current) {
        p.x += p.vx; p.y += p.vy;
        p.vy += won ? 0.12 : 0.16;
        p.vx *= 0.985;
        p.life -= won ? 0.013 : 0.018;
        p.angle += 0.08;

        ctx.globalAlpha = Math.max(0, p.life > 0.5 ? 1 : p.life * 2);
        ctx.fillStyle   = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur  = 5;

        if (won && p.size > 3) {
          ctx.save();
          ctx.translate(p.x, p.y); ctx.rotate(p.angle);
          ctx.fillRect(-p.size * 0.5, -p.size * 0.25, p.size, p.size * 0.5);
          ctx.restore();
        } else {
          ctx.beginPath(); ctx.arc(p.x, p.y, p.size * 0.6, 0, Math.PI * 2); ctx.fill();
        }
      }
      ctx.globalAlpha = 1; ctx.shadowBlur = 0;
      if (particles.current.length > 0) rafRef.current = requestAnimationFrame(animate);
    };
    animate();
    return () => cancelAnimationFrame(rafRef.current);
  }, [won]);

  const reasonIcon = closeReason === 'takeprofit'
    ? <Target size={12} style={{ color: '#00ff88' }} />
    : closeReason === 'stoploss'
    ? <Shield size={12} style={{ color: '#ff3355' }} />
    : <Zap size={12} style={{ color: 'rgba(0,255,136,0.5)' }} />;

  const reasonLabel = closeReason === 'takeprofit'
    ? 'Take Profit Hit'
    : closeReason === 'stoploss'
    ? 'Stop Loss Triggered'
    : 'Contract Expired';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.92)', backdropFilter: 'blur(20px)' }}
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}>

      {/* Particles */}
      <canvas ref={canvasRef} className="absolute inset-0 pointer-events-none"
        style={{ width: '100%', height: '100%' }} />

      {/* Flash phase */}
      {phase === 'flash' && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none"
          style={{ animation: 'flashBurst 0.4s ease-out forwards' }}>
          <div style={{
            width: 200, height: 200, borderRadius: '50%',
            background: `radial-gradient(circle, rgba(${accentRgb},0.35) 0%, transparent 70%)`,
            animation: 'expandFade 0.4s ease-out forwards',
          }} />
        </div>
      )}

      {/* Card */}
      {phase === 'detail' && (
        <div className="relative w-full max-w-sm anim-result-pop"
          style={{
            background: 'rgba(0,4,2,0.97)',
            border: `1px solid rgba(${accentRgb},0.35)`,
            borderRadius: '1.5rem',
            boxShadow: `0 0 80px rgba(${accentRgb},0.18), 0 0 160px rgba(${accentRgb},0.06), inset 0 1px 0 rgba(${accentRgb},0.1)`,
            backdropFilter: 'blur(40px)',
          }}>

          {/* Top bar */}
          <div className="h-1 rounded-t-[1.5rem] relative overflow-hidden"
            style={{ background: `rgba(${accentRgb},0.15)` }}>
            <div className="absolute inset-0"
              style={{
                background: `linear-gradient(90deg, transparent, ${accent}, transparent)`,
                boxShadow: `0 0 20px rgba(${accentRgb},0.8)`,
              }} />
          </div>

          {/* Close */}
          <button onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center transition-all"
            style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)', color: 'rgba(0,255,136,0.3)' }}
            onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.08)')}
            onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.04)')}>
            <X size={13} />
          </button>

          <div className="p-6 space-y-5">

            {/* ── Hero ── */}
            <div className="text-center space-y-3">
              {/* Icon ring */}
              <div className="relative w-20 h-20 mx-auto">
                <div className="absolute inset-0 rounded-full"
                  style={{
                    border: `1px solid rgba(${accentRgb},0.2)`,
                    animation: 'pingRipple 2s ease-out infinite',
                  }} />
                <div className="absolute inset-2 rounded-full"
                  style={{
                    border: `1px solid rgba(${accentRgb},0.15)`,
                    animation: 'pingRipple 2s ease-out infinite',
                    animationDelay: '0.3s',
                  }} />
                <div className="w-full h-full rounded-full flex items-center justify-center"
                  style={{
                    background: `rgba(${accentRgb},0.1)`,
                    border: `2px solid rgba(${accentRgb},0.4)`,
                    boxShadow: `0 0 30px rgba(${accentRgb},0.25), 0 0 60px rgba(${accentRgb},0.08)`,
                  }}>
                  {won
                    ? <TrendingUp size={32} style={{ color: accent, filter: `drop-shadow(0 0 10px ${accent})` }} />
                    : <TrendingDown size={32} style={{ color: accent, filter: `drop-shadow(0 0 10px ${accent})` }} />}
                </div>
              </div>

              {/* Close reason badge */}
              <div className="flex items-center justify-center">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-2xs font-black"
                  style={{
                    background: `rgba(${accentRgb},0.1)`,
                    border: `1px solid rgba(${accentRgb},0.25)`,
                    color: accent,
                  }}>
                  {reasonIcon} {reasonLabel}
                </div>
              </div>

              {/* P&L */}
              <div>
                <p className="text-2xs font-black uppercase tracking-widest mb-1"
                  style={{ color: `rgba(${accentRgb},0.5)` }}>
                  Trade {won ? 'Won' : 'Lost'}
                </p>
                <div className="text-6xl font-black font-mono leading-none"
                  style={{
                    color: accent,
                    textShadow: `0 0 30px rgba(${accentRgb},0.9), 0 0 60px rgba(${accentRgb},0.4)`,
                    letterSpacing: '-0.02em',
                  }}>
                  {profitLoss >= 0 ? '+' : ''}{profitLoss.toFixed(2)}
                </div>
                <div className="flex items-center justify-center gap-1.5 mt-2">
                  <DollarSign size={11} style={{ color: `rgba(${accentRgb},0.45)` }} />
                  <span className="text-sm font-bold font-mono"
                    style={{ color: `rgba(${accentRgb},0.55)` }}>
                    {roi}% {won ? 'return' : 'loss'} on ${stake.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            {/* ── Balance update ── */}
            {newBalance !== null && balVisible && (
              <div className="rounded-2xl px-4 py-3.5 anim-fade-up"
                style={{
                  background: won ? 'rgba(0,255,136,0.05)' : 'rgba(255,51,85,0.04)',
                  border: won ? '1px solid rgba(0,255,136,0.15)' : '1px solid rgba(255,51,85,0.12)',
                }}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-2xs t-muted mb-0.5">New Balance</p>
                    <p className="text-2xl font-black font-mono"
                      style={{ color: won ? '#00ff88' : '#ff3355', textShadow: won ? '0 0 16px rgba(0,255,136,0.6)' : '0 0 16px rgba(255,51,85,0.6)' }}>
                      {newBalance.toFixed(2)}
                      <span className="text-sm ml-1.5 t-muted">{currency}</span>
                    </p>
                  </div>
                  {balDiff !== null && (
                    <div className="flex items-center gap-1 px-3 py-1.5 rounded-xl"
                      style={{
                        background: balDiff >= 0 ? 'rgba(0,255,136,0.08)' : 'rgba(255,51,85,0.08)',
                        border: balDiff >= 0 ? '1px solid rgba(0,255,136,0.18)' : '1px solid rgba(255,51,85,0.18)',
                      }}>
                      {balDiff >= 0
                        ? <TrendingUp size={11} style={{ color: '#00ff88' }} />
                        : <TrendingDown size={11} style={{ color: '#ff3355' }} />}
                      <span className="text-sm font-black font-mono"
                        style={{ color: balDiff >= 0 ? '#00ff88' : '#ff3355' }}>
                        {balDiff >= 0 ? '+' : ''}{balDiff.toFixed(2)}
                      </span>
                    </div>
                  )}
                </div>
                {prevBalance !== null && (
                  <div className="flex items-center gap-1.5 mt-2">
                    <span className="text-2xs t-muted">{prevBalance.toFixed(2)}</span>
                    <ArrowRight size={9} style={{ color: 'rgba(0,255,136,0.3)' }} />
                    <span className="text-2xs font-black"
                      style={{ color: won ? '#00ff88' : '#ff3355' }}>
                      {newBalance.toFixed(2)} {currency}
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* ── Trade summary ── */}
            <div className="rounded-2xl overflow-hidden"
              style={{ border: `1px solid rgba(${accentRgb},0.09)`, background: `rgba(${accentRgb},0.03)` }}>
              {[
                { label: 'Symbol',   val: symbol },
                { label: 'Contract', val: CONTRACT_META[contractType] ?? contractType },
                { label: 'Stake',    val: `$${stake.toFixed(2)}` },
                { label: 'Payout',   val: `$${payout.toFixed(2)}` },
                { label: 'Entry',    val: entryPrice?.toFixed(3) ?? '—' },
                { label: 'Exit',     val: exitPrice?.toFixed(3) ?? '—' },
              ].map((row, i, arr) => (
                <div key={row.label}
                  className="flex items-center justify-between px-4 py-2.5"
                  style={{ borderBottom: i < arr.length - 1 ? `1px solid rgba(${accentRgb},0.05)` : 'none' }}>
                  <span className="text-xs font-semibold t-muted">{row.label}</span>
                  <span className="text-xs font-black font-mono t-sub">{row.val}</span>
                </div>
              ))}
            </div>

            {/* ── Martingale next trade ── */}
            {martingaleNext !== null && !won && (
              <div className="flex items-center gap-3 px-4 py-3 rounded-2xl anim-fade-up"
                style={{
                  background: 'rgba(0,212,255,0.05)',
                  border: '1px solid rgba(0,212,255,0.18)',
                  boxShadow: '0 0 16px rgba(0,212,255,0.06)',
                }}>
                <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ background: 'rgba(0,212,255,0.1)', border: '1px solid rgba(0,212,255,0.2)' }}>
                  <Zap size={14} style={{ color: '#00d4ff', filter: 'drop-shadow(0 0 4px #00d4ff)' }} />
                </div>
                <div className="flex-1">
                  <p className="text-2xs font-black" style={{ color: '#00d4ff', textShadow: '0 0 8px rgba(0,212,255,0.5)' }}>
                    MARTINGALE ACTIVE
                  </p>
                  <p className="text-2xs t-muted mt-0.5">Next trade stake doubled automatically</p>
                </div>
                <span className="text-lg font-black font-mono"
                  style={{ color: '#00d4ff', textShadow: '0 0 12px rgba(0,212,255,0.6)' }}>
                  ${martingaleNext.toFixed(2)}
                </span>
              </div>
            )}

            {/* ── AI summary ── */}
            {analysis && (
              <div className="rounded-2xl px-4 py-3"
                style={{ background: 'rgba(0,255,136,0.025)', border: '1px solid rgba(0,255,136,0.07)' }}>
                <p className="section-label mb-2">AI Signal</p>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-black"
                    style={{
                      color: analysis.signal === 'CALL' ? '#00ff88' : analysis.signal === 'PUT' ? '#ff3355' : '#ffaa00',
                      textShadow: analysis.signal === 'CALL' ? '0 0 8px rgba(0,255,136,0.6)' : analysis.signal === 'PUT' ? '0 0 8px rgba(255,51,85,0.6)' : 'none',
                    }}>
                    {analysis.signal === 'CALL' ? '▲ RISE' : analysis.signal === 'PUT' ? '▼ FALL' : '◆ NEUTRAL'}
                  </span>
                  <div className="h-1.5 flex-1 rounded-full overflow-hidden" style={{ background: 'rgba(0,255,136,0.07)' }}>
                    <div className="h-full rounded-full"
                      style={{
                        width: `${analysis.confidence}%`,
                        background: analysis.confidence >= 61 ? '#00ff88' : '#ffaa00',
                      }} />
                  </div>
                  <span className="text-sm font-black font-mono t-green">{analysis.confidence}%</span>
                </div>
              </div>
            )}

            {/* ── Actions ── */}
            <div className="grid grid-cols-2 gap-3">
              <button onClick={onRetrade}
                className="group relative flex items-center justify-center gap-2 py-3.5 rounded-xl font-black text-sm uppercase tracking-wider overflow-hidden transition-all active:scale-95"
                style={{
                  background: 'linear-gradient(135deg, rgba(0,255,136,0.14), rgba(0,200,100,0.06))',
                  border: '1px solid rgba(0,255,136,0.28)',
                  color: '#00ff88',
                  textShadow: '0 0 10px rgba(0,255,136,0.6)',
                  boxShadow: '0 0 20px rgba(0,255,136,0.1)',
                }}>
                <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 pointer-events-none"
                  style={{ background: 'linear-gradient(90deg, transparent, rgba(0,255,136,0.07), transparent)', width: '40%' }} />
                <RotateCcw size={14} style={{ filter: 'drop-shadow(0 0 3px #00ff88)' }} />
                {martingaleNext !== null ? `Trade $${martingaleNext.toFixed(0)}` : 'Trade Again'}
              </button>
              <button onClick={onClose}
                className="py-3.5 rounded-xl font-black text-sm uppercase tracking-wider transition-all active:scale-95 t-muted"
                style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.05)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.03)')}>
                Close
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
