import { useState } from 'react';
import { User, Wifi, WifiOff, KeyRound, ChevronRight, Zap, CircleDollarSign, Shield, ArrowLeftRight } from 'lucide-react';
import { DerivAccount, OAuthAccount } from '../../lib/derivApi';

type Props = {
  account: DerivAccount | null;
  balance: number | null;
  connected: boolean;
  totalPL: number;
  winRate: number;
  tradesCount: number;
  oauthAccounts: OAuthAccount[];
  onOpenAuth: () => void;
  onSwitchAccount: (loginid: string) => void;
};

export default function AccountPanel({
  account, balance, connected, totalPL, winRate, tradesCount,
  oauthAccounts, onOpenAuth, onSwitchAccount,
}: Props) {
  const [hovered, setHovered] = useState(false);
  const plPos = totalPL >= 0;
  const isVirtual = account?.is_virtual ?? true;

  // Separate real and demo accounts from oauth list
  const realAccounts  = oauthAccounts.filter(a => !a.is_virtual);
  const demoAccounts  = oauthAccounts.filter(a => a.is_virtual);
  const hasMultiple   = oauthAccounts.length > 1;

  return (
    <div className="flex flex-col gap-3">

      {/* ── Account Card ── */}
      <button
        onClick={onOpenAuth}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        className="w-full group relative rounded-2xl p-4 text-left overflow-hidden transition-all duration-300"
        style={{
          background: account
            ? isVirtual
              ? 'linear-gradient(135deg, rgba(255,170,0,0.07) 0%, rgba(0,8,4,0.8) 100%)'
              : 'linear-gradient(135deg, rgba(0,255,136,0.09) 0%, rgba(0,8,4,0.8) 100%)'
            : 'rgba(0,8,4,0.7)',
          border: account
            ? isVirtual ? '1px solid rgba(255,170,0,0.2)' : '1px solid rgba(0,255,136,0.2)'
            : '1px solid rgba(0,255,136,0.1)',
          boxShadow: account
            ? isVirtual
              ? hovered ? '0 0 30px rgba(255,170,0,0.12)' : '0 0 12px rgba(255,170,0,0.06)'
              : hovered ? '0 0 30px rgba(0,255,136,0.14)' : '0 0 12px rgba(0,255,136,0.06)'
            : hovered ? '0 0 20px rgba(0,255,136,0.08)' : 'none',
          backdropFilter: 'blur(32px)',
        }}
      >
        {/* Shimmer on hover */}
        <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 pointer-events-none"
          style={{ background: 'linear-gradient(90deg, transparent, rgba(0,255,136,0.05), transparent)', width: '40%' }} />

        {/* Top line gradient */}
        <div className="absolute top-0 left-0 right-0 h-px"
          style={{
            background: account
              ? isVirtual
                ? 'linear-gradient(90deg, transparent, rgba(255,170,0,0.5), transparent)'
                : 'linear-gradient(90deg, transparent, rgba(0,255,136,0.5), transparent)'
              : 'linear-gradient(90deg, transparent, rgba(0,255,136,0.2), transparent)',
          }} />

        <div className="flex items-start justify-between gap-3">
          {/* Icon + info */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
              style={{
                background: account
                  ? isVirtual ? 'rgba(255,170,0,0.1)' : 'rgba(0,255,136,0.1)'
                  : 'rgba(0,255,136,0.06)',
                border: account
                  ? isVirtual ? '1px solid rgba(255,170,0,0.2)' : '1px solid rgba(0,255,136,0.2)'
                  : '1px solid rgba(0,255,136,0.1)',
                boxShadow: account
                  ? isVirtual ? '0 0 12px rgba(255,170,0,0.15)' : '0 0 12px rgba(0,255,136,0.15)'
                  : 'none',
              }}>
              {account
                ? <User size={16} style={{ color: isVirtual ? '#ffaa00' : '#00ff88', filter: `drop-shadow(0 0 4px ${isVirtual ? '#ffaa0088' : '#00ff8888'})` }} />
                : <KeyRound size={16} style={{ color: '#00ff88', filter: 'drop-shadow(0 0 4px #00ff8888)' }} />}
            </div>

            <div>
              {account ? (
                <>
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-black"
                      style={{ color: isVirtual ? '#ffaa00' : '#00ff88', textShadow: isVirtual ? '0 0 8px rgba(255,170,0,0.5)' : '0 0 8px rgba(0,255,136,0.5)' }}>
                      {account.loginid}
                    </span>
                    <span className="text-2xs font-black px-1.5 py-0.5 rounded-md"
                      style={{
                        background: isVirtual ? 'rgba(255,170,0,0.12)' : 'rgba(0,255,136,0.1)',
                        color: isVirtual ? '#ffaa00' : '#00ff88',
                        border: isVirtual ? '1px solid rgba(255,170,0,0.2)' : '1px solid rgba(0,255,136,0.15)',
                      }}>
                      {isVirtual ? 'DEMO' : 'REAL'}
                    </span>
                  </div>
                  <p className="text-2xs mt-0.5 t-muted">
                    {account.currency} Account · {isVirtual ? 'Virtual funds' : 'Live trading'}
                  </p>
                </>
              ) : (
                <>
                  <p className="text-sm font-black t-green">Connect Account</p>
                  <p className="text-2xs mt-0.5 t-muted">Link your Deriv account to trade live</p>
                </>
              )}
            </div>
          </div>

          <ChevronRight size={14} style={{ color: 'rgba(0,255,136,0.3)', flexShrink: 0, marginTop: 2 }} />
        </div>

        {/* Balance */}
        {account && balance !== null && (
          <div className="mt-3 pt-3 flex items-center justify-between"
            style={{ borderTop: `1px solid ${isVirtual ? 'rgba(255,170,0,0.08)' : 'rgba(0,255,136,0.08)'}` }}>
            <div>
              <p className="text-2xs t-muted mb-0.5">Balance</p>
              <p className="text-2xl font-black font-mono"
                style={{
                  color: isVirtual ? '#ffaa00' : '#00ff88',
                  textShadow: isVirtual ? '0 0 16px rgba(255,170,0,0.5)' : '0 0 16px rgba(0,255,136,0.5)',
                }}>
                {balance.toFixed(2)}
                <span className="text-sm ml-1.5" style={{ color: 'rgba(0,255,136,0.4)', fontWeight: 700 }}>{account.currency}</span>
              </p>
            </div>
            <div className="flex items-center gap-1.5">
              <div className={`w-2 h-2 rounded-full ${connected ? 'bg-green-400' : 'bg-red-500'}`}
                style={{ boxShadow: connected ? '0 0 6px #00ff88' : '0 0 6px #ff3355' }} />
              <span className="text-2xs font-black" style={{ color: connected ? '#00ff88' : '#ff3355' }}>
                {connected ? 'LIVE' : 'OFFLINE'}
              </span>
            </div>
          </div>
        )}
      </button>

      {/* ── Real / Demo balance pills (when both exist) ── */}
      {hasMultiple && (realAccounts.length > 0 || demoAccounts.length > 0) && (
        <div className="grid grid-cols-2 gap-2">
          {realAccounts.length > 0 && (
            <button
              onClick={() => onSwitchAccount(realAccounts[0].loginid)}
              className="flex flex-col items-center gap-1 py-2.5 px-3 rounded-xl transition-all"
              style={{
                background: !isVirtual ? 'rgba(0,255,136,0.08)' : 'rgba(0,255,136,0.03)',
                border: !isVirtual ? '1px solid rgba(0,255,136,0.22)' : '1px solid rgba(0,255,136,0.08)',
                boxShadow: !isVirtual ? '0 0 16px rgba(0,255,136,0.08)' : 'none',
              }}>
              <span className="text-2xs font-black uppercase tracking-wider" style={{ color: 'rgba(0,255,136,0.5)' }}>Real</span>
              <span className="text-xs font-black font-mono"
                style={{ color: '#00ff88', textShadow: '0 0 8px rgba(0,255,136,0.5)' }}>
                {realAccounts[0].loginid}
              </span>
              {!isVirtual && account && (
                <span className="text-xs font-black font-mono" style={{ color: '#00ff88' }}>
                  {balance?.toFixed(2)} {account.currency}
                </span>
              )}
              {!isVirtual && (
                <div className="w-1 h-1 rounded-full mt-0.5"
                  style={{ background: '#00ff88', boxShadow: '0 0 4px #00ff88' }} />
              )}
            </button>
          )}
          {demoAccounts.length > 0 && (
            <button
              onClick={() => onSwitchAccount(demoAccounts[0].loginid)}
              className="flex flex-col items-center gap-1 py-2.5 px-3 rounded-xl transition-all"
              style={{
                background: isVirtual ? 'rgba(255,170,0,0.07)' : 'rgba(255,170,0,0.03)',
                border: isVirtual ? '1px solid rgba(255,170,0,0.2)' : '1px solid rgba(255,170,0,0.07)',
                boxShadow: isVirtual ? '0 0 16px rgba(255,170,0,0.06)' : 'none',
              }}>
              <span className="text-2xs font-black uppercase tracking-wider" style={{ color: 'rgba(255,170,0,0.5)' }}>Demo</span>
              <span className="text-xs font-black font-mono"
                style={{ color: '#ffaa00', textShadow: '0 0 8px rgba(255,170,0,0.5)' }}>
                {demoAccounts[0].loginid}
              </span>
              {isVirtual && account && (
                <span className="text-xs font-black font-mono" style={{ color: '#ffaa00' }}>
                  {balance?.toFixed(2)} {account.currency}
                </span>
              )}
              {isVirtual && (
                <div className="w-1 h-1 rounded-full mt-0.5"
                  style={{ background: '#ffaa00', boxShadow: '0 0 4px #ffaa00' }} />
              )}
            </button>
          )}
        </div>
      )}

      {/* Switch account hint if multiple */}
      {hasMultiple && (
        <div className="flex items-center justify-center gap-1.5 py-1.5 rounded-xl text-2xs font-black cursor-pointer transition-colors t-muted hover:t-sub"
          onClick={onOpenAuth}
          style={{ border: '1px solid rgba(0,255,136,0.06)' }}>
          <ArrowLeftRight size={10} />
          Switch account
        </div>
      )}

      {/* ── Stats row ── */}
      <div className="grid grid-cols-3 gap-2">
        {[
          {
            icon: <CircleDollarSign size={12} />,
            label: 'P & L',
            value: `${plPos ? '+' : '-'}$${Math.abs(totalPL).toFixed(2)}`,
            color: plPos ? '#00ff88' : '#ff3355',
            glow: plPos ? 'rgba(0,255,136,0.08)' : 'rgba(255,51,85,0.08)',
            border: plPos ? 'rgba(0,255,136,0.15)' : 'rgba(255,51,85,0.15)',
          },
          {
            icon: <Zap size={12} />,
            label: 'Win Rate',
            value: `${isNaN(winRate) ? 0 : winRate.toFixed(0)}%`,
            color: '#00d4ff',
            glow: 'rgba(0,212,255,0.06)',
            border: 'rgba(0,212,255,0.12)',
          },
          {
            icon: <Shield size={12} />,
            label: 'Trades',
            value: String(tradesCount),
            color: 'rgba(0,255,136,0.6)',
            glow: 'rgba(0,255,136,0.04)',
            border: 'rgba(0,255,136,0.1)',
          },
        ].map(s => (
          <div key={s.label} className="rounded-xl px-3 py-2.5 flex flex-col items-center gap-1"
            style={{ background: s.glow, border: `1px solid ${s.border}`, backdropFilter: 'blur(20px)' }}>
            <span style={{ color: s.color }}>{s.icon}</span>
            <p className="text-2xs t-muted">{s.label}</p>
            <p className="text-sm font-black font-mono leading-none"
              style={{ color: s.color, textShadow: `0 0 8px ${s.color}60` }}>
              {s.value}
            </p>
          </div>
        ))}
      </div>

      {/* ── Connection status strip ── */}
      <div className="flex items-center gap-2 px-3 py-2 rounded-xl"
        style={{
          background: connected ? 'rgba(0,255,136,0.03)' : 'rgba(255,51,85,0.03)',
          border: connected ? '1px solid rgba(0,255,136,0.08)' : '1px solid rgba(255,51,85,0.1)',
        }}>
        {connected
          ? <Wifi size={11} style={{ color: '#00ff88', filter: 'drop-shadow(0 0 3px #00ff88)' }} />
          : <WifiOff size={11} style={{ color: '#ff3355' }} />}
        <div className="relative flex items-center">
          <div className="w-1.5 h-1.5 rounded-full"
            style={{ background: connected ? '#00ff88' : '#ff3355', boxShadow: connected ? '0 0 6px #00ff88' : '0 0 6px #ff3355' }} />
          {connected && (
            <div className="absolute w-1.5 h-1.5 rounded-full anim-ping"
              style={{ background: '#00ff88', opacity: 0.5 }} />
          )}
        </div>
        <span className="text-2xs font-black ml-0.5"
          style={{ color: connected ? '#00ff88' : '#ff3355' }}>
          {connected ? 'Connected to Deriv' : 'Disconnected'}
        </span>
      </div>
    </div>
  );
}
