import { useState, useEffect, useCallback } from 'react';
import { derivAPI, VOLATILITY_INDICES } from '../lib/derivApi';
import { TrendingUp, TrendingDown, Star, Activity } from 'lucide-react';

type Entry = {
  symbol: string;
  displayName: string;
  category: string;
  price: number | null;
  prevPrice: number | null;
  changePct: number;
  sparkline: number[];
};

type Props = {
  selectedSymbol: string;
  onSelectSymbol: (s: string) => void;
};

const CATS = ['All', 'Volatility', 'Volatility 1s', 'Crash/Boom', 'Favorites'];

export default function VolatilityScanner({ selectedSymbol, onSelectSymbol }: Props) {
  const [entries, setEntries] = useState<Map<string, Entry>>(new Map(
    VOLATILITY_INDICES.map(v => [v.symbol, {
      symbol: v.symbol, displayName: v.displayName, category: v.category,
      price: null, prevPrice: null, changePct: 0, sparkline: [],
    }])
  ));
  const [category, setCategory] = useState('All');
  const [favorites, setFavorites] = useState<Set<string>>(new Set(['R_100', 'BOOM500', 'CRASH500']));

  const startFeeds = useCallback(async () => {
    derivAPI.subscribe('tick', (data) => {
      const tick = (data as { tick?: { quote: number; symbol: string } }).tick;
      if (!tick) return;
      setEntries(prev => {
        const next = new Map(prev);
        const e = next.get(tick.symbol);
        if (!e) return prev;
        const pct = e.price ? ((tick.quote - e.price) / e.price) * 100 : 0;
        next.set(tick.symbol, {
          ...e,
          prevPrice: e.price,
          price: tick.quote,
          changePct: pct,
          sparkline: [...e.sparkline, tick.quote].slice(-24),
        });
        return next;
      });
    });
    for (const sym of VOLATILITY_INDICES.slice(0, 8).map(v => v.symbol)) {
      try { await derivAPI.getTicks(sym); await new Promise(r => setTimeout(r, 80)); } catch {}
    }
  }, []);

  useEffect(() => { startFeeds(); }, [startFeeds]);

  const filtered = Array.from(entries.values()).filter(e => {
    if (category === 'Favorites') return favorites.has(e.symbol);
    if (category === 'All') return true;
    return e.category === category;
  });

  return (
    <div className="flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Activity size={12} style={{ color: '#475569' }} />
        <span className="text-xs font-bold uppercase tracking-widest" style={{ color: '#64748b' }}>Markets</span>
        <div className="ml-auto flex items-center gap-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-2xs font-semibold" style={{ color: '#10b981' }}>LIVE</span>
        </div>
      </div>

      {/* Category tabs */}
      <div className="flex gap-1 overflow-x-auto scrollbar-hide">
        {CATS.map(c => (
          <button key={c} onClick={() => setCategory(c)}
            className="px-2.5 py-1 rounded text-2xs font-semibold whitespace-nowrap transition-all shrink-0"
            style={{
              background: category === c ? 'rgba(6,182,212,0.12)' : 'rgba(255,255,255,0.03)',
              color: category === c ? '#06b6d4' : '#475569',
              border: category === c ? '1px solid rgba(6,182,212,0.2)' : '1px solid transparent',
            }}>
            {c}
          </button>
        ))}
      </div>

      {/* List */}
      <div className="space-y-0.5">
        {filtered.map(e => {
          const isSelected = e.symbol === selectedSymbol;
          const isUp = e.changePct >= 0;
          const isFav = favorites.has(e.symbol);

          return (
            <div key={e.symbol} onClick={() => onSelectSymbol(e.symbol)}
              className="group flex items-center gap-2.5 px-2.5 py-2 rounded-lg cursor-pointer transition-all"
              style={{
                background: isSelected ? 'rgba(6,182,212,0.07)' : 'transparent',
                border: isSelected ? '1px solid rgba(6,182,212,0.15)' : '1px solid transparent',
              }}>

              <button onClick={ev => {
                ev.stopPropagation();
                setFavorites(prev => {
                  const n = new Set(prev);
                  if (n.has(e.symbol)) n.delete(e.symbol); else n.add(e.symbol);
                  return n;
                });
              }} className="shrink-0 transition-colors"
                style={{ color: isFav ? '#f59e0b' : '#1e293b' }}>
                <Star size={10} fill={isFav ? 'currentColor' : 'none'} />
              </button>

              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold leading-none truncate" style={{ color: '#cbd5e1' }}>
                  {e.displayName.replace(' Index', '').replace('Volatility ', 'Vol ').replace(' (1s)', '')}
                </p>
                <p className="text-2xs mt-0.5" style={{ color: '#334155' }}>{e.symbol}</p>
              </div>

              {e.sparkline.length > 3 && <MiniSpark data={e.sparkline} isUp={isUp} />}

              <div className="text-right shrink-0">
                <p className="text-xs font-mono font-bold leading-none" style={{ color: '#e2e8f0' }}>
                  {e.price !== null ? e.price.toFixed(2) : '—'}
                </p>
                <div className={`flex items-center justify-end gap-0.5 text-2xs font-semibold mt-0.5`}
                  style={{ color: isUp ? '#10b981' : '#ef4444' }}>
                  {isUp ? <TrendingUp size={9} /> : <TrendingDown size={9} />}
                  <span>{e.changePct !== 0 ? `${isUp ? '+' : ''}${e.changePct.toFixed(3)}%` : '—'}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function MiniSpark({ data, isUp }: { data: number[]; isUp: boolean }) {
  const min = Math.min(...data), max = Math.max(...data), range = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * 36},${16 - ((v - min) / range) * 14 + 1}`).join(' ');
  return (
    <svg width="36" height="18" className="shrink-0">
      <polyline points={pts} fill="none" stroke={isUp ? '#10b981' : '#ef4444'} strokeWidth="1.2" strokeLinejoin="round" />
    </svg>
  );
}
