import { useEffect, useState, useRef } from 'react';
import { Trade } from '../lib/supabase';
import { TrendingUp, TrendingDown, Activity, Clock, Zap } from 'lucide-react';

type Props = {
  trade: Trade;
  currentPrice: number | null;
  aiConfidence: number;
  exitPrice?: number | null;
};

function contractLabel(ct: string): string {
  const map: Record<string, string> = {
    CALL: 'RISE', PUT: 'FALL',
    EVEN: 'EVEN', ODD: 'ODD',
    DIGITMATCH: 'MATCHES', DIGITDIFF: 'DIFFERS',
    DIGITOVER: 'OVER', DIGITUNDER: 'UNDER',
  };
  return map[ct] ?? ct;
}

export default function LiveTradePanel({ trade, currentPrice, aiConfidence, exitPrice }: Props) {
  const [elapsed, setElapsed]   = useState(0);
  const [livePL, setLivePL]     = useState(0);
  const [priceFlash, setPriceFlash] = useState<'up' | 'down' | null>(null);
  const prevPriceRef = useRef<number | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const duration = trade.duration || 180;
  const remaining = Math.max(0, duration - elapsed);
  const progress = Math.min(1, elapsed / duration);
  const isCall = ['CALL', 'EVEN', 'DIGITOVER', 'DIGITMATCH'].includes(trade.contract_type);
  const entry = trade.entry_price || 0;
  const isDigit = !['CALL', 'PUT'].includes(trade.contract_type);

  // Timer
  useEffect(() => {
    setElapsed(0);
    timerRef.current = setInterval(() => {
      setElapsed(p => {
        if (p >= duration) { if (timerRef.current) clearInterval(timerRef.current); return p; }
        return p + 1;
      });
    }, 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [trade.id, duration]);

  // Live P&L + price flash
  useEffect(() => {
    if (!currentPrice || !entry) return;
    const prev = prevPriceRef.current;
    if (prev !== null && prev !== currentPrice) {
      setPriceFlash(currentPrice > prev ? 'up' : 'down');
      setTimeout(() => setPriceFlash(null), 500);
    }
    prevPriceRef.current = currentPrice;

    if (!isDigit) {
      const diff = currentPrice - entry;
      const raw = isCall
        ? (diff > 0 ? trade.stake * 0.85 : -(trade.stake * (Math.abs(diff) / entry) * 8))
        : (diff < 0 ? trade.stake * 0.85 : -(trade.stake * (Math.abs(diff) / entry) * 8));
      setLivePL(Math.max(-trade.stake, Math.min(trade.stake * 0.95, raw)));
    }
  }, [currentPrice, entry, isCall, isDigit, trade.stake]);

  const fmt = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  const plPos = livePL >= 0;
  const plColor = plPos ? '#10b981' : '#ef4444';
  const signalColor = isCall ? '#10b981' : '#ef4444';
  const displayPrice = exitPrice ?? currentPrice;

  return (
    <div className="relative rounded-2xl overflow-hidden"
      style={{
        background: 'rgba(8,12,24,0.95)',
        border: `1px solid ${plPos ? 'rgba(16,185,129,0.25)' : 'rgba(239,68,68,0.2)'}`,
        backdropFilter: 'blur(24px)',
        boxShadow: `0 0 40px ${plPos ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.08)'}, 0 8px 32px rgba(0,0,0,0.4)`,
      }}>

      {/* Progress bar */}
      <div className="h-1 w-full relative" style={{ background: 'rgba(255,255,255,0.05)' }}>
        <div className="h-full transition-all duration-1000 ease-linear rounded-full"
          style={{
            width: `${progress * 100}%`,
            background: `linear-gradient(90deg, ${signalColor}80, ${signalColor})`,
            boxShadow: `0 0 10px ${signalColor}70`,
          }} />
      </div>

      <div className="p-4">
        {/* Top row: symbol + direction + live badge */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl"
              style={{ background: isCall ? 'rgba(16,185,129,0.12)' : 'rgba(239,68,68,0.12)', border: `1px solid ${signalColor}25` }}>
              {isCall
                ? <TrendingUp size={15} style={{ color: '#10b981' }} />
                : <TrendingDown size={15} style={{ color: '#ef4444' }} />}
            </div>
            <div>
              <p className="text-sm font-bold leading-none" style={{ color: '#f1f5f9' }}>{trade.symbol}</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-2xs font-bold uppercase" style={{ color: signalColor }}>
                  {contractLabel(trade.contract_type)}
                </span>
                {trade.prediction !== null && trade.prediction !== undefined && (
                  <span className="text-2xs px-1.5 py-0.5 rounded font-bold"
                    style={{ background: 'rgba(6,182,212,0.12)', color: '#06b6d4' }}>
                    #{trade.prediction}
                  </span>
                )}
                {trade.barrier !== null && trade.barrier !== undefined && (
                  <span className="text-2xs px-1.5 py-0.5 rounded font-bold"
                    style={{ background: 'rgba(245,158,11,0.12)', color: '#f59e0b' }}>
                    B:{trade.barrier}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg"
            style={{ background: 'rgba(6,182,212,0.08)', border: '1px solid rgba(6,182,212,0.18)' }}>
            <Activity size={10} className="animate-pulse" style={{ color: '#06b6d4' }} />
            <span className="text-2xs font-bold uppercase tracking-wider" style={{ color: '#06b6d4' }}>Live</span>
          </div>
        </div>

        {/* Entry / Current / Exit spots */}
        <div className="grid grid-cols-3 gap-1.5 mb-3">
          <div className="px-2.5 py-2.5 rounded-xl"
            style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.05)' }}>
            <p className="text-2xs mb-1 font-semibold" style={{ color: '#475569' }}>Entry Spot</p>
            <p className="text-sm font-mono font-bold" style={{ color: '#94a3b8' }}>
              {entry > 0 ? entry.toFixed(4) : '—'}
            </p>
          </div>

          <div className="px-2.5 py-2.5 rounded-xl transition-all duration-300"
            style={{
              background: priceFlash === 'up'
                ? 'rgba(16,185,129,0.15)'
                : priceFlash === 'down'
                ? 'rgba(239,68,68,0.15)'
                : 'rgba(6,182,212,0.06)',
              border: `1px solid ${priceFlash === 'up' ? 'rgba(16,185,129,0.3)' : priceFlash === 'down' ? 'rgba(239,68,68,0.3)' : 'rgba(6,182,212,0.15)'}`,
            }}>
            <p className="text-2xs mb-1 font-semibold" style={{ color: '#475569' }}>Live Price</p>
            <p className="text-sm font-mono font-bold transition-colors duration-200"
              style={{ color: priceFlash === 'up' ? '#10b981' : priceFlash === 'down' ? '#ef4444' : '#06b6d4' }}>
              {displayPrice !== null ? displayPrice.toFixed(4) : '—'}
            </p>
          </div>

          <div className="px-2.5 py-2.5 rounded-xl"
            style={{
              background: exitPrice ? (plPos ? 'rgba(16,185,129,0.08)' : 'rgba(239,68,68,0.08)') : 'rgba(255,255,255,0.025)',
              border: `1px solid ${exitPrice ? (plPos ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.2)') : 'rgba(255,255,255,0.05)'}`,
            }}>
            <p className="text-2xs mb-1 font-semibold" style={{ color: '#475569' }}>Exit Spot</p>
            <p className="text-sm font-mono font-bold"
              style={{ color: exitPrice ? (plPos ? '#10b981' : '#ef4444') : '#334155' }}>
              {exitPrice ? exitPrice.toFixed(4) : '—'}
            </p>
          </div>
        </div>

        {/* P&L + Timer */}
        <div className="flex items-center justify-between px-3 py-3 rounded-xl mb-3"
          style={{
            background: plPos ? 'rgba(16,185,129,0.05)' : 'rgba(239,68,68,0.05)',
            border: plPos ? '1px solid rgba(16,185,129,0.12)' : '1px solid rgba(239,68,68,0.12)',
          }}>
          <div>
            <p className="text-2xs font-semibold mb-1" style={{ color: '#475569' }}>
              {isDigit ? 'Est. P&L' : 'Live P&L'}
            </p>
            <p className="text-3xl font-mono font-black transition-all duration-300"
              style={{ color: plColor, textShadow: `0 0 24px ${plColor}50` }}>
              {isDigit ? '—' : `${plPos ? '+' : ''}$${Math.abs(livePL).toFixed(2)}`}
            </p>
          </div>

          <div className="text-right">
            <div className="flex items-center justify-end gap-1 mb-1">
              <Clock size={10} style={{ color: '#475569' }} />
              <p className="text-2xs font-semibold" style={{ color: '#475569' }}>Remaining</p>
            </div>
            <p className={`text-3xl font-mono font-black ${remaining < 15 ? 'animate-pulse' : ''}`}
              style={{ color: remaining < 15 ? '#ef4444' : '#e2e8f0' }}>
              {fmt(remaining)}
            </p>
          </div>
        </div>

        {/* Stats footer */}
        <div className="grid grid-cols-4 gap-1.5">
          {[
            { label: 'Stake',    val: `$${trade.stake.toFixed(0)}`,        color: '#94a3b8' },
            { label: 'Payout',   val: `$${(trade.payout || 0).toFixed(0)}`, color: '#10b981' },
            { label: 'Duration', val: fmt(duration),                         color: '#94a3b8' },
            { label: 'AI Conf.', val: `${aiConfidence}%`,                    color: '#06b6d4' },
          ].map(({ label, val, color }) => (
            <div key={label} className="px-2 py-2 rounded-lg text-center"
              style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.04)' }}>
              <p className="text-2xs mb-0.5 leading-none" style={{ color: '#334155' }}>{label}</p>
              <p className="text-xs font-mono font-bold" style={{ color }}>{val}</p>
            </div>
          ))}
        </div>

        {remaining < 10 && remaining > 0 && (
          <div className="mt-2.5 flex items-center justify-center gap-1.5 py-1.5 rounded-lg animate-pulse"
            style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)' }}>
            <Zap size={10} style={{ color: '#ef4444' }} />
            <span className="text-2xs font-bold" style={{ color: '#ef4444' }}>Expiring in {remaining}s</span>
          </div>
        )}
      </div>
    </div>
  );
}
