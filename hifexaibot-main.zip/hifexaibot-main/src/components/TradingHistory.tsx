import { Trade } from '../lib/supabase';
import { History, TrendingUp, TrendingDown, RefreshCw, Clock } from 'lucide-react';

type Props = {
  trades: Trade[];
  totalPL: number;
  winRate: number;
  loading: boolean;
  onRefresh: () => void;
};

export default function TradingHistory({ trades, totalPL, winRate, loading, onRefresh }: Props) {
  const closed = trades.filter(t => t.result !== 'open');
  const open = trades.filter(t => t.result === 'open');
  const wins = closed.filter(t => t.result === 'won').length;

  const fmt = (iso: string) => {
    const d = new Date(iso);
    const today = new Date().toDateString() === d.toDateString();
    return today
      ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      : d.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  const plPos = totalPL >= 0;

  return (
    <div className="flex flex-col gap-3 h-full">
      {/* Header */}
      <div className="flex items-center gap-2 shrink-0">
        <History size={12} style={{ color: '#475569' }} />
        <span className="text-xs font-bold uppercase tracking-widest" style={{ color: '#64748b' }}>History</span>
        <button onClick={onRefresh}
          className="ml-auto p-1.5 rounded transition-colors"
          style={{ color: '#334155' }}
          onMouseEnter={e => (e.currentTarget.style.color = '#64748b')}
          onMouseLeave={e => (e.currentTarget.style.color = '#334155')}>
          <RefreshCw size={11} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-1.5 shrink-0">
        <StatCard label="Total P&L" value={`${plPos ? '+' : ''}$${totalPL.toFixed(2)}`}
          color={plPos ? '#10b981' : '#ef4444'} />
        <StatCard label="Win Rate" value={`${isNaN(winRate) ? '0' : winRate.toFixed(0)}%`} color="#06b6d4" />
        <StatCard label="Closed" value={String(closed.length)} color="#94a3b8" />
      </div>

      {/* Win/loss bar */}
      {closed.length > 0 && (
        <div className="shrink-0">
          <div className="flex justify-between text-2xs mb-1">
            <span style={{ color: '#10b981' }}>{wins} won</span>
            <span style={{ color: '#ef4444' }}>{closed.length - wins} lost</span>
          </div>
          <div className="flex h-1 rounded-full overflow-hidden gap-px" style={{ background: 'rgba(255,255,255,0.04)' }}>
            <div className="h-full rounded-full transition-all duration-500"
              style={{ width: `${(wins / closed.length) * 100}%`, background: '#10b981' }} />
          </div>
        </div>
      )}

      {/* Trades list */}
      <div className="flex-1 overflow-y-auto min-h-0 space-y-0.5">
        {open.length > 0 && (
          <>
            <p className="text-2xs font-bold uppercase tracking-widest py-1.5 sticky top-0"
              style={{ color: '#f59e0b', background: 'rgba(5,8,16,0.9)' }}>
              Open ({open.length})
            </p>
            {open.map(t => <TradeRow key={t.id} trade={t} fmt={fmt} />)}
          </>
        )}

        {closed.length === 0 && open.length === 0 && (
          <div className="flex flex-col items-center justify-center py-10 text-center">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
              style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)' }}>
              <History size={16} style={{ color: '#334155' }} />
            </div>
            <p className="text-xs font-semibold" style={{ color: '#334155' }}>No trades yet</p>
            <p className="text-2xs mt-1" style={{ color: '#1e293b' }}>Execute your first trade to begin</p>
          </div>
        )}

        {closed.length > 0 && (
          <>
            <p className="text-2xs font-bold uppercase tracking-widest py-1.5 sticky top-0"
              style={{ color: '#475569', background: 'rgba(5,8,16,0.9)' }}>
              Closed ({closed.length})
            </p>
            {closed.map(t => <TradeRow key={t.id} trade={t} fmt={fmt} />)}
          </>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="px-2.5 py-2 rounded-lg text-center"
      style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.04)' }}>
      <p className="text-2xs mb-0.5 leading-none" style={{ color: '#334155' }}>{label}</p>
      <p className="text-xs font-bold font-mono leading-none" style={{ color }}>{value}</p>
    </div>
  );
}

const CT_LABEL: Record<string, string> = {
  CALL: 'RISE', PUT: 'FALL',
  EVEN: 'EVEN', ODD: 'ODD',
  DIGITMATCH: 'MATCHES', DIGITDIFF: 'DIFFERS',
  DIGITOVER: 'OVER', DIGITUNDER: 'UNDER',
};

function TradeRow({ trade, fmt }: { trade: Trade; fmt: (s: string) => string }) {
  const isWon = trade.result === 'won';
  const isOpen = trade.result === 'open';
  const isCall = trade.contract_type === 'CALL' || trade.contract_type === 'EVEN' || trade.contract_type === 'DIGITOVER' || trade.contract_type === 'DIGITMATCH';
  const plColor = isWon ? '#10b981' : isOpen ? '#f59e0b' : '#ef4444';
  const borderColor = isWon ? 'rgba(16,185,129,0.12)' : isOpen ? 'rgba(245,158,11,0.1)' : 'rgba(239,68,68,0.1)';

  return (
    <div className="flex items-center gap-2.5 px-2.5 py-2 rounded-lg"
      style={{ border: `1px solid ${borderColor}`, background: `${borderColor}` }}>
      <div className="p-1 rounded shrink-0"
        style={{ background: isCall ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)' }}>
        {isCall
          ? <TrendingUp size={10} style={{ color: '#10b981' }} />
          : <TrendingDown size={10} style={{ color: '#ef4444' }} />}
      </div>

      <div className="flex-1 min-w-0">
        <p className="text-xs font-semibold leading-none truncate" style={{ color: '#cbd5e1' }}>{trade.symbol}</p>
        <div className="flex items-center gap-1 mt-0.5">
          <span className="text-2xs font-bold" style={{ color: isCall ? '#10b981' : '#ef4444' }}>
            {CT_LABEL[trade.contract_type] ?? trade.contract_type}
          </span>
          <Clock size={8} style={{ color: '#334155' }} />
          <p className="text-2xs" style={{ color: '#334155' }}>{fmt(trade.created_at)}</p>
        </div>
      </div>

      <div className="text-right shrink-0">
        <p className="text-xs font-mono font-semibold leading-none" style={{ color: '#64748b' }}>
          ${trade.stake.toFixed(0)}
        </p>
        {isOpen ? (
          <p className="text-2xs font-bold mt-0.5" style={{ color: '#f59e0b' }}>OPEN</p>
        ) : (
          <p className="text-xs font-mono font-bold mt-0.5" style={{ color: plColor }}>
            {isWon ? '+' : '-'}${Math.abs(trade.profit_loss).toFixed(2)}
          </p>
        )}
      </div>
    </div>
  );
}
