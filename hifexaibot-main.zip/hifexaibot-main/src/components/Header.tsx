import { useState, useEffect } from 'react';
import { derivAPI, DerivAccount } from '../lib/derivApi';
import { Activity, Wifi, WifiOff, KeyRound, User } from 'lucide-react';

type Props = {
  totalPL: number;
  winRate: number;
  tradesCount: number;
  account: DerivAccount | null;
  balance: number | null;
  onOpenAuth: () => void;
};

export default function Header({ totalPL, account, balance, onOpenAuth }: Props) {
  const [connected, setConnected] = useState(false);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    derivAPI.connect().then(() => setConnected(true)).catch(() => {});
    const cc = setInterval(() => setConnected(derivAPI.isConnected()), 2000);
    const tc = setInterval(() => setTime(new Date()), 1000);
    return () => { clearInterval(cc); clearInterval(tc); };
  }, []);

  const plPos = totalPL >= 0;

  return (
    <header className="h-14 shrink-0 flex items-center px-4 gap-3 z-20 relative"
      style={{
        background: 'rgba(5,8,16,0.95)',
        borderBottom: '1px solid rgba(6,182,212,0.1)',
        backdropFilter: 'blur(20px)',
        boxShadow: '0 1px 0 rgba(6,182,212,0.06), 0 4px 24px rgba(0,0,0,0.4)',
      }}>

      {/* Brand */}
      <div className="flex items-center gap-2.5 shrink-0">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
          style={{
            background: 'linear-gradient(135deg, #0891b2, #06b6d4)',
            boxShadow: '0 0 16px rgba(6,182,212,0.4), 0 0 32px rgba(6,182,212,0.15)',
          }}>
          <Activity size={14} className="text-white" />
        </div>
        <div className="flex items-baseline gap-1.5">
          <span className="text-base font-black tracking-tight"
            style={{
              color: '#f1f5f9',
              textShadow: '0 0 20px rgba(241,245,249,0.3)',
            }}>DerivDen</span>
          <span className="text-2xs font-black uppercase tracking-widest"
            style={{
              color: '#06b6d4',
              textShadow: '0 0 10px rgba(6,182,212,0.8)',
            }}>AI</span>
        </div>
      </div>

      {/* P&L — desktop only */}
      <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl"
        style={{
          background: plPos ? 'rgba(16,185,129,0.07)' : 'rgba(239,68,68,0.07)',
          border: plPos ? '1px solid rgba(16,185,129,0.15)' : '1px solid rgba(239,68,68,0.15)',
        }}>
        <span className="text-2xs font-semibold" style={{ color: '#475569' }}>P&L</span>
        <span className="text-sm font-black font-mono"
          style={{
            color: plPos ? '#10b981' : '#ef4444',
            textShadow: plPos ? '0 0 10px rgba(16,185,129,0.6)' : '0 0 10px rgba(239,68,68,0.6)',
          }}>
          {plPos ? '+' : '-'}${Math.abs(totalPL).toFixed(2)}
        </span>
      </div>

      {/* Balance — when authenticated */}
      {account && balance !== null && (
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-xl"
          style={{
            background: account.is_virtual ? 'rgba(245,158,11,0.07)' : 'rgba(16,185,129,0.07)',
            border: account.is_virtual ? '1px solid rgba(245,158,11,0.15)' : '1px solid rgba(16,185,129,0.15)',
          }}>
          <span className="text-2xs font-semibold" style={{ color: '#475569' }}>
            {account.is_virtual ? 'Demo' : 'Live'}
          </span>
          <span className="text-sm font-black font-mono"
            style={{
              color: account.is_virtual ? '#f59e0b' : '#10b981',
              textShadow: account.is_virtual ? '0 0 8px rgba(245,158,11,0.5)' : '0 0 8px rgba(16,185,129,0.5)',
            }}>
            {balance.toFixed(2)} {account.currency}
          </span>
        </div>
      )}

      <div className="flex-1" />

      {/* UTC clock */}
      <div className="hidden lg:block font-mono text-xs font-semibold"
        style={{ color: '#334155' }}>
        {time.toUTCString().slice(17, 25)} UTC
      </div>

      {/* WS status */}
      <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-2xs font-bold"
        style={{
          background: connected ? 'rgba(16,185,129,0.06)' : 'rgba(239,68,68,0.06)',
          border: connected ? '1px solid rgba(16,185,129,0.14)' : '1px solid rgba(239,68,68,0.14)',
          color: connected ? '#10b981' : '#ef4444',
        }}>
        {connected
          ? <Wifi size={11} style={{ filter: 'drop-shadow(0 0 4px #10b981)' }} />
          : <WifiOff size={11} />}
        <div className={`w-1.5 h-1.5 rounded-full ${connected ? 'bg-emerald-400 animate-pulse' : 'bg-red-400'}`} />
      </div>

      {/* Auth button */}
      <button onClick={onOpenAuth}
        className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-black transition-all"
        style={{
          background: account ? 'rgba(16,185,129,0.08)' : 'rgba(6,182,212,0.08)',
          border: account ? '1px solid rgba(16,185,129,0.22)' : '1px solid rgba(6,182,212,0.22)',
          color: account ? '#10b981' : '#06b6d4',
          textShadow: account ? '0 0 8px rgba(16,185,129,0.5)' : '0 0 8px rgba(6,182,212,0.5)',
          boxShadow: account ? '0 0 12px rgba(16,185,129,0.08)' : '0 0 12px rgba(6,182,212,0.08)',
        }}
        onMouseEnter={e => (e.currentTarget.style.opacity = '0.8')}
        onMouseLeave={e => (e.currentTarget.style.opacity = '1')}>
        {account ? <User size={12} /> : <KeyRound size={12} />}
        <span className="max-w-[90px] truncate">
          {account ? account.loginid : 'Connect'}
        </span>
      </button>
    </header>
  );
}
