import { useEffect, useState } from 'react';
import { Brain, Cpu, Search, TrendingUp, Zap, Eye, AlertTriangle, CheckCircle2 } from 'lucide-react';

export type AIStatus =
  | 'idle'
  | 'scanning'
  | 'analyzing_momentum'
  | 'detecting_trend'
  | 'high_probability'
  | 'executing'
  | 'monitoring'
  | 'no_signal';

const STATUS_MAP: Record<AIStatus, {
  label: string;
  subtext: string;
  icon: React.ReactNode;
  color: string;
  bg: string;
  border: string;
  pulse: boolean;
}> = {
  idle: {
    label: 'AI Engine Standby',
    subtext: 'Ready to scan markets',
    icon: <Brain size={12} />,
    color: '#64748b',
    bg: 'rgba(100,116,139,0.06)',
    border: 'rgba(100,116,139,0.12)',
    pulse: false,
  },
  scanning: {
    label: 'Scanning Markets',
    subtext: 'Connecting to live volatility feed',
    icon: <Search size={12} />,
    color: '#06b6d4',
    bg: 'rgba(6,182,212,0.07)',
    border: 'rgba(6,182,212,0.18)',
    pulse: true,
  },
  analyzing_momentum: {
    label: 'Analyzing Momentum',
    subtext: 'Computing RSI, MACD, Bollinger Bands',
    icon: <Cpu size={12} />,
    color: '#3b82f6',
    bg: 'rgba(59,130,246,0.07)',
    border: 'rgba(59,130,246,0.18)',
    pulse: true,
  },
  detecting_trend: {
    label: 'Detecting Trend Strength',
    subtext: 'Evaluating market structure',
    icon: <TrendingUp size={12} />,
    color: '#06b6d4',
    bg: 'rgba(6,182,212,0.07)',
    border: 'rgba(6,182,212,0.18)',
    pulse: true,
  },
  high_probability: {
    label: 'High Probability Setup Detected',
    subtext: 'Strong signal — execute now',
    icon: <CheckCircle2 size={12} />,
    color: '#10b981',
    bg: 'rgba(16,185,129,0.08)',
    border: 'rgba(16,185,129,0.25)',
    pulse: true,
  },
  executing: {
    label: 'Executing Trade',
    subtext: 'Submitting order to market',
    icon: <Zap size={12} />,
    color: '#f59e0b',
    bg: 'rgba(245,158,11,0.07)',
    border: 'rgba(245,158,11,0.18)',
    pulse: true,
  },
  monitoring: {
    label: 'Monitoring Active Trade',
    subtext: 'Tracking live position',
    icon: <Eye size={12} />,
    color: '#06b6d4',
    bg: 'rgba(6,182,212,0.07)',
    border: 'rgba(6,182,212,0.18)',
    pulse: true,
  },
  no_signal: {
    label: 'No Strong Setup Found',
    subtext: 'All markets below 61% threshold',
    icon: <AlertTriangle size={12} />,
    color: '#f59e0b',
    bg: 'rgba(245,158,11,0.06)',
    border: 'rgba(245,158,11,0.14)',
    pulse: false,
  },
};

type Props = {
  status: AIStatus;
  autoTrade?: boolean;
  scanSymbol?: string;
};

export default function AIStatusBar({ status, autoTrade, scanSymbol }: Props) {
  const [dots, setDots] = useState('');
  const cfg = STATUS_MAP[status];

  useEffect(() => {
    if (!cfg.pulse) { setDots(''); return; }
    const t = setInterval(() => setDots(d => d.length >= 3 ? '' : d + '.'), 600);
    return () => clearInterval(t);
  }, [status, cfg.pulse]);

  return (
    <div className="flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-300"
      style={{ background: cfg.bg, border: `1px solid ${cfg.border}` }}>

      {/* Icon + pulse indicator */}
      <div className="relative shrink-0 flex items-center justify-center w-5 h-5">
        {cfg.pulse && (
          <div className="absolute inset-0 rounded-full animate-ping opacity-30"
            style={{ background: cfg.color }} />
        )}
        <div className="relative z-10" style={{ color: cfg.color }}>{cfg.icon}</div>
      </div>

      {/* Text */}
      <div className="flex-1 min-w-0 flex items-center gap-2">
        <span className="text-xs font-semibold leading-none whitespace-nowrap" style={{ color: cfg.color }}>
          {cfg.label}{cfg.pulse ? dots : ''}
        </span>
        {scanSymbol && status === 'scanning' && (
          <span className="text-2xs font-mono hidden sm:inline truncate" style={{ color: '#475569' }}>
            {scanSymbol}
          </span>
        )}
        {!scanSymbol && (
          <span className="text-2xs hidden md:inline truncate" style={{ color: '#334155' }}>{cfg.subtext}</span>
        )}
      </div>

      {/* Auto badge */}
      {autoTrade && (
        <div className="shrink-0 flex items-center gap-1 px-2 py-0.5 rounded text-2xs font-bold uppercase tracking-wider"
          style={{ background: 'rgba(16,185,129,0.12)', border: '1px solid rgba(16,185,129,0.2)', color: '#10b981' }}>
          <div className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
          Auto
        </div>
      )}
    </div>
  );
}
