import { useEffect, useRef, useState, useCallback } from 'react';
import { DerivTick } from '../lib/derivApi';
import { TrendingUp, TrendingDown } from 'lucide-react';

type TimeFrame = '1m' | '5m' | '15m' | 'all';

type Props = {
  ticks: DerivTick[];
  currentPrice: number | null;
  symbol: string;
  signal?: 'CALL' | 'PUT' | 'NEUTRAL';
};

export default function PriceChart({ ticks, currentPrice, symbol, signal }: Props) {
  const canvasRef    = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ w: 0, h: 0 });
  const [timeframe, setTimeframe]   = useState<TimeFrame>('all');
  const [hoverIdx, setHoverIdx]     = useState<number | null>(null);

  useEffect(() => {
    const obs = new ResizeObserver(([e]) => {
      setDimensions({ w: Math.floor(e.contentRect.width), h: Math.floor(e.contentRect.height) });
    });
    if (containerRef.current) obs.observe(containerRef.current);
    return () => obs.disconnect();
  }, []);

  const getFiltered = useCallback(() => {
    if (!ticks.length) return ticks;
    if (timeframe === 'all') return ticks.slice(-300);
    const now = ticks[ticks.length - 1]?.epoch || 0;
    const cutoff = { '1m': 60, '5m': 300, '15m': 900 }[timeframe] || 9999;
    const f = ticks.filter(t => t.epoch >= now - cutoff);
    return f.length > 3 ? f : ticks.slice(-30);
  }, [ticks, timeframe]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !dimensions.w || !dimensions.h) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    canvas.width  = dimensions.w * dpr;
    canvas.height = dimensions.h * dpr;
    canvas.style.width  = `${dimensions.w}px`;
    canvas.style.height = `${dimensions.h}px`;
    ctx.scale(dpr, dpr);

    const filtered = getFiltered();
    if (filtered.length < 2) return;

    const W = dimensions.w;
    const H = dimensions.h;
    const pad = { top: 20, bottom: 36, left: 70, right: 18 };
    const cw = W - pad.left - pad.right;
    const ch = H - pad.top - pad.bottom;

    const prices = filtered.map(t => t.quote);
    const rawMin = Math.min(...prices);
    const rawMax = Math.max(...prices);
    const rawRange = rawMax - rawMin || rawMax * 0.001;
    const minP = rawMin - rawRange * 0.1;
    const maxP = rawMax + rawRange * 0.1;
    const range = maxP - minP;

    const toX = (i: number) => pad.left + (i / (prices.length - 1)) * cw;
    const toY = (p: number) => pad.top + ch - ((p - minP) / range) * ch;

    // Clear
    ctx.clearRect(0, 0, W, H);

    // ── Subtle dark chart background ──
    ctx.fillStyle = 'rgba(5,8,16,0.0)';
    ctx.fillRect(0, 0, W, H);

    // ── Horizontal grid lines ──
    const gridRows = 6;
    for (let i = 0; i <= gridRows; i++) {
      const y   = pad.top + (ch / gridRows) * i;
      const val = maxP - (range / gridRows) * i;

      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(pad.left + cw, y);
      ctx.strokeStyle = 'rgba(255,255,255,0.04)';
      ctx.lineWidth = 1;
      ctx.setLineDash([]);
      ctx.stroke();

      // Price label
      ctx.fillStyle = 'rgba(100,116,139,0.7)';
      ctx.font = '600 10px "JetBrains Mono", ui-monospace, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(val.toFixed(3), pad.left - 8, y + 3.5);
    }

    // ── Vertical time labels ──
    const vCount = Math.min(5, Math.floor(prices.length / 15));
    ctx.fillStyle = 'rgba(71,85,105,0.6)';
    ctx.font = '10px Inter, sans-serif';
    ctx.textAlign = 'center';
    for (let i = 0; i <= vCount; i++) {
      const idx = Math.floor((i / vCount) * (prices.length - 1));
      const x = toX(idx);
      const ep = filtered[idx]?.epoch || 0;
      const d = new Date(ep * 1000);
      const label = `${d.getHours().toString().padStart(2,'0')}:${d.getMinutes().toString().padStart(2,'0')}`;

      ctx.beginPath();
      ctx.moveTo(x, pad.top);
      ctx.lineTo(x, pad.top + ch);
      ctx.strokeStyle = 'rgba(255,255,255,0.025)';
      ctx.lineWidth = 1;
      ctx.stroke();

      ctx.fillText(label, x, H - 10);
    }

    const isRising = prices[prices.length - 1] >= prices[0];
    const lineColor =
      signal === 'CALL' ? '#10b981' :
      signal === 'PUT'  ? '#ef4444' :
      isRising ? '#10b981' : '#ef4444';

    // ── Thin gradient area ──
    const areaGrad = ctx.createLinearGradient(0, pad.top, 0, pad.top + ch);
    areaGrad.addColorStop(0,   lineColor + '18');
    areaGrad.addColorStop(0.5, lineColor + '06');
    areaGrad.addColorStop(1,   'rgba(0,0,0,0)');

    ctx.beginPath();
    prices.forEach((p, i) => {
      i === 0 ? ctx.moveTo(toX(i), toY(p)) : ctx.lineTo(toX(i), toY(p));
    });
    ctx.lineTo(toX(prices.length - 1), pad.top + ch);
    ctx.lineTo(pad.left, pad.top + ch);
    ctx.closePath();
    ctx.fillStyle = areaGrad;
    ctx.fill();

    // ── Price line ──
    ctx.beginPath();
    prices.forEach((p, i) => {
      i === 0 ? ctx.moveTo(toX(i), toY(p)) : ctx.lineTo(toX(i), toY(p));
    });
    ctx.strokeStyle = lineColor;
    ctx.lineWidth = 1.6;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';
    ctx.setLineDash([]);
    ctx.stroke();

    // ── Current price dashed line ──
    const lastY = toY(prices[prices.length - 1]);
    ctx.beginPath();
    ctx.moveTo(pad.left, lastY);
    ctx.lineTo(pad.left + cw, lastY);
    ctx.strokeStyle = lineColor + '35';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 5]);
    ctx.stroke();
    ctx.setLineDash([]);

    // ── Current price tag ──
    const tagW = 62;
    const tagH = 18;
    const tagX = W - tagW - 2;
    const tagY = lastY - tagH / 2;
    ctx.fillStyle = lineColor;
    ctx.beginPath();
    ctx.roundRect(tagX, tagY, tagW, tagH, 3);
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px "JetBrains Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText(prices[prices.length - 1].toFixed(3), tagX + tagW / 2, tagY + 12.5);

    // ── Pulsing end dot ──
    const endX = toX(prices.length - 1);
    ctx.beginPath();
    ctx.arc(endX, lastY, 3.5, 0, Math.PI * 2);
    ctx.fillStyle = lineColor;
    ctx.fill();
    ctx.beginPath();
    ctx.arc(endX, lastY, 7, 0, Math.PI * 2);
    ctx.strokeStyle = lineColor + '45';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // ── Hover crosshair ──
    if (hoverIdx !== null && hoverIdx >= 0 && hoverIdx < prices.length) {
      const hx = toX(hoverIdx);
      const hy = toY(prices[hoverIdx]);

      ctx.beginPath();
      ctx.moveTo(hx, pad.top);
      ctx.lineTo(hx, pad.top + ch);
      ctx.strokeStyle = 'rgba(6,182,212,0.28)';
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 3]);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(pad.left, hy);
      ctx.lineTo(pad.left + cw, hy);
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.beginPath();
      ctx.arc(hx, hy, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#06b6d4';
      ctx.fill();

      // Hover price tag on left axis
      const hVal = prices[hoverIdx].toFixed(3);
      const htW = 58, htH = 16;
      ctx.fillStyle = 'rgba(6,182,212,0.85)';
      ctx.beginPath();
      ctx.roundRect(2, hy - htH / 2, htW, htH, 3);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.font = '600 9px "JetBrains Mono", monospace';
      ctx.textAlign = 'center';
      ctx.fillText(hVal, 2 + htW / 2, hy + 3.5);
    }
  }, [ticks, dimensions, signal, getFiltered, hoverIdx]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const filtered = getFiltered();
    if (!filtered.length) return;
    const pad = { left: 70, right: 18 };
    const cw = rect.width - pad.left - pad.right;
    const x = e.clientX - rect.left - pad.left;
    const idx = Math.round((x / cw) * (filtered.length - 1));
    setHoverIdx(Math.max(0, Math.min(filtered.length - 1, idx)));
  }, [getFiltered]);

  const isRising = ticks.length > 1 && ticks[ticks.length - 1].quote >= ticks[0].quote;
  const priceColor = signal === 'CALL' ? '#10b981' : signal === 'PUT' ? '#ef4444' : isRising ? '#10b981' : '#ef4444';

  const hovered = hoverIdx !== null ? getFiltered()[hoverIdx] : null;

  return (
    <div className="relative flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center justify-between px-4 py-2 shrink-0"
        style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
        <div className="flex items-center gap-2.5">
          <span className="text-xs font-bold font-mono" style={{ color: '#94a3b8' }}>{symbol}</span>
          <div className="w-px h-3.5" style={{ background: 'rgba(255,255,255,0.07)' }} />
          {currentPrice !== null && (
            <span className="text-sm font-bold font-mono transition-colors"
              style={{ color: priceColor }}>
              {currentPrice.toFixed(3)}
            </span>
          )}
          {signal && signal !== 'NEUTRAL' && (
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-md text-2xs font-bold"
              style={{
                background: signal === 'CALL' ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)',
                color: signal === 'CALL' ? '#10b981' : '#ef4444',
                border: `1px solid ${signal === 'CALL' ? 'rgba(16,185,129,0.2)' : 'rgba(239,68,68,0.2)'}`,
              }}>
              {signal === 'CALL' ? <TrendingUp size={9} /> : <TrendingDown size={9} />}
              <span className="ml-0.5">{signal === 'CALL' ? 'RISE' : 'FALL'}</span>
            </div>
          )}
          {hovered && (
            <span className="text-2xs font-mono" style={{ color: '#475569' }}>
              {hovered.quote.toFixed(3)}
            </span>
          )}
        </div>

        <div className="flex items-center gap-0.5">
          {(['1m', '5m', '15m', 'all'] as TimeFrame[]).map(tf => (
            <button key={tf} onClick={() => setTimeframe(tf)}
              className="px-2 py-1 rounded text-2xs font-semibold transition-all"
              style={{
                background: timeframe === tf ? 'rgba(6,182,212,0.12)' : 'transparent',
                color: timeframe === tf ? '#06b6d4' : '#475569',
                border: timeframe === tf ? '1px solid rgba(6,182,212,0.2)' : '1px solid transparent',
              }}>
              {tf === 'all' ? 'ALL' : tf.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Canvas */}
      <div ref={containerRef} className="flex-1 relative overflow-hidden">
        {ticks.length < 2 ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
            <div className="relative">
              <div className="w-9 h-9 rounded-full border-2 border-t-cyan-500 border-cyan-500/20 animate-spin" />
              <div className="absolute inset-0 rounded-full" style={{ boxShadow: '0 0 20px rgba(6,182,212,0.15)' }} />
            </div>
            <div className="text-center">
              <p className="text-xs font-semibold" style={{ color: '#06b6d4' }}>Connecting to {symbol}</p>
              <p className="text-2xs mt-1" style={{ color: '#334155' }}>Awaiting live market data</p>
            </div>
          </div>
        ) : (
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full"
            onMouseMove={handleMouseMove}
            onMouseLeave={() => setHoverIdx(null)}
          />
        )}
      </div>
    </div>
  );
}
