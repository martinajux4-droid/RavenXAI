import { useEffect, useRef } from 'react';
import { AIAnalysis } from '../lib/aiEngine';
import { Brain, TrendingUp, TrendingDown, Minus, Activity } from 'lucide-react';

type Props = {
  analysis: AIAnalysis | null;
  loading?: boolean;
};

export default function AIConfidenceMeter({ analysis, loading }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const S = 160;
    canvas.width = S; canvas.height = S;
    const cx = S / 2, cy = S / 2, R = 62;

    ctx.clearRect(0, 0, S, S);

    const startA = Math.PI * 0.72;
    const endA = Math.PI * 2.28;
    const conf = (analysis?.confidence || 0) / 100;

    const color = analysis?.signal === 'CALL' ? '#10b981'
      : analysis?.signal === 'PUT' ? '#ef4444'
      : '#f59e0b';

    // Track
    ctx.beginPath();
    ctx.arc(cx, cy, R, startA, endA);
    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 10;
    ctx.lineCap = 'round';
    ctx.stroke();

    // Subtle glow ring
    ctx.beginPath();
    ctx.arc(cx, cy, R, startA, endA);
    ctx.strokeStyle = 'rgba(255,255,255,0.03)';
    ctx.lineWidth = 18;
    ctx.lineCap = 'round';
    ctx.stroke();

    if (conf > 0) {
      const fillEnd = startA + (endA - startA) * conf;

      // Glow pass
      ctx.beginPath();
      ctx.arc(cx, cy, R, startA, fillEnd);
      ctx.strokeStyle = color + '30';
      ctx.lineWidth = 18;
      ctx.lineCap = 'round';
      ctx.stroke();

      // Main arc
      const grad = ctx.createLinearGradient(0, 0, S, S);
      grad.addColorStop(0, color + 'aa');
      grad.addColorStop(1, color);
      ctx.beginPath();
      ctx.arc(cx, cy, R, startA, fillEnd);
      ctx.strokeStyle = grad;
      ctx.lineWidth = 10;
      ctx.lineCap = 'round';
      ctx.stroke();

      // Tick marks at 30%, 58%, 61%, 80%
      const thresholds = [0.3, 0.58, 0.61, 0.8];
      thresholds.forEach(t => {
        const ta = startA + (endA - startA) * t;
        const inner = R - 8;
        const outer = R + 2;
        ctx.beginPath();
        ctx.moveTo(cx + Math.cos(ta) * inner, cy + Math.sin(ta) * inner);
        ctx.lineTo(cx + Math.cos(ta) * outer, cy + Math.sin(ta) * outer);
        ctx.strokeStyle = t <= 0.58 ? 'rgba(245,158,11,0.5)' : 'rgba(16,185,129,0.5)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      });
    }
  }, [analysis]);

  const signal = analysis?.signal;
  const conf = analysis?.confidence || 0;
  const signalColor = signal === 'CALL' ? '#10b981' : signal === 'PUT' ? '#ef4444' : '#f59e0b';

  return (
    <div className="flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center gap-2">
        <Brain size={13} style={{ color: '#475569' }} />
        <span className="text-xs font-bold uppercase tracking-widest" style={{ color: '#64748b' }}>AI Analysis</span>
        {loading && (
          <div className="ml-auto w-3.5 h-3.5 border-2 rounded-full animate-spin"
            style={{ borderColor: 'rgba(6,182,212,0.3)', borderTopColor: '#06b6d4' }} />
        )}
      </div>

      {/* Gauge + signal */}
      <div className="flex items-center gap-4">
        <div className="relative shrink-0">
          <canvas ref={canvasRef} className="w-[100px] h-[100px]" />
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            {analysis ? (
              <>
                <span className="text-2xl font-bold font-mono leading-none" style={{ color: signalColor }}>{conf}%</span>
                <span className="text-2xs mt-0.5 font-medium" style={{ color: '#475569' }}>confidence</span>
              </>
            ) : (
              <span className="text-xs" style={{ color: '#334155' }}>—</span>
            )}
          </div>
        </div>

        {analysis ? (
          <div className="flex-1 min-w-0 space-y-2">
            {/* Signal badge */}
            <div className="flex items-center gap-2 px-2.5 py-2 rounded-lg"
              style={{
                background: signal === 'CALL' ? 'rgba(16,185,129,0.08)' : signal === 'PUT' ? 'rgba(239,68,68,0.08)' : 'rgba(245,158,11,0.08)',
                border: `1px solid ${signal === 'CALL' ? 'rgba(16,185,129,0.2)' : signal === 'PUT' ? 'rgba(239,68,68,0.2)' : 'rgba(245,158,11,0.2)'}`,
              }}>
              {signal === 'CALL' ? <TrendingUp size={13} style={{ color: '#10b981' }} />
                : signal === 'PUT' ? <TrendingDown size={13} style={{ color: '#ef4444' }} />
                : <Minus size={13} style={{ color: '#f59e0b' }} />}
              <div>
                <p className="text-sm font-bold leading-none" style={{ color: signalColor }}>{signal}</p>
                <p className="text-2xs mt-0.5" style={{ color: '#475569' }}>
                  {conf >= 61 ? 'Execute now' : conf >= 45 ? 'Weak setup' : 'No signal'}
                </p>
              </div>
            </div>

            {/* Threshold bar */}
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-2xs" style={{ color: '#334155' }}>Threshold</span>
                <span className="text-2xs font-mono font-semibold"
                  style={{ color: conf >= 61 ? '#10b981' : conf >= 45 ? '#f59e0b' : '#ef4444' }}>
                  {conf >= 61 ? 'STRONG' : conf >= 45 ? 'WEAK' : 'NONE'}
                </span>
              </div>
              <div className="w-full h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.05)' }}>
                <div className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${conf}%`,
                    background: conf >= 61
                      ? 'linear-gradient(90deg, #059669, #10b981)'
                      : conf >= 45
                      ? 'linear-gradient(90deg, #b45309, #f59e0b)'
                      : 'linear-gradient(90deg, #b91c1c, #ef4444)',
                  }} />
              </div>
              <div className="flex justify-between mt-0.5">
                <span className="text-2xs" style={{ color: '#1e293b' }}>0</span>
                <span className="text-2xs" style={{ color: '#334155' }}>58%</span>
                <span className="text-2xs" style={{ color: '#334155' }}>61%</span>
                <span className="text-2xs" style={{ color: '#1e293b' }}>100</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <p className="text-xs" style={{ color: '#334155' }}>Run scan or click Analyze</p>
          </div>
        )}
      </div>

      {/* Indicators grid */}
      {analysis && (
        <div className="space-y-2">
          <p className="text-2xs font-bold uppercase tracking-widest" style={{ color: '#334155' }}>Indicators</p>
          <div className="grid grid-cols-3 gap-1.5">
            <IndicatorCell label="RSI" value={analysis.indicators.rsi.toFixed(1)}
              status={analysis.indicators.rsi < 30 ? 'bull' : analysis.indicators.rsi > 70 ? 'bear' : 'neutral'} />
            <IndicatorCell label="Trend" value={analysis.indicators.trend}
              status={analysis.indicators.trend === 'UP' ? 'bull' : analysis.indicators.trend === 'DOWN' ? 'bear' : 'neutral'} />
            <IndicatorCell label="Candles" value={analysis.indicators.candleDirection || 'NEUT'}
              status={analysis.indicators.candleDirection === 'BULLISH' ? 'bull' : analysis.indicators.candleDirection === 'BEARISH' ? 'bear' : 'neutral'} />
            <IndicatorCell label="MACD" value={analysis.indicators.macd.histogram > 0 ? 'BULL' : 'BEAR'}
              status={analysis.indicators.macd.histogram > 0 ? 'bull' : 'bear'} />
            <IndicatorCell label="Momentum" value={`${analysis.indicators.momentum > 0 ? '+' : ''}${analysis.indicators.momentum.toFixed(2)}%`}
              status={analysis.indicators.momentum > 0.05 ? 'bull' : analysis.indicators.momentum < -0.05 ? 'bear' : 'neutral'} />
            <IndicatorCell label="Vol" value={`${analysis.indicators.volatility.toFixed(2)}%`} status="neutral" />
          </div>

          {/* Reasoning */}
          {analysis.reasoning.length > 0 && (
            <div className="space-y-1 pt-1">
              <div className="flex items-center gap-1.5">
                <Activity size={10} style={{ color: '#334155' }} />
                <span className="text-2xs font-bold uppercase tracking-widest" style={{ color: '#334155' }}>Signal Basis</span>
              </div>
              {analysis.reasoning.slice(0, 3).map((r, i) => (
                <div key={i} className="flex items-start gap-1.5">
                  <div className="w-1 h-1 rounded-full mt-1.5 shrink-0"
                    style={{ background: signal === 'CALL' ? '#10b981' : signal === 'PUT' ? '#ef4444' : '#f59e0b' }} />
                  <p className="text-2xs leading-relaxed" style={{ color: '#475569' }}>{r}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function IndicatorCell({ label, value, status }: { label: string; value: string; status: 'bull' | 'bear' | 'neutral' }) {
  const color = status === 'bull' ? '#10b981' : status === 'bear' ? '#ef4444' : '#64748b';
  return (
    <div className="px-2 py-1.5 rounded" style={{ background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.04)' }}>
      <p className="text-2xs mb-0.5" style={{ color: '#334155' }}>{label}</p>
      <p className="text-xs font-bold font-mono leading-none" style={{ color }}>{value}</p>
    </div>
  );
}
