// PWA Installation Handler
class PWAInstaller {
  constructor() {
    this.deferredPrompt = null;
    this.init();
  }

  init() {
    // Register service worker
    this.registerServiceWorker();
    
    // Listen for beforeinstallprompt event
    window.addEventListener('beforeinstallprompt', (e) => {
      console.log('beforeinstallprompt event fired');
      // Prevent the mini-infobar from appearing on mobile
      e.preventDefault();
      // Store the event so it can be triggered later
      this.deferredPrompt = e;
      // Update UI to notify the user they can install the PWA
      this.showInstallButton();
    });

    // Listen for app installed
    window.addEventListener('appinstalled', (e) => {
      console.log('PWA was installed');
      this.hideInstallButton();
    });

    // Check if app is already installed
    this.checkIfInstalled();
  }

  async registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js');
        console.log('Service Worker registered with scope:', registration.scope);
        
        // Check for updates
        registration.addEventListener('updatefound', () => {
          console.log('Service Worker update found');
        });
      } catch (error) {
        console.error('Service Worker registration failed:', error);
      }
    }
  }

  showInstallButton() {
    const installButton = document.getElementById('pwa-install-button');
    const installSection = document.querySelector('.install-section');
    
    if (installButton) {
      installButton.style.display = 'block';
      installButton.disabled = false;
    }
    
    if (installSection) {
      installSection.style.display = 'block';
    }
  }

  hideInstallButton() {
    const installButton = document.getElementById('pwa-install-button');
    const installSection = document.querySelector('.install-section');
    
    if (installButton) {
      installButton.style.display = 'none';
    }
    
    if (installSection) {
      installSection.style.display = 'none';
    }
  }

  async installPWA() {
    if (!this.deferredPrompt) {
      console.log('No deferred prompt available');
      this.showManualInstallInstructions();
      return;
    }

    // Show the install prompt
    this.deferredPrompt.prompt();
    
    // Wait for the user to respond to the prompt
    const { outcome } = await this.deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      console.log('User accepted the install prompt');
    } else {
      console.log('User dismissed the install prompt');
    }
    
    // Clear the deferredPrompt
    this.deferredPrompt = null;
  }

  showManualInstallInstructions() {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isAndroid = /Android/.test(navigator.userAgent);
    
    let instructions = '';
    
    if (isIOS) {
      instructions = `
        <div class="manual-install-instructions">
          <h3>Install on iOS:</h3>
          <ol>
            <li>Tap the Share button <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAxNiAxNiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTggMkw2IDRIOVYxMEgxMVY0SDE0TDggMloiIGZpbGw9IiMwMDciLz4KPHBhdGggZD0iTTMgMTJIMTNWMTRIM1YxMloiIGZpbGw9IiMwMDciLz4KPC9zdmc+Cg==" alt="Share" style="width: 16px; height: 16px; display: inline;"></li>
            <li>Scroll down and tap "Add to Home Screen"</li>
            <li>Tap "Add" to confirm</li>
          </ol>
        </div>
      `;
    } else if (isAndroid) {
      instructions = `
        <div class="manual-install-instructions">
          <h3>Install on Android:</h3>
          <ol>
            <li>Tap the menu button (⋮) in your browser</li>
            <li>Select "Add to Home screen" or "Install app"</li>
            <li>Tap "Install" to confirm</li>
          </ol>
        </div>
      `;
    } else {
      instructions = `
        <div class="manual-install-instructions">
          <h3>Install on Desktop:</h3>
          <ol>
            <li>Look for the install icon in your address bar</li>
            <li>Or open your browser menu and select "Install Hifex Trader"</li>
            <li>Click "Install" to confirm</li>
          </ol>
        </div>
      `;
    }
    
    // Show instructions in a modal or alert
    const instructionsContainer = document.getElementById('install-instructions');
    if (instructionsContainer) {
      instructionsContainer.innerHTML = instructions;
      instructionsContainer.style.display = 'block';
    } else {
      // Fallback to alert
      alert('To install this app, look for the install option in your browser menu or address bar.');
    }
  }

  checkIfInstalled() {
    // Check if running in standalone mode (installed PWA)
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    const isFullscreen = window.matchMedia('(display-mode: fullscreen)').matches;
    
    if (isStandalone || isFullscreen) {
      console.log('PWA is already installed');
      this.hideInstallButton();
    }
  }
}

// Initialize PWA installer when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  const pwaInstaller = new PWAInstaller();
  
  // Add event listener to install button
  const installButton = document.getElementById('pwa-install-button');
  if (installButton) {
    installButton.addEventListener('click', () => {
      pwaInstaller.installPWA();
    });
  }
});

// Export for use in other files
window.PWAInstaller = PWAInstaller; 